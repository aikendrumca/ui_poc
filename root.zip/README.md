# Payments Operational UI

View-only UI over MongoDB for ISO 20022 **pain.001.001.09** payment files,
their batches (PmtInf) and transactions (CdtTrfTxInf), and the
**pain.002.001.10** status reports that answer them.

| Folder | What |
|---|---|
| `db/create-db.js` | Creates the `payments` database: collections, validators, indexes |
| `backend/` | Java 25, Spring Boot 4.0.8, Gradle 9.8: XML loader, inbox watcher, read-only REST API |
| `frontend/` | React + TypeScript (Vite): the UI |
| `docker-compose.yml`, `docker-*.ps1` | Run the API and UI in Docker (see below) |

## Run it in Docker (Windows)

Needs only Docker Desktop. From the project folder in PowerShell:

```powershell
.\docker-start.ps1            # build and start; UI on http://localhost:3000
.\docker-samples.ps1          # optional: 20 sample pain.001 files plus pain.002 reports
.\docker-stop.ps1             # stop the containers
```

Double-clicking `docker-start.cmd`, `docker-samples.cmd` or `docker-stop.cmd` does the same.

* **MongoDB.** By default the API uses the MongoDB container you already run
  (`mongoaidb`, published on port 27017), reached as
  `mongodb://host.docker.internal:27017/payments`. Before starting, the script runs
  `db/create-db.js` inside that container (safe to re-run). Use
  `-MongoContainer <name>` for another container, `-SkipDbSetup` to skip that step, or
  set `MONGODB_URI` in `.env` for any other MongoDB.
* **No MongoDB yet?** `.\docker-start.ps1 -BundledMongo` also starts a MongoDB 7
  container for this app, set up with `create-db.js`, with its data in a Docker volume
  (published on port 27018). `.\docker-stop.ps1 -RemoveData` deletes that volume.
* **Inbox.** `.\inbox` is mounted into the API container; drop pain.001 or pain.002
  XML files there.
* **Settings.** Copy `.env.example` to `.env` to change `UI_PORT` (3000), `API_PORT`
  (8080), `MONGODB_URI`, `MONGO_PORT` or `INBOX_DIR`.
* **Faster restarts.** `.\docker-start.ps1 -NoBuild` reuses the built images; `-Open`
  opens the browser.

Two images are built: `payments-ui-api` (Spring Boot on Java 25) and `payments-ui-web`
(nginx serving the React build and forwarding `/api` to the API). The first build
downloads Gradle, Maven and npm packages and takes a few minutes. Without the
scripts, it is plain Compose: `docker compose up -d --build`, and
`docker compose --profile bundled-mongo up -d` with
`MONGODB_URI=mongodb://mongo:27017/payments` for the bundled MongoDB.

## Prerequisites (running without Docker)

* JDK 25 (`java -version`)
* MongoDB running on `localhost:27017` and `mongosh`
* Node.js 22+ (only for the UI)

## First run (Windows PowerShell or any shell)

```powershell
# 1. Create the database (safe to re-run)
mongosh "mongodb://localhost:27017" db/create-db.js

# 2. Generate 20 sample pain.001 files into ./inbox
cd backend
./gradlew generateSamples -Pcount=20 -Pout=../inbox

# 3. Start the API; it loads everything in ../inbox and keeps watching it
./gradlew bootRun

# 4. Optional, with the API still running: write pain.002 status reports for
#    loaded files that have none yet; the inbox picks them up
./gradlew generateStatusReports -Pcount=20 -Pout=../inbox
```

On Windows use `.\gradlew.bat` instead of `./gradlew`.

The API is on http://localhost:8080/api (try `/api/summary`).
The inbox takes both pain.001 and pain.002 files and tells them apart by their
namespace. Loaded files move to `inbox/processed/<date>/`; rejected ones move to
`inbox/failed/` next to a `.error.txt` saying why.

Configuration (environment variables): `MONGODB_URI`
(default `mongodb://localhost:27017/payments`), `PAYMENTS_INBOX` (default `../inbox`), `PORT` (default 8080).

## UI

```powershell
cd frontend
npm install
npm run dev        # http://localhost:5173, proxies /api to :8080
```

For a single deployable jar: `npm run build` in `frontend`, then
`./gradlew bootJar` in `backend`; the jar serves the UI at http://localhost:8080.

The **Original XML** tab shows at most the first 5 MB of a file (about 9,000
transactions), cut at a line break, with a note giving the full size; **Download**
always returns the whole file. Change the limit with `PAYMENTS_XML_PREVIEW_BYTES`
(or `payments.xml.preview-bytes`). The API side is `GET /api/files/{id}/xml?preview=true`
(and the same on `/api/reports/{id}/xml`), which sends `X-Xml-Truncated` and
`X-Xml-Total-Bytes` headers.

## Searching

The Files and Transactions screens filter by:

* **Time range**: files by received or created time (CreDtTm); transactions by
  requested execution date, file created time or file received time. Quick picks
  for the last hour, 24 hours, today, 7 and 30 days.
* **Amount range**: transactions by amount (optionally one currency); files by
  any per-currency total in the file.
* **Initiating party**: picked from the parties seen in loaded files.

The same filters are on the API, e.g.
`/api/transactions?party=Northwind%20Traders%20Ltd&ccy=EUR&min=1000&max=5000&timeField=received&from=2026-09-27T00:00:00Z`.
Times are ISO-8601 instants, or plain dates (`to=2026-09-27` includes that whole day, UTC).
`/api/parties` lists the initiating parties.

Transactions loaded by an earlier version get the fields these filters need
copied down from their file automatically when the app starts.

## Tests and coverage

```powershell
cd backend
.\gradlew.bat check          # all tests + JaCoCo report + 95% coverage gate
```

* **Unit tests** need nothing installed: MongoDB-backed code runs against an
  in-memory MongoDB (`mongo-java-server`), so they work on any machine.
* **Integration tests** (tagged `integration`) run the whole app against a real
  MongoDB in Docker via Testcontainers, and are skipped when Docker is absent.
  `.\gradlew.bat test -PunitOnly` skips them explicitly.
* **Coverage report**: `backend/build/reports/jacoco/test/html/index.html`
  (XML for CI tools next to it). `check` fails if instruction or line coverage
  drops below 95%. Only `PaymentsUiApplication` (the Spring entry point) is excluded.

## Status reports (pain.002)

Each pain.002.001.10 message is stored in `statusReports` and linked to what it
reports on:

| Report reference | Links to |
|---|---|
| `OrgnlGrpInfAndSts/OrgnlMsgId` (plus `OrgnlCreDtTm` if two parties reuse a MsgId) | the file |
| `OrgnlPmtInfAndSts/OrgnlPmtInfId` | a batch in that file |
| `TxInfAndSts/OrgnlUETR`, else `OrgnlEndToEndId` (+ `OrgnlInstrId`), else `OrgnlInstrId` | a transaction |

The latest status is copied onto the file, batch or transaction as `status`
(code, reason, which report said so). A group status applies to every batch and
transaction in the file, and a batch status to every transaction in the batch,
except `PART`, which only means "see the details". The newest report by
`CreDtTm` wins, so an early `ACTC` arriving late never overwrites a final
`ACSC` or `RJCT`. A report whose original file is not loaded yet is kept as
"Original not loaded" and linked as soon as that file arrives. References that
do not match are listed on the report page.

In the UI: a **Status reports** page, a payment status column and filter on
Files and Transactions, a **Payment status** card on each file with the
transaction breakdown, the status history of every batch and transaction, and
the reports hanging off the file in the link graph.

## Audit log

Every user action lands in the `auditLog` collection of the same database
(created by `db/create-db.js`). There are two sources:

* `source: "api"`: one entry per `/api` call, written by the API itself, e.g.
  `files.list`, `file.view`, `transaction.view`, `report.xml`. Filters sent with
  a list call are kept in `details`; `request` holds method, path, route, HTTP
  status and duration. Calls to unknown routes are logged as `api.request`.
* `source: "ui"`: what the user did in the browser, sent to
  `POST /api/audit/events`: `page.view`, `search.query`, `search.open`,
  `list.filter`, `list.page`, `file.tab`, `report.tab`, `graph.open`,
  `xml.download`, `theme.change`.

Each entry has `at`, `action`, `target {type, id, label}` when the action is about
one file, batch, transaction or report, and `userId`, which is **always null for
now**. Once sign-in exists, declare a `UserResolver` bean (see
`backend/src/main/java/com/paymentsui/audit/UserResolver.java`); without one the
API already uses the servlet's remote user.

`client` holds everything seen about the caller:

| Field | Meaning |
|---|---|
| `ip` | Source IP: the first `X-Forwarded-For` address, else the TCP peer |
| `remoteAddr`, `forwardedFor`, `realIp` | The raw values it was worked out from |
| `clientId` | Random id kept in the browser's local storage (one per browser) |
| `sessionId` | Random id per browser tab session |
| `requestId` | Per API call; also returned in the `X-Request-Id` response header |
| `userAgent`, `referer`, `origin`, `acceptLanguage` | Request headers |

Settings (environment variables or `application.yml`):

* `PAYMENTS_AUDIT_API_REQUESTS=false` stops logging API calls (UI events are still stored).
* `PAYMENTS_AUDIT_TRUST_FORWARDED_FOR=false` ignores `X-Forwarded-For` for `ip`.
  Leave it on behind the bundled nginx or the Vite dev server, which set it; turn
  it off if the API is exposed directly, since a client can send any value.

With Docker Desktop, browsers on the same machine usually show up as the Docker
gateway address (such as `172.18.0.1`) rather than `127.0.0.1`; requests from
other machines show their real address.

A failed audit write is logged as a warning and never breaks the page. The
collection grows forever; `create-db.js` has a commented-out TTL index if you
want old entries removed.

```js
// mongosh payments
db.auditLog.find().sort({ at: -1 }).limit(20)
db.auditLog.find({ "client.ip": "10.1.2.3" }).sort({ at: -1 })
db.auditLog.find({ "target.type": "file", "target.id": "<file id>" }).sort({ at: -1 })
db.auditLog.aggregate([{ $group: { _id: "$action", n: { $sum: 1 } } }, { $sort: { n: -1 } }])
```

## Data model

See `docs/design.md`. In short: `files` (GrpHdr), `batches` (PmtInf, `fileId`),
`transactions` (CdtTrfTxInf, `fileId` + `batchId`, plus a flat `view` sub-document
for fast lists and search), and `statusReports` (pain.002, with `fileId`,
`batchId` and `txId` links). Field names are the ISO tags in camelCase; amounts are
Decimal128. Original XML is kept in the GridFS bucket `rawXml`.
