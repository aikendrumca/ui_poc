<#
.SYNOPSIS
    Builds and starts the payments UI in Docker.

.DESCRIPTION
    Starts two containers from docker-compose.yml: the API (Spring Boot) and the UI
    (nginx serving the React app and forwarding /api to the API).

    By default the API uses your existing MongoDB container (mongoaidb) through the
    port it publishes on this machine, and this script first runs db/create-db.js
    inside that container so collections, validators and indexes are up to date
    (safe to re-run). Use -BundledMongo on a machine without MongoDB.

.EXAMPLE
    .\docker-start.ps1
    Uses the MongoDB container "mongoaidb", builds the images and starts everything.

.EXAMPLE
    .\docker-start.ps1 -BundledMongo
    Also starts a MongoDB container for this app (data kept in a Docker volume).

.EXAMPLE
    .\docker-start.ps1 -MongoContainer mymongo -NoBuild -Open
#>
[CmdletBinding()]
param(
    # Name of your existing MongoDB container; create-db.js is run inside it.
    [string]$MongoContainer = "mongoaidb",
    # Start a MongoDB container for this app instead of using an existing one.
    [switch]$BundledMongo,
    # Do not run create-db.js against the existing MongoDB container.
    [switch]$SkipDbSetup,
    # Reuse the images already built instead of rebuilding them.
    [switch]$NoBuild,
    # Open the UI in the browser once it is up.
    [switch]$Open
)

$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
. (Join-Path $PSScriptRoot "docker/common.ps1")

Assert-Docker
$settings = Get-DockerSettings
New-Item -ItemType Directory -Force -Path $settings.InboxDir | Out-Null

$composeArgs = @()
if ($BundledMongo) {
    Write-Step "Using the bundled MongoDB container (port $($settings.MongoPort) on this machine)"
    $env:MONGODB_URI = "mongodb://mongo:27017/payments"
    $composeArgs += @("--profile", "bundled-mongo")
} else {
    Write-Step "Using the MongoDB at $($settings.MongoUri)"
    if (-not $SkipDbSetup) {
        Initialize-ExistingMongo -Container $MongoContainer -Uri $settings.MongoUri
    }
}

try {
    $up = $composeArgs + @("up", "-d")
    if (-not $NoBuild) {
        Write-Step "Building images (the first build downloads Gradle, Maven and npm packages and takes a few minutes)"
        $up += "--build"
    }
    docker compose @up
    if ($LASTEXITCODE -ne 0) { throw "docker compose up failed (exit code $LASTEXITCODE)." }
} finally {
    Remove-Item Env:\MONGODB_URI -ErrorAction SilentlyContinue
}

Write-Step "Waiting for the API to report healthy"
$healthUrl = "http://localhost:$($settings.ApiPort)/actuator/health"
$deadline = (Get-Date).AddSeconds(120)
$healthy = $false
while ((Get-Date) -lt $deadline) {
    try {
        $r = Invoke-RestMethod -Uri $healthUrl -TimeoutSec 3
        if ($r.status -eq "UP") { $healthy = $true; break }
    } catch { }
    Start-Sleep -Seconds 2
}

$uiUrl = "http://localhost:$($settings.UiPort)"
if ($healthy) {
    Write-Host ""
    Write-Host "Payments UI is running." -ForegroundColor Green
    Write-Host "  UI     $uiUrl"
    Write-Host "  API    http://localhost:$($settings.ApiPort)/api/summary"
    Write-Host "  Inbox  $((Resolve-Path $settings.InboxDir).Path)  (drop pain.001 / pain.002 XML files here)"
    Write-Host "  Logs   docker compose logs -f api"
    Write-Host "  Stop   .\docker-stop.ps1"
    if ($Open) { Start-Process $uiUrl }
} else {
    Write-Warning "The API did not report healthy within 2 minutes. Recent API log lines:"
    docker compose logs --tail 40 api
    exit 1
}
