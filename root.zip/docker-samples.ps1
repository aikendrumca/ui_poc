<#
.SYNOPSIS
    Writes sample pain.001 files and pain.002 status reports into the inbox, using the API image.

.DESCRIPTION
    Needs the containers from docker-start.ps1 to be running. Sample pain.001 files
    are written first; the running API loads them within a few seconds. Status
    reports are then written for loaded files that have none yet, and loaded too.

.EXAMPLE
    .\docker-samples.ps1
    20 pain.001 files, then status reports for up to 20 files.
.EXAMPLE
    .\docker-samples.ps1 -Files 0 -StatusReports 50
    Only status reports, for files already loaded.
#>
[CmdletBinding()]
param(
    [int]$Files = 20,
    [int]$StatusReports = 20
)

$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
. (Join-Path $PSScriptRoot "docker/common.ps1")

Assert-Docker
$running = docker compose ps --status running --services
if ($running -notcontains "api") { throw "The API container is not running. Start it with .\docker-start.ps1 first." }

function Invoke-InApi([string]$MainClass, [string[]]$Arguments) {
    docker compose exec -T api java "-Dloader.main=$MainClass" -cp /app/app.jar `
        org.springframework.boot.loader.launch.PropertiesLauncher @Arguments
    if ($LASTEXITCODE -ne 0) { throw "$MainClass failed (exit code $LASTEXITCODE)." }
}

if ($Files -gt 0) {
    Write-Step "Writing $Files sample pain.001 files into the inbox"
    Invoke-InApi "com.paymentsui.samples.SampleGenerator" @("/data/inbox", "$Files")
    Write-Step "Waiting for the API to load them"
    $inbox = (Get-DockerSettings).InboxDir
    $deadline = (Get-Date).AddSeconds(90)
    while ((Get-Date) -lt $deadline -and (Get-ChildItem -Path $inbox -Filter "pain001_*.xml" -File).Count -gt 0) {
        Start-Sleep -Seconds 2
    }
}
if ($StatusReports -gt 0) {
    Write-Step "Writing pain.002 status reports for up to $StatusReports loaded files"
    # The generator reads MONGODB_URI from the API container's environment.
    Invoke-InApi "com.paymentsui.samples.StatusReportGenerator" @("/data/inbox", "$StatusReports")
}
Write-Host "Done. The API loads new inbox files every 10 seconds." -ForegroundColor Green
