<#
.SYNOPSIS
    Stops the payments UI containers started by docker-start.ps1.

.DESCRIPTION
    Stops and removes the API and UI containers (and the bundled MongoDB, if it
    was started). Your own MongoDB container is not touched. Data in the bundled
    MongoDB is kept unless you pass -RemoveData.

.EXAMPLE
    .\docker-stop.ps1
.EXAMPLE
    .\docker-stop.ps1 -RemoveData
    Also deletes the bundled MongoDB's data volume.
#>
[CmdletBinding()]
param(
    # Delete the bundled MongoDB's data volume as well.
    [switch]$RemoveData
)

$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
. (Join-Path $PSScriptRoot "docker/common.ps1")

Assert-Docker
$down = @("--profile", "bundled-mongo", "down", "--remove-orphans")
if ($RemoveData) { $down += "--volumes" }
Write-Step "Stopping the payments UI containers"
docker compose @down
if ($LASTEXITCODE -ne 0) { throw "docker compose down failed (exit code $LASTEXITCODE)." }
Write-Host "Stopped." -ForegroundColor Green
