// Creates the `payments` database for ISO 20022 pain.001.001.09 payment files and
// the pain.002.001.10 status reports that answer them.
// Run: mongosh "mongodb://localhost:27017" create-db.js
// Other database name: mongosh "mongodb://localhost:27017" --eval "var DB_NAME='payments_test'" create-db.js
// Safe to re-run: existing collections get their validator updated, indexes are idempotent.

const dbName = typeof DB_NAME !== "undefined" ? DB_NAME : "payments";
const pdb = db.getSiblingDB(dbName);

const max35 = { bsonType: "string", minLength: 1, maxLength: 35 };
const ccy = { bsonType: "string", pattern: "^[A-Z]{3}$" };
const money = { bsonType: "decimal" };
const partyOpt = { bsonType: "object" };
// Latest pain.002 status copied onto a file, batch or transaction.
const pmtStatus = {
  bsonType: "object",
  required: ["code", "level", "at", "reportId"],
  properties: {
    code: { bsonType: "string", pattern: "^[A-Z]{4}$" },
    level: { enum: ["GROUP", "PMTINF", "TX"] },
    at: { bsonType: "date" },
    reportId: { bsonType: "objectId" },
    reportMsgId: max35,
    rsn: { bsonType: "string" },
    addtlInf: { bsonType: "string" }
  }
};

const schemas = {
  files: {
    bsonType: "object",
    required: ["msgId", "creDtTm", "nbOfTxs", "initgPty", "source"],
    properties: {
      msgId: max35,
      creDtTm: { bsonType: "date" },
      authstn: { bsonType: "array", maxItems: 2 },
      nbOfTxs: { bsonType: ["int", "long"], minimum: 1 },
      ctrlSum: money,
      initgPty: partyOpt,
      fwdgAgt: { bsonType: "object" },
      source: {
        bsonType: "object",
        required: ["fileName", "receivedAt", "sha256"],
        properties: {
          fileName: { bsonType: "string" },
          receivedAt: { bsonType: "date" },
          sha256: { bsonType: "string", pattern: "^[a-f0-9]{64}$" },
          sizeBytes: { bsonType: ["int", "long"] },
          channel: { bsonType: "string" }
        }
      },
      validation: {
        bsonType: "object",
        properties: { status: { enum: ["VALID", "WARN", "INVALID"] } }
      },
      status: pmtStatus
    }
  },

  batches: {
    bsonType: "object",
    required: ["fileId", "msgId", "seq", "pmtInfId", "pmtMtd", "nbOfTxs", "reqdExctnDt", "dbtr", "dbtrAcct", "dbtrAgt"],
    properties: {
      fileId: { bsonType: "objectId" },
      msgId: max35,
      seq: { bsonType: "int", minimum: 0 },
      pmtInfId: max35,
      pmtMtd: { enum: ["TRF", "CHK", "TRA"] },
      btchBookg: { bsonType: "bool" },
      nbOfTxs: { bsonType: ["int", "long"], minimum: 1 },
      ctrlSum: money,
      reqdExctnDt: {
        bsonType: "object",
        required: ["date", "hasTime"],
        properties: { date: { bsonType: "date" }, hasTime: { bsonType: "bool" } }
      },
      dbtr: partyOpt,
      dbtrAcct: { bsonType: "object" },
      dbtrAgt: { bsonType: "object" },
      chrgBr: { enum: ["DEBT", "CRED", "SHAR", "SLEV"] },
      status: pmtStatus
    }
  },

  transactions: {
    bsonType: "object",
    required: ["fileId", "batchId", "msgId", "pmtInfId", "seq", "pmtId", "amt", "view"],
    properties: {
      fileId: { bsonType: "objectId" },
      batchId: { bsonType: "objectId" },
      msgId: max35,
      pmtInfId: max35,
      seq: { bsonType: "int", minimum: 0 },
      pmtId: {
        bsonType: "object",
        required: ["endToEndId"],
        properties: {
          instrId: max35,
          endToEndId: max35,
          uetr: {
            bsonType: "string",
            pattern: "^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$"
          }
        }
      },
      amt: {
        bsonType: "object",
        minProperties: 1,
        maxProperties: 1,
        properties: {
          instdAmt: {
            bsonType: "object",
            required: ["value", "ccy"],
            properties: { value: money, ccy: ccy }
          },
          eqvtAmt: {
            bsonType: "object",
            required: ["amt", "ccyOfTrf"],
            properties: { amt: { bsonType: "object" }, ccyOfTrf: ccy }
          }
        }
      },
      chrgBr: { enum: ["DEBT", "CRED", "SHAR", "SLEV"] },
      view: {
        bsonType: "object",
        required: ["amount", "ccy", "reqdExctnDt"],
        properties: {
          amount: money,
          ccy: ccy,
          reqdExctnDt: { bsonType: "date" }
        }
      },
      status: pmtStatus
    }
  },

  // What users did: one document per API call or UI event. userId stays null until
  // sign-in exists; see README "Audit log".
  auditLog: {
    bsonType: "object",
    required: ["at", "source", "action", "client"],
    properties: {
      at: { bsonType: "date" },
      source: { enum: ["api", "ui"] },
      action: { bsonType: "string", pattern: "^[a-z][a-z0-9._-]{0,63}$" },
      userId: { bsonType: ["string", "null"] },
      target: {
        bsonType: "object",
        properties: { type: { bsonType: "string" }, id: { bsonType: "string" }, label: { bsonType: "string" } }
      },
      details: { bsonType: "object" },
      page: { bsonType: "string" },
      clientAt: { bsonType: "date" },
      client: {
        bsonType: "object",
        required: ["ip"],
        properties: {
          ip: { bsonType: ["string", "null"] },
          remoteAddr: { bsonType: ["string", "null"] },
          forwardedFor: { bsonType: "array", items: { bsonType: "string" } },
          clientId: { bsonType: "string" },
          sessionId: { bsonType: "string" },
          requestId: { bsonType: "string" },
          userAgent: { bsonType: "string" }
        }
      },
      request: {
        bsonType: "object",
        properties: {
          method: { bsonType: "string" },
          path: { bsonType: "string" },
          status: { bsonType: "int" },
          durationMs: { bsonType: ["int", "long"] }
        }
      }
    }
  },

  // One document per pain.002.001.10 message. fileId, orgnlPmtInfAndSts.batchId and
  // orgnlPmtInfAndSts.txInfAndSts.txId link back to the original pain.001; they are
  // null until the original is loaded.
  statusReports: {
    bsonType: "object",
    required: ["msgId", "creDtTm", "orgnlGrpInfAndSts", "orgnlPmtInfAndSts", "source", "link"],
    properties: {
      msgId: max35,
      creDtTm: { bsonType: "date" },
      fileId: { bsonType: ["objectId", "null"] },
      orgnlGrpInfAndSts: {
        bsonType: "object",
        required: ["orgnlMsgId", "orgnlMsgNmId"],
        properties: {
          orgnlMsgId: max35,
          orgnlMsgNmId: max35,
          orgnlCreDtTm: { bsonType: "date" },
          grpSts: { bsonType: "string", pattern: "^[A-Z]{4}$" }
        }
      },
      orgnlPmtInfAndSts: {
        bsonType: "array",
        items: {
          bsonType: "object",
          required: ["orgnlPmtInfId", "txInfAndSts"],
          properties: {
            orgnlPmtInfId: max35,
            batchId: { bsonType: ["objectId", "null"] },
            pmtInfSts: { bsonType: "string", pattern: "^[A-Z]{4}$" },
            txInfAndSts: {
              bsonType: "array",
              items: {
                bsonType: "object",
                properties: {
                  txId: { bsonType: ["objectId", "null"] },
                  txSts: { bsonType: "string", pattern: "^[A-Z]{4}$" }
                }
              }
            }
          }
        }
      },
      source: {
        bsonType: "object",
        required: ["fileName", "receivedAt", "sha256"],
        properties: {
          fileName: { bsonType: "string" },
          receivedAt: { bsonType: "date" },
          sha256: { bsonType: "string", pattern: "^[a-f0-9]{64}$" }
        }
      },
      link: {
        bsonType: "object",
        required: ["status"],
        properties: { status: { enum: ["LINKED", "PARTIAL", "UNMATCHED"] } }
      }
    }
  }
};

const existing = pdb.getCollectionNames();
for (const [name, schema] of Object.entries(schemas)) {
  const opts = { validator: { $jsonSchema: schema }, validationLevel: "moderate", validationAction: "error" };
  if (existing.includes(name)) {
    pdb.runCommand({ collMod: name, ...opts });
    print(`updated validator: ${name}`);
  } else {
    pdb.createCollection(name, opts);
    print(`created: ${name}`);
  }
}

pdb.files.createIndexes([
  { creDtTm: -1 },
  { "source.receivedAt": -1 },
  { "validation.status": 1, creDtTm: -1 },
  { "initgPty.nm": 1, "source.receivedAt": -1 },
  { "stats.totalsByCcy.ccy": 1, "stats.totalsByCcy.amount": 1 }
]);
pdb.files.createIndex({ msgId: 1, "initgPty.nm": 1 }, { unique: true, name: "uniq_msgId_initgPty" });
pdb.files.createIndex({ "source.sha256": 1 }, { unique: true, name: "uniq_sha256" });

pdb.files.createIndex({ "status.code": 1 }, { sparse: true });

pdb.batches.createIndex({ fileId: 1, seq: 1 }, { unique: true });
pdb.batches.createIndexes([
  { pmtInfId: 1 },
  { "reqdExctnDt.date": -1 },
  { "dbtrAcct.id.iban": 1 }
]);

pdb.transactions.createIndex({ batchId: 1, seq: 1 }, { unique: true });
pdb.transactions.createIndexes([
  { fileId: 1, seq: 1 },
  { "pmtId.endToEndId": 1 },
  { "view.cdtrAcct": 1 },
  { "view.dbtrAcct": 1 },
  { "view.reqdExctnDt": -1, "view.ccy": 1, "view.amount": -1 },
  { "view.initgPtyNm": 1, "view.reqdExctnDt": -1 },
  { "view.creDtTm": -1 },
  { "view.receivedAt": -1 },
  { "view.amount": -1 }
]);
pdb.transactions.createIndex({ "pmtId.uetr": 1 }, { sparse: true });
pdb.transactions.createIndex({ "pmtId.instrId": 1 }, { sparse: true });
pdb.transactions.createIndex({ "status.code": 1, "view.reqdExctnDt": -1 }, { sparse: true });
pdb.transactions.createIndex(
  { "view.cdtrNm": "text", "view.dbtrNm": "text", "view.rmtInf": "text" },
  { name: "tx_text_search" }
);

pdb.statusReports.createIndexes([
  { fileId: 1, creDtTm: 1 },
  { "orgnlGrpInfAndSts.orgnlMsgId": 1 },
  { "orgnlPmtInfAndSts.batchId": 1 },
  { "orgnlPmtInfAndSts.txInfAndSts.txId": 1 },
  { creDtTm: -1 },
  { "source.receivedAt": -1 },
  { "link.status": 1 }
]);
pdb.statusReports.createIndex({ msgId: 1, "orgnlGrpInfAndSts.orgnlMsgId": 1 }, { unique: true, name: "uniq_msgId_orgnlMsgId" });
pdb.statusReports.createIndex({ "source.sha256": 1 }, { unique: true, name: "uniq_sha256" });

pdb.auditLog.createIndexes([
  { at: -1 },
  { action: 1, at: -1 },
  { "client.ip": 1, at: -1 },
  { "client.clientId": 1, at: -1 },
  { "client.sessionId": 1, at: 1 },
  { "client.requestId": 1 },
  { userId: 1, at: -1 },
  { "target.type": 1, "target.id": 1, at: -1 }
]);
// No expiry by default. To keep, say, one year of entries:
//   db.auditLog.createIndex({ at: 1 }, { expireAfterSeconds: 31536000, name: "ttl_at" })

print(`done: ${dbName} ready`);
