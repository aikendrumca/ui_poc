package com.paymentsui.samples;

import static com.paymentsui.support.Samples.bytes;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.junit.jupiter.api.io.TempDir;

import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import com.paymentsui.ingest.IngestService;
import com.paymentsui.ingest.Pain002Mapper;
import com.paymentsui.support.InMemoryMongo;
import com.paymentsui.support.Samples;

class StatusReportGeneratorTest {

    @RegisterExtension
    InMemoryMongo mongo = new InMemoryMongo();

    @TempDir
    Path dir;

    private IngestService loadFiles(int count) {
        IngestService ingest = new IngestService(mongo.db());
        SampleGenerator gen = new SampleGenerator(42);
        for (int i = 0; i < count; i++) {
            ingest.ingest(bytes(gen.file("GEN-" + i, i % 8 == 7)), "gen-" + i + ".xml", "test");
        }
        return ingest;
    }

    private static List<Path> sorted(List<Path> paths) {
        List<Path> copy = new ArrayList<>(paths);
        copy.sort(null);
        return copy;
    }

    @Test
    void everyGeneratedReportLoadsAndLinksToItsFile() throws IOException {
        IngestService ingest = loadFiles(16);
        List<Path> written = new StatusReportGenerator(5).writeAll(mongo.db(), dir, 50);

        for (Path p : sorted(written)) {
            ingest.load(Files.readAllBytes(p), p.getFileName().toString(), "test");
        }
        MongoDatabase db = mongo.db();
        assertThat(db.getCollection("statusReports").countDocuments()).isEqualTo(written.size());
        assertThat(db.getCollection("statusReports").countDocuments(Filters.ne("link.status", "LINKED"))).isZero();
        assertThat(db.getCollection("files").countDocuments(Filters.exists("status", false))).isZero();

        // Files that failed validation are rejected with a matching reason.
        for (Document f : db.getCollection("files").find(Filters.eq("validation.status", "INVALID"))) {
            Document status = f.get("status", Document.class);
            assertThat(status.getString("code")).isEqualTo("RJCT");
            assertThat(status.getString("rsn")).isIn("AM10", "AM18", "DUPL");
        }

        // A second run finds nothing left to report on.
        assertThat(new StatusReportGenerator(6).writeAll(db, dir.resolve("again"), 50)).isEmpty();
    }

    @Test
    void producesEveryKindOfOutcome() {
        loadFiles(3);
        MongoDatabase db = mongo.db();
        Set<String> grp = new HashSet<>();
        Set<String> pmtInf = new HashSet<>();
        Set<String> tx = new HashSet<>();
        for (Document file : db.getCollection("files").find()) {
            ObjectId id = file.getObjectId("_id");
            List<Document> batches = db.getCollection("batches").find(Filters.eq("fileId", id)).sort(Sorts.ascending("seq")).into(new ArrayList<>());
            List<Document> txs = db.getCollection("transactions").find(Filters.eq("fileId", id)).into(new ArrayList<>());
            for (int seed = 0; seed < 80; seed++) {
                for (String xml : new StatusReportGenerator(seed).reportsFor(file, batches, txs)) {
                    Document r = Pain002Mapper.map(bytes(xml), Samples.SOURCE);
                    grp.add(r.get("orgnlGrpInfAndSts", Document.class).getString("grpSts"));
                    r.getList("orgnlPmtInfAndSts", Document.class).forEach(p -> {
                        pmtInf.add(p.getString("pmtInfSts"));
                        p.getList("txInfAndSts", Document.class).forEach(t -> tx.add(t.getString("txSts")));
                    });
                }
            }
        }
        assertThat(grp).contains("ACTC", "ACCP", "ACSC", "PART", "RJCT");
        assertThat(pmtInf).contains("ACSC", "PART", "RJCT");
        assertThat(tx).contains("ACSC", "RJCT");
    }

    @Test
    void mainReadsFromTheGivenDatabase() throws IOException {
        loadFiles(3);
        Path out = dir.resolve("inbox");
        StatusReportGenerator.main(new String[] {out.toString(), "2", "9", mongo.connectionString() + "/payments"});
        try (var files = Files.list(out)) {
            assertThat(files.filter(p -> p.getFileName().toString().startsWith("pain002_GEN-"))).isNotEmpty();
        }
        // Without a database in the URI it reads the payments database.
        Path out2 = dir.resolve("inbox2");
        StatusReportGenerator.main(new String[] {out2.toString(), "2", "9", mongo.connectionString()});
        assertThat(out2).isDirectory();
    }

    @Test
    void handlesFilesWithoutAnAgentAndNamesThatNeedEscaping() {
        StatusReportGenerator gen = new StatusReportGenerator(1);
        Document file = new Document("msgId", "A&B/<1>").append("nbOfTxs", 1);
        Document batch = new Document("_id", new ObjectId()).append("pmtInfId", "P&1").append("nbOfTxs", 1);
        Document tx = new Document("batchId", batch.getObjectId("_id"))
                .append("pmtId", new Document("endToEndId", "E&1"))
                .append("view", new Document("ccy", "EUR").append("amount", "1.50").append("cdtrNm", "Margie's"));
        Set<String> all = new HashSet<>();
        for (int seed = 0; seed < 40; seed++) {
            for (String xml : new StatusReportGenerator(seed).reportsFor(file, List.of(batch), List.of(tx))) {
                Document r = Pain002Mapper.map(bytes(xml), Samples.SOURCE);
                assertThat(r.get("orgnlGrpInfAndSts", Document.class).getString("orgnlMsgId")).isEqualTo("A&B/<1>");
                all.add(xml);
            }
        }
        assertThat(String.join("", all)).contains("&amp;").contains("&apos;").doesNotContain("<DbtrAgt>");
        assertThat(gen.reportsFor(new Document("msgId", "EMPTY").append("nbOfTxs", 0), List.of(), List.of())).isNotEmpty();
    }
}
