package com.paymentsui.samples;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import com.paymentsui.ingest.Pain001Mapper;
import com.paymentsui.support.Samples;

class SampleGeneratorTest {

    @TempDir
    Path dir;

    private static List<Path> xmlFiles(Path d) throws IOException {
        try (Stream<Path> s = Files.list(d)) {
            return s.filter(p -> p.toString().endsWith(".xml")).toList();
        }
    }

    @Test
    void mainWritesTheRequestedNumberOfLoadableFiles() throws IOException {
        SampleGenerator.main(new String[] {dir.toString(), "9", "123"});

        List<Path> files = xmlFiles(dir);
        assertThat(files).hasSize(9);
        long problems = files.stream().map(p -> {
            try {
                return Pain001Mapper.map(Files.readAllBytes(p), Samples.SOURCE).file();
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }
        }).filter(f -> !"VALID".equals(f.get("validation", Document.class).getString("status"))).count();
        // Every eighth file carries a deliberate problem.
        assertThat(problems).isEqualTo(1);
    }

    @Test
    void mainDefaultsCountAndSeed() throws IOException {
        Path out = dir.resolve("nested");
        SampleGenerator.main(new String[] {out.toString()});
        assertThat(xmlFiles(out)).hasSize(20);
    }

    @Test
    void everyKindOfDeliberateProblemIsDetected() {
        // Across many seeds each problem type (control sum, count, duplicate EndToEndId) shows up.
        java.util.Set<String> codes = new java.util.HashSet<>();
        for (int seed = 0; seed < 60; seed++) {
            Document file = Samples.map(new SampleGenerator(seed).file("P-" + seed, true)).file();
            file.get("validation", Document.class).getList("issues", Document.class).forEach(i -> codes.add(i.getString("code")));
        }
        assertThat(codes).contains("CTRL_SUM_MISMATCH", "NB_OF_TXS_MISMATCH", "DUPLICATE_E2E");
    }

    @Test
    void ibansHaveValidCheckDigitsForEveryCountry() {
        SampleGenerator gen = new SampleGenerator(3);
        for (String country : List.of("GB", "DE", "FR", "NL", "ES", "IT", "BE", "IE", "CH")) {
            String iban = gen.iban(country);
            assertThat(SampleGenerator.mod97(iban.substring(4) + iban.substring(0, 4))).as(iban).isEqualTo(1);
        }
    }

    @Test
    void escapesXmlSpecialCharactersInNames() {
        // "Margie's Travel" and "City Power & Light" are among the creditors.
        StringBuilder all = new StringBuilder();
        for (int seed = 0; seed < 30; seed++) {
            all.append(new SampleGenerator(seed).file("E-" + seed, false));
        }
        assertThat(all.toString()).contains("&amp;").contains("&apos;").doesNotContain("Power & Light");
    }
}
