package com.paymentsui.support;

import org.junit.jupiter.api.extension.AfterEachCallback;
import org.junit.jupiter.api.extension.BeforeEachCallback;
import org.junit.jupiter.api.extension.ExtensionContext;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

import de.bwaldvogel.mongo.MongoServer;
import de.bwaldvogel.mongo.backend.memory.MemoryBackend;

/**
 * A fresh in-memory MongoDB per test, reached through the real Java driver.
 * Register with {@code @RegisterExtension static InMemoryMongo mongo = new InMemoryMongo();}
 * and use {@link #db()}.
 */
public class InMemoryMongo implements BeforeEachCallback, AfterEachCallback {

    private MongoServer server;
    private MongoClient client;
    private MongoDatabase db;
    private String connectionString;

    @Override
    public void beforeEach(ExtensionContext context) {
        server = new MongoServer(new MemoryBackend());
        connectionString = server.bindAndGetConnectionString();
        client = MongoClients.create(connectionString);
        db = client.getDatabase("payments");
    }

    @Override
    public void afterEach(ExtensionContext context) {
        client.close();
        server.shutdownNow();
    }

    public MongoDatabase db() {
        return db;
    }

    /** Connection string of the server, for code that opens its own client. */
    public String connectionString() {
        return connectionString;
    }
}
