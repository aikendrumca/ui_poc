package com.paymentsui.support;

import java.nio.charset.StandardCharsets;
import java.time.Instant;

import com.paymentsui.ingest.Pain001Mapper;
import com.paymentsui.samples.SampleGenerator;

/** Generated pain.001.001.09 messages, small edits to them for edge cases, and pain.002.001.10 reports. */
public final class Samples {

    public static final Pain001Mapper.Source SOURCE = new Pain001Mapper.Source("test.xml", Instant.parse("2026-09-27T10:00:00Z"), "test");

    private Samples() {
    }

    public static String xml(String msgId) {
        return new SampleGenerator(msgId.hashCode()).file(msgId, false);
    }

    public static byte[] bytes(String xml) {
        return xml.getBytes(StandardCharsets.UTF_8);
    }

    public static Pain001Mapper.Mapped map(String xml) {
        return Pain001Mapper.map(bytes(xml), SOURCE);
    }

    /**
     * A minimal valid message with one batch and {@code txCount} transactions,
     * for tests that need an exact shape (or a large file).
     */
    public static String minimal(String msgId, int txCount) {
        StringBuilder txs = new StringBuilder();
        for (int i = 1; i <= txCount; i++) {
            txs.append("""
                    <CdtTrfTxInf>
                      <PmtId><EndToEndId>E2E-%d</EndToEndId></PmtId>
                      <Amt><InstdAmt Ccy="EUR">1.00</InstdAmt></Amt>
                      <Cdtr><Nm>Creditor %d</Nm></Cdtr>
                      <CdtrAcct><Id><IBAN>DE89370400440532013000</IBAN></Id></CdtrAcct>
                    </CdtTrfTxInf>
                    """.formatted(i, i));
        }
        return """
                <?xml version="1.0" encoding="UTF-8"?>
                <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.09">
                  <CstmrCdtTrfInitn>
                    <GrpHdr>
                      <MsgId>%s</MsgId>
                      <CreDtTm>2026-09-27T09:00:00Z</CreDtTm>
                      <NbOfTxs>%d</NbOfTxs>
                      <InitgPty><Nm>Minimal Ltd</Nm></InitgPty>
                    </GrpHdr>
                    <PmtInf>
                      <PmtInfId>%s-B1</PmtInfId>
                      <PmtMtd>TRF</PmtMtd>
                      <NbOfTxs>%d</NbOfTxs>
                      <ReqdExctnDt><Dt>2026-09-28</Dt></ReqdExctnDt>
                      <Dbtr><Nm>Minimal Ltd</Nm></Dbtr>
                      <DbtrAcct><Id><IBAN>GB29NWBK60161331926819</IBAN></Id></DbtrAcct>
                      <DbtrAgt><FinInstnId><BICFI>NWBKGB2L</BICFI></FinInstnId></DbtrAgt>
                      %s
                    </PmtInf>
                  </CstmrCdtTrfInitn>
                </Document>
                """.formatted(msgId, txCount, msgId, txCount, txs);
    }

    /**
     * A pain.002.001.10 report for {@code orgnlMsgId}. {@code grpSts} may be null;
     * {@code pmtInfs} are {@link #pmtInf} blocks.
     */
    public static String pain002(String msgId, String creDtTm, String orgnlMsgId, String grpSts, String... pmtInfs) {
        return """
                <?xml version="1.0" encoding="UTF-8"?>
                <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.10">
                  <CstmrPmtStsRpt>
                    <GrpHdr><MsgId>%s</MsgId><CreDtTm>%s</CreDtTm></GrpHdr>
                    <OrgnlGrpInfAndSts>
                      <OrgnlMsgId>%s</OrgnlMsgId>
                      <OrgnlMsgNmId>pain.001.001.09</OrgnlMsgNmId>
                      %s
                    </OrgnlGrpInfAndSts>
                    %s
                  </CstmrPmtStsRpt>
                </Document>
                """.formatted(msgId, creDtTm, orgnlMsgId, grpSts == null ? "" : "<GrpSts>" + grpSts + "</GrpSts>",
                String.join("\n", pmtInfs));
    }

    /** An OrgnlPmtInfAndSts block; {@code sts} may be null; {@code txs} are {@link #tx} blocks. */
    public static String pmtInf(String pmtInfId, String sts, String... txs) {
        return "<OrgnlPmtInfAndSts><OrgnlPmtInfId>" + pmtInfId + "</OrgnlPmtInfId>"
                + (sts == null ? "" : "<PmtInfSts>" + sts + "</PmtInfSts>") + String.join("", txs) + "</OrgnlPmtInfAndSts>";
    }

    /** A TxInfAndSts block matched on EndToEndId, with an optional reason code and text. */
    public static String tx(String endToEndId, String sts, String reason, String text) {
        return "<TxInfAndSts><OrgnlEndToEndId>" + endToEndId + "</OrgnlEndToEndId><TxSts>" + sts + "</TxSts>"
                + (reason == null ? "" : "<StsRsnInf><Rsn><Cd>" + reason + "</Cd></Rsn>"
                        + (text == null ? "" : "<AddtlInf>" + text + "</AddtlInf>") + "</StsRsnInf>")
                + "</TxInfAndSts>";
    }
}
