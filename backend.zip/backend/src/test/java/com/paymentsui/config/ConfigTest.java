package com.paymentsui.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mongodb.client.MongoDatabase;

class ConfigTest {

    @Test
    void clientRoutesForwardToTheSinglePageApp() throws Exception {
        MockMvc mvc = MockMvcBuilders.standaloneSetup(new SpaForwardingController()).build();
        for (String path : new String[] {"/", "/files", "/files/abc", "/batches/abc", "/transactions", "/transactions/abc"}) {
            mvc.perform(get(path)).andExpect(status().isOk()).andExpect(forwardedUrl("/index.html"));
        }
    }

    @Test
    void exposesTheTemplatesDatabase() {
        MongoTemplate template = mock(MongoTemplate.class);
        MongoDatabase db = mock(MongoDatabase.class);
        when(template.getDb()).thenReturn(db);
        assertThat(new MongoConfig().paymentsDatabase(template)).isSameAs(db);
    }
}
