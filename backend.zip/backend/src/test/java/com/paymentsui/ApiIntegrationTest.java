package com.paymentsui;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.nio.file.Path;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.mongodb.MongoDBContainer;
import org.testcontainers.utility.MountableFile;

import com.jayway.jsonpath.JsonPath;
import com.paymentsui.ingest.IngestException;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.paymentsui.ingest.IngestService;
import com.paymentsui.ingest.ViewBackfill;
import com.paymentsui.samples.SampleGenerator;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/** Loads generated files into a real MongoDB (with the create-db.js validators) and reads them back through the API. */
@Tag("integration")
@SpringBootTest(properties = "payments.inbox.enabled=false")
@Testcontainers(disabledWithoutDocker = true)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class ApiIntegrationTest {

    @Container
    @ServiceConnection
    static MongoDBContainer mongo = new MongoDBContainer("mongo:7")
            .withCopyFileToContainer(MountableFile.forHostPath(Path.of("../db/create-db.js")), "/tmp/create-db.js");

    @Autowired
    IngestService ingest;

    @Autowired
    WebApplicationContext context;

    @Autowired
    MongoDatabase db;

    @Autowired
    ViewBackfill backfill;

    MockMvc mvc;
    IngestService.Result loaded;

    @BeforeAll
    void load() throws Exception {
        var exec = mongo.execInContainer("mongosh", "--quiet", "mongodb://localhost:27017", "--eval", "var DB_NAME='test'", "/tmp/create-db.js");
        assertThat(exec.getExitCode()).as(exec.getStderr()).isZero();
        mvc = MockMvcBuilders.webAppContextSetup(context).build();
        SampleGenerator gen = new SampleGenerator(99);
        loaded = ingest.ingest(gen.file("MSG-IT-1", false).getBytes(StandardCharsets.UTF_8), "a.xml", "test");
        ingest.ingest(gen.file("MSG-IT-2", true).getBytes(StandardCharsets.UTF_8), "b.xml", "test");
    }

    @Test
    void duplicateFilesAreRejected() {
        byte[] xml = new SampleGenerator(99).file("MSG-IT-1", false).getBytes(StandardCharsets.UTF_8);
        assertThatThrownBy(() -> ingest.ingest(xml, "again.xml", "test"))
                .isInstanceOf(IngestException.class)
                .hasMessageContaining("Duplicate");
    }

    @Test
    void walksFileToBatchToTransaction() throws Exception {
        String file = body("/api/files/" + loaded.fileId());
        assertThat((String) JsonPath.read(file, "$.msgId")).isEqualTo("MSG-IT-1");

        String graph = body("/api/files/" + loaded.fileId() + "/graph");
        String batchId = JsonPath.read(graph, "$.batches[0]._id");
        String txId = JsonPath.read(graph, "$.batches[0].transactions[0]._id");

        String txs = body("/api/batches/" + batchId + "/transactions");
        assertThat((Integer) JsonPath.read(txs, "$.total")).isPositive();

        String tx = body("/api/transactions/" + txId);
        assertThat((String) JsonPath.read(tx, "$.context.batch._id")).isEqualTo(batchId);
        assertThat((String) JsonPath.read(tx, "$.context.file.msgId")).isEqualTo("MSG-IT-1");
        // Amounts travel as strings so no precision is lost.
        assertThat((Object) JsonPath.read(tx, "$.view.amount")).isInstanceOf(String.class);

        String e2e = JsonPath.read(tx, "$.pmtId.endToEndId");
        String hits = body("/api/search?q=" + e2e);
        assertThat((String) JsonPath.read(hits, "$.hits[0].id")).isEqualTo(txId);

        String xml = body("/api/files/" + loaded.fileId() + "/xml");
        assertThat(xml).contains("MSG-IT-1");
    }

    @Test
    void summaryAndFilters() throws Exception {
        String summary = body("/api/summary");
        assertThat((Integer) JsonPath.read(summary, "$.counts.files")).isEqualTo(2);
        assertThat((Integer) JsonPath.read(summary, "$.validation.VALID")).isEqualTo(1);

        String invalid = body("/api/files?status=INVALID");
        assertThat((Integer) JsonPath.read(invalid, "$.total")).isEqualTo(1);

        String eur = body("/api/transactions?ccy=EUR&min=0&size=5");
        assertThat((Integer) JsonPath.read(eur, "$.total")).isPositive();

        mvc.perform(get("/api/files/not-an-id")).andExpect(status().isNotFound());
        mvc.perform(get("/api/transactions?from=yesterday")).andExpect(status().isBadRequest());
        mvc.perform(get("/api/files?to=27/09/2026")).andExpect(status().isBadRequest());
    }

    @Test
    void filtersByInitiatingParty() throws Exception {
        String party = JsonPath.read(body("/api/files/" + loaded.fileId()), "$.initgPty.nm");
        List<String> names = JsonPath.read(body("/api/parties"), "$.items[*].name");
        assertThat(names).contains(party);

        String files = body("/api/files?party=" + enc(party));
        assertThat(JsonPath.<List<String>>read(files, "$.items[*].initgPty.nm")).isNotEmpty().allMatch(party::equals);

        String txs = body("/api/transactions?size=200&party=" + enc(party));
        int expected = JsonPath.<List<Integer>>read(files, "$.items[*].stats.txCount").stream().mapToInt(Integer::intValue).sum();
        assertThat((Integer) JsonPath.read(txs, "$.total")).isEqualTo(expected);
        assertThat(JsonPath.<List<String>>read(txs, "$.items[*].view.initgPtyNm")).allMatch(party::equals);

        assertThat((Integer) JsonPath.read(body("/api/transactions?party=Nobody%20Ltd"), "$.total")).isZero();
    }

    @Test
    void filtersByAmountRange() throws Exception {
        String txs = body("/api/transactions?size=200&min=1000&max=5000");
        List<String> amounts = JsonPath.read(txs, "$.items[*].view.amount");
        assertThat(amounts).isNotEmpty().allSatisfy(a ->
                assertThat(new BigDecimal(a)).isBetween(new BigDecimal("1000"), new BigDecimal("5000")));

        // A file matches when one of its currency totals is inside the range.
        String file = body("/api/files/" + loaded.fileId());
        String ccy = JsonPath.read(file, "$.stats.totalsByCcy[0].ccy");
        BigDecimal total = new BigDecimal(JsonPath.<String>read(file, "$.stats.totalsByCcy[0].amount"));
        String inside = body("/api/files?ccy=" + ccy + "&min=" + total.subtract(BigDecimal.ONE) + "&max=" + total.add(BigDecimal.ONE));
        assertThat(JsonPath.<List<String>>read(inside, "$.items[*].msgId")).contains("MSG-IT-1");
        String above = body("/api/files?ccy=" + ccy + "&min=" + total.add(BigDecimal.ONE) + "&max=" + total.add(BigDecimal.TEN));
        assertThat(JsonPath.<List<String>>read(above, "$.items[*].msgId")).doesNotContain("MSG-IT-1");
    }

    @Test
    void filtersByTimeRange() throws Exception {
        Instant now = Instant.now();
        String lastHour = "&from=" + now.minus(1, ChronoUnit.HOURS) + "&to=" + now.plus(1, ChronoUnit.MINUTES);
        assertThat((Integer) JsonPath.read(body("/api/files?timeField=received" + lastHour), "$.total")).isEqualTo(2);
        assertThat((Integer) JsonPath.read(body("/api/files?timeField=received&from=" + now.plus(1, ChronoUnit.HOURS)), "$.total")).isZero();

        long allTxs = JsonPath.<Integer>read(body("/api/summary"), "$.counts.transactions");
        assertThat((Integer) JsonPath.read(body("/api/transactions?timeField=received" + lastHour), "$.total")).isEqualTo((int) allTxs);

        // Files are created up to five days before today; a date-only "to" includes that whole day.
        String today = LocalDate.now(ZoneOffset.UTC).toString();
        assertThat((Integer) JsonPath.read(body("/api/files?timeField=created&to=" + today), "$.total")).isEqualTo(2);
        assertThat((Integer) JsonPath.read(body("/api/transactions?timeField=created&to=2000-01-01"), "$.total")).isZero();
        // A local date-time without an offset is read as UTC.
        assertThat((Integer) JsonPath.read(body("/api/files?timeField=created&from=2000-01-01T00:00"), "$.total")).isEqualTo(2);
    }

    @Test
    void backfillsViewFieldsOnOlderTransactions() {
        var txs = db.getCollection("transactions");
        txs.updateMany(Filters.eq("fileId", loaded.fileId()),
                Updates.combine(Updates.unset("view.initgPtyNm"), Updates.unset("view.creDtTm"), Updates.unset("view.receivedAt")));
        assertThat(txs.countDocuments(Filters.exists("view.receivedAt", false))).isPositive();

        backfill.run();

        assertThat(txs.countDocuments(Filters.exists("view.receivedAt", false))).isZero();
        assertThat(txs.countDocuments(Filters.and(Filters.eq("fileId", loaded.fileId()), Filters.exists("view.initgPtyNm")))).isEqualTo(loaded.transactions());
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20");
    }

    private String body(String url) throws Exception {
        // A URI (not a template) so pre-encoded query values are sent as-is.
        return mvc.perform(get(java.net.URI.create(url))).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
    }

    @Test
    void statusReportsPassTheValidatorsAndLinkToTheirFile() throws Exception {
        java.nio.file.Path dir = java.nio.file.Files.createTempDirectory("pain002");
        List<java.nio.file.Path> reports = new com.paymentsui.samples.StatusReportGenerator(3).writeAll(db, dir, 10);
        assertThat(reports).isNotEmpty();
        for (java.nio.file.Path p : reports.stream().sorted().toList()) {
            ingest.load(java.nio.file.Files.readAllBytes(p), p.getFileName().toString(), "test");
        }
        assertThat(db.getCollection("statusReports").countDocuments(Filters.eq("link.status", "LINKED"))).isEqualTo(reports.size());
        assertThat(db.getCollection("files").countDocuments(Filters.exists("status"))).isEqualTo(db.getCollection("files").countDocuments());
        String body = mvc.perform(get("/api/files/" + loaded.fileId() + "/status")).andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        assertThat(JsonPath.<List<Object>>read(body, "$.reports")).isNotEmpty();
        mvc.perform(get("/api/reports")).andExpect(status().isOk());
    }

    @Test
    void userActionsAreWrittenToAuditLogAndPassItsValidator() throws Exception {
        MockMvc audited = MockMvcBuilders.webAppContextSetup(context)
                .addFilters(context.getBean(com.paymentsui.audit.AuditFilter.class)).build();
        audited.perform(get("/api/files/" + loaded.fileId())
                        .header("X-Forwarded-For", "203.0.113.9").header("X-Client-Id", "it-client").header("X-Request-Id", "it-req-1"))
                .andExpect(status().isOk());
        audited.perform(org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post("/api/audit/events")
                        .contentType(org.springframework.http.MediaType.APPLICATION_JSON).header("X-Client-Id", "it-client")
                        .content("{\"events\": [{\"action\": \"file.tab\", \"target\": {\"type\": \"file\", \"id\": \"x\"},"
                                + " \"details\": {\"tab\": \"graph\"}, \"path\": \"/files/x\", \"at\": \"2026-09-27T10:00:00Z\"}]}"))
                .andExpect(status().isAccepted());

        // Writes that fail validation are only logged, so finding them proves create-db.js accepts them.
        var log = db.getCollection("auditLog");
        var api = log.find(Filters.eq("client.requestId", "it-req-1")).first();
        assertThat(api).isNotNull();
        assertThat(api.getString("action")).isEqualTo("file.view");
        assertThat(api.get("client", org.bson.Document.class).getString("ip")).isEqualTo("203.0.113.9");
        assertThat(api.containsKey("userId")).isTrue();
        assertThat(log.countDocuments(Filters.and(Filters.eq("source", "ui"), Filters.eq("client.clientId", "it-client")))).isEqualTo(1);
    }
}
