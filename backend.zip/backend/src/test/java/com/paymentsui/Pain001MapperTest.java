package com.paymentsui;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;

import org.bson.Document;
import org.bson.types.Decimal128;
import org.junit.jupiter.api.Test;

import com.paymentsui.ingest.IngestException;
import com.paymentsui.ingest.Pain001Mapper;
import com.paymentsui.samples.SampleGenerator;

class Pain001MapperTest {

    private static final Pain001Mapper.Source SRC = new Pain001Mapper.Source("test.xml", Instant.now(), "test");

    @Test
    void mapsGeneratedFileIntoLinkedDocuments() {
        String xml = new SampleGenerator(42).file("MSG-TEST-1", false);
        Pain001Mapper.Mapped m = Pain001Mapper.map(xml.getBytes(StandardCharsets.UTF_8), SRC);

        Document file = m.file();
        assertThat(file.getString("msgId")).isEqualTo("MSG-TEST-1");
        assertThat(file.get("validation", Document.class).getString("status")).isEqualTo("VALID");
        assertThat(file.get("initgPty", Document.class).getString("nm")).isNotBlank();
        assertThat(file.get("stats", Document.class).getInteger("txCount")).isEqualTo(m.transactions().size());
        assertThat(file.getInteger("nbOfTxs")).isEqualTo(m.transactions().size());

        for (Document b : m.batches()) {
            assertThat(b.get("fileId")).isEqualTo(file.get("_id"));
            assertThat(b.getString("pmtMtd")).isEqualTo("TRF");
            assertThat(b.get("reqdExctnDt", Document.class).get("date")).isNotNull();
            assertThat(b.get("dbtrAcct", Document.class).get("id", Document.class).getString("iban")).isNotBlank();
            assertThat(b.get("dbtrAgt", Document.class).get("finInstnId", Document.class).getString("bicfi")).isNotBlank();
            assertThat(b).doesNotContainKey("cdtTrfTxInf");
        }

        Document tx = m.transactions().getFirst();
        assertThat(tx.get("batchId")).isEqualTo(m.batches().getFirst().get("_id"));
        assertThat(tx.get("fileId")).isEqualTo(file.get("_id"));
        Document instd = tx.get("amt", Document.class).get("instdAmt", Document.class);
        assertThat(instd.get("value")).isInstanceOf(Decimal128.class);
        assertThat(instd.getString("ccy")).matches("[A-Z]{3}");
        assertThat(tx.get("pmtId", Document.class).getString("uetr")).hasSize(36);
        Document view = tx.get("view", Document.class);
        assertThat(view.getString("cdtrAcct")).isNotBlank();
        assertThat(view.get("amount")).isEqualTo(instd.get("value"));
        assertThat(tx.get("rmtInf", Document.class).get("ustrd", List.class)).hasSize(1);
    }

    @Test
    void flagsControlSumAndCountMismatches() {
        String xml = new SampleGenerator(7).file("MSG-TEST-2", false)
                .replaceFirst("<NbOfTxs>\\d+</NbOfTxs>", "<NbOfTxs>9999</NbOfTxs>")
                .replaceFirst("<CtrlSum>[0-9.]+</CtrlSum>", "<CtrlSum>1.00</CtrlSum>");
        Document validation = Pain001Mapper.map(xml.getBytes(StandardCharsets.UTF_8), SRC).file().get("validation", Document.class);

        assertThat(validation.getString("status")).isEqualTo("INVALID");
        assertThat(validation.getList("issues", Document.class)).extracting(d -> d.getString("code"))
                .contains("NB_OF_TXS_MISMATCH", "CTRL_SUM_MISMATCH");
    }

    @Test
    void rejectsOtherMessageVersions() {
        String xml = new SampleGenerator(1).file("MSG-TEST-3", false).replace("pain.001.001.09", "pain.001.001.03");
        assertThatThrownBy(() -> Pain001Mapper.map(xml.getBytes(StandardCharsets.UTF_8), SRC))
                .isInstanceOf(IngestException.class)
                .hasMessageContaining("pain.001.001.09");
    }

    @Test
    void generatedIbansHaveValidCheckDigits() {
        SampleGenerator gen = new SampleGenerator(3);
        for (String country : List.of("GB", "DE", "FR", "NL", "ES", "IT", "BE", "IE")) {
            String iban = gen.iban(country);
            String rearranged = iban.substring(4) + iban.substring(0, 4);
            assertThat(new java.math.BigInteger(rearranged.chars()
                    .mapToObj(c -> Character.isLetter(c) ? String.valueOf(c - 'A' + 10) : String.valueOf((char) c))
                    .reduce("", String::concat)).mod(java.math.BigInteger.valueOf(97)).intValue())
                    .as(iban).isEqualTo(1);
        }
    }
}
