package com.paymentsui.ingest;

import static com.paymentsui.support.Samples.minimal;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.junit.jupiter.api.io.TempDir;

import com.paymentsui.support.InMemoryMongo;

class InboxWatcherTest {

    @RegisterExtension
    InMemoryMongo mongo = new InMemoryMongo();

    @TempDir
    Path dir;

    @Test
    void loadsGoodFilesAndParksBadOnesWithAReason() throws IOException {
        Path inbox = dir.resolve("inbox");
        InboxWatcher watcher = new InboxWatcher(new IngestService(mongo.db()), inbox.toString());
        Files.writeString(inbox.resolve("good.xml"), minimal("INBOX-1", 2));
        Files.writeString(inbox.resolve("bad.XML"), "<not-a-payment/>");
        Files.writeString(inbox.resolve("notes.txt"), "ignored");
        Files.createDirectory(inbox.resolve("folder.xml"));

        watcher.poll();

        assertThat(inbox.resolve("processed").resolve(LocalDate.now().toString()).resolve("good.xml")).exists();
        assertThat(inbox.resolve("failed/bad.XML")).exists();
        assertThat(Files.readString(inbox.resolve("failed/bad.XML.error.txt"))).contains("pain.001.001.09");
        assertThat(inbox.resolve("notes.txt")).exists();
        assertThat(mongo.db().getCollection("files").countDocuments()).isEqualTo(1);
    }

    @Test
    void keepsBothCopiesWhenANameIsReused() throws IOException {
        Path inbox = dir.resolve("inbox");
        InboxWatcher watcher = new InboxWatcher(new IngestService(mongo.db()), inbox.toString());
        Files.writeString(inbox.resolve("dup.xml"), "<one/>");
        watcher.poll();
        Files.writeString(inbox.resolve("dup.xml"), "<two/>");
        watcher.poll();

        try (var files = Files.list(inbox.resolve("failed"))) {
            assertThat(files.map(p -> p.getFileName().toString()).filter(n -> n.endsWith("dup.xml"))).hasSize(2);
        }
    }

    @Test
    void reportsUnexpectedErrorsByType() throws IOException {
        IngestService ingest = mock(IngestService.class);
        when(ingest.load(any(), anyString(), anyString())).thenThrow(new IllegalStateException("db down"));
        Path inbox = dir.resolve("inbox");
        InboxWatcher watcher = new InboxWatcher(ingest, inbox.toString());
        Files.writeString(inbox.resolve("x.xml"), "<x/>");

        watcher.poll();

        assertThat(Files.readString(inbox.resolve("failed/x.xml.error.txt"))).contains("IllegalStateException: db down");
    }

    @Test
    void survivesAnUnreadableInboxAndAnUnwritableFailedFolder() throws IOException {
        IngestService ingest = mock(IngestService.class);
        Path inbox = dir.resolve("inbox");
        InboxWatcher watcher = new InboxWatcher(ingest, inbox.toString());

        // "failed" exists as a file, so the rejected file cannot be moved there.
        Files.writeString(inbox.resolve("failed"), "blocking");
        Files.writeString(inbox.resolve("y.xml"), "<y/>");
        when(ingest.load(any(), eq("y.xml"), anyString())).thenThrow(new IngestException("nope"));
        watcher.poll();
        assertThat(inbox.resolve("y.xml")).exists();

        Files.delete(inbox.resolve("y.xml"));
        Files.delete(inbox.resolve("failed"));
        Files.delete(inbox);
        watcher.poll();
        verify(ingest, never()).load(any(), eq("z.xml"), anyString());
    }
}
