package com.paymentsui.ingest;

import static com.paymentsui.support.Samples.bytes;
import static com.paymentsui.support.Samples.minimal;
import static com.paymentsui.support.Samples.pain002;
import static com.paymentsui.support.Samples.pmtInf;
import static com.paymentsui.support.Samples.tx;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.model.Indexes;
import com.paymentsui.support.InMemoryMongo;

class StatusReportServiceTest {

    @RegisterExtension
    InMemoryMongo mongo = new InMemoryMongo();

    IngestService ingest;

    @BeforeEach
    void setUp() {
        ingest = new IngestService(mongo.db());
    }

    private MongoCollection<Document> col(String name) {
        return mongo.db().getCollection(name);
    }

    private Document statusOf(String collection, Document filter) {
        return col(collection).find(filter).first().get("status", Document.class);
    }

    private Document txStatus(String e2e) {
        return statusOf("transactions", new Document("pmtId.endToEndId", e2e));
    }

    private Document report(String msgId) {
        return col("statusReports").find(Filters.eq("msgId", msgId)).first();
    }

    private String load(String xml, String name) {
        return ingest.load(bytes(xml), name, "test");
    }

    @Test
    void aGroupStatusAppliesToTheFileAndEverythingInIt() {
        load(minimal("S-1", 3), "s1.xml");
        String summary = load(pain002("R-1", "2026-09-27T10:00:00Z", "S-1", "ACCP"), "r1.xml");

        assertThat(summary).isEqualTo("status report R-1 for S-1 (LINKED)");
        Document file = col("files").find().first();
        Document status = file.get("status", Document.class);
        assertThat(status.getString("code")).isEqualTo("ACCP");
        assertThat(status.getString("level")).isEqualTo("GROUP");
        assertThat(status.getString("reportMsgId")).isEqualTo("R-1");
        assertThat(statusOf("batches", new Document()).getString("code")).isEqualTo("ACCP");
        assertThat(col("transactions").countDocuments(Filters.eq("status.code", "ACCP"))).isEqualTo(3);

        Document r = report("R-1");
        assertThat(r.getObjectId("fileId")).isEqualTo(file.getObjectId("_id"));
        assertThat(r.get("link", Document.class).getList("issues", Document.class)).isEmpty();
        assertThat(r.getObjectId("rawXmlRef")).isNotNull();
        assertThat(r.get("source", Document.class).getString("fileName")).isEqualTo("r1.xml");
    }

    @Test
    void aPartialReportOnlyChangesWhatItNames() {
        load(minimal("S-2", 3), "s2.xml");
        load(pain002("R-2", "2026-09-27T10:00:00Z", "S-2", "ACTC"), "r2a.xml");
        load(pain002("R-3", "2026-09-27T12:00:00Z", "S-2", "PART",
                pmtInf("S-2-B1", "PART",
                        tx("E2E-1", "ACSC", null, null),
                        tx("E2E-2", "RJCT", "AC04", "Account closed"))), "r2b.xml");

        assertThat(col("files").find().first().get("status", Document.class).getString("code")).isEqualTo("PART");
        assertThat(statusOf("batches", new Document()).getString("code")).isEqualTo("PART");
        assertThat(txStatus("E2E-1").getString("code")).isEqualTo("ACSC");
        Document rejected = txStatus("E2E-2");
        assertThat(rejected.getString("code")).isEqualTo("RJCT");
        assertThat(rejected.getString("level")).isEqualTo("TX");
        assertThat(rejected.getString("rsn")).isEqualTo("AC04");
        assertThat(rejected.getString("addtlInf")).isEqualTo("Account closed");
        // Not named in the PART report, so it keeps the earlier technical acceptance.
        assertThat(txStatus("E2E-3").getString("code")).isEqualTo("ACTC");

        Document r = report("R-3");
        assertThat(r.get("stats", Document.class).getList("txByStatus", Document.class))
                .extracting(d -> d.getString("sts") + "=" + d.getInteger("count")).containsExactly("ACSC=1", "RJCT=1");
    }

    @Test
    void aBatchStatusAppliesToItsTransactionsAndProprietaryReasonsAreKept() {
        load(minimal("S-3", 2), "s3.xml");
        load(pain002("R-4", "2026-09-27T10:00:00Z", "S-3", null, pmtInf("S-3-B1", "RJCT")), "r4.xml");
        assertThat(col("files").find().first().get("status")).isNull();
        assertThat(txStatus("E2E-2").getString("level")).isEqualTo("PMTINF");

        String prtry = pain002("R-5", "2026-09-27T11:00:00Z", "S-3", "RJCT")
                .replace("<GrpSts>RJCT</GrpSts>", "<GrpSts>RJCT</GrpSts><StsRsnInf><Rsn><Prtry>BANK-42</Prtry></Rsn></StsRsnInf>");
        load(prtry, "r5.xml");
        assertThat(col("files").find().first().get("status", Document.class).getString("rsn")).isEqualTo("BANK-42");
        assertThat(txStatus("E2E-1").get("addtlInf")).isNull();
    }

    @Test
    void anOlderReportNeverOverwritesANewerStatus() {
        load(minimal("S-4", 1), "s4.xml");
        load(pain002("R-6", "2026-09-27T12:00:00Z", "S-4", "ACSC"), "late.xml");
        load(pain002("R-7", "2026-09-27T08:00:00Z", "S-4", "ACTC"), "early.xml");

        assertThat(txStatus("E2E-1").getString("code")).isEqualTo("ACSC");
        assertThat(col("files").find().first().get("status", Document.class).getString("reportMsgId")).isEqualTo("R-6");
    }

    @Test
    void aReportThatArrivesFirstIsLinkedWhenItsFileIsLoaded() {
        String summary = load(pain002("R-8", "2026-09-27T12:00:00Z", "S-5", "RJCT"), "early.xml");
        assertThat(summary).endsWith("(UNMATCHED)");
        Document r = report("R-8");
        assertThat(r.get("fileId")).isNull();
        assertThat(r.get("link", Document.class).getList("issues", Document.class).get(0).getString("code"))
                .isEqualTo("UNKNOWN_ORIGINAL");

        load(minimal("S-5", 2), "s5.xml");

        r = report("R-8");
        assertThat(r.getObjectId("fileId")).isEqualTo(col("files").find().first().getObjectId("_id"));
        assertThat(r.get("link", Document.class).getString("status")).isEqualTo("LINKED");
        assertThat(txStatus("E2E-2").getString("code")).isEqualTo("RJCT");
    }

    @Test
    void relinkLeavesReportsWhoseFileIsStillMissing() {
        load(pain002("R-9", "2026-09-27T12:00:00Z", "NOT-HERE", "ACCP",
                pmtInf("X-B1", "ACCP", tx("E2E-1", "ACCP", null, null))), "r9.xml");
        StatusReportService service = new StatusReportService(mongo.db(), GridFSBuckets.create(mongo.db(), "rawXml"));
        assertThat(service.relink("NOT-HERE")).isZero();
        Document r = report("R-9");
        Document pmtInf = r.getList("orgnlPmtInfAndSts", Document.class).get(0);
        assertThat(pmtInf.containsKey("batchId")).isTrue();
        assertThat(pmtInf.get("batchId")).isNull();
        assertThat(pmtInf.getList("txInfAndSts", Document.class).get(0).get("txId")).isNull();
    }

    @Test
    void recordsWhatCouldNotBeMatched() {
        load(minimal("S-6", 2), "s6.xml");
        String report = pain002("R-10", "2026-09-27T12:00:00Z", "S-6", "PART",
                pmtInf("S-6-B1", "PART",
                        tx("E2E-9", "RJCT", null, null),
                        "<TxInfAndSts><TxSts>RJCT</TxSts></TxInfAndSts>",
                        "<TxInfAndSts><OrgnlEndToEndId>NOTPROVIDED</OrgnlEndToEndId><TxSts>RJCT</TxSts></TxInfAndSts>"),
                pmtInf("NO-SUCH-BATCH", "ACCP"))
                .replace("<OrgnlMsgNmId>pain.001.001.09</OrgnlMsgNmId>",
                        "<OrgnlMsgNmId>pain.001.001.09</OrgnlMsgNmId><OrgnlNbOfTxs>5</OrgnlNbOfTxs>");
        assertThat(load(report, "r10.xml")).endsWith("(PARTIAL)");

        Document link = report("R-10").get("link", Document.class);
        assertThat(link.getList("issues", Document.class)).extracting(d -> d.getString("code"))
                .containsExactly("COUNT_DIFFERS", "UNKNOWN_TX", "NO_TX_REFERENCE", "NO_TX_REFERENCE", "UNKNOWN_BATCH");
        assertThat(col("transactions").countDocuments(Filters.exists("status"))).isZero();
    }

    @Test
    void matchesTransactionsByUetrOrInstructionIdAndWarnsWhenAmbiguous() {
        String file = minimal("S-7", 3)
                .replace("<PmtId><EndToEndId>E2E-1</EndToEndId></PmtId>",
                        "<PmtId><InstrId>I-1</InstrId><EndToEndId>E2E-1</EndToEndId><UETR>0f8fad5b-d9cb-469f-a165-70867728950e</UETR></PmtId>")
                .replace("<PmtId><EndToEndId>E2E-2</EndToEndId></PmtId>", "<PmtId><InstrId>I-2</InstrId><EndToEndId>E2E-2</EndToEndId></PmtId>")
                .replace("<PmtId><EndToEndId>E2E-3</EndToEndId></PmtId>", "<PmtId><EndToEndId>E2E-2</EndToEndId></PmtId>");
        load(file, "s7.xml");
        load(pain002("R-11", "2026-09-27T12:00:00Z", "S-7", null, pmtInf("S-7-B1", null,
                "<TxInfAndSts><OrgnlUETR>0F8FAD5B-D9CB-469F-A165-70867728950E</OrgnlUETR><TxSts>ACSC</TxSts></TxInfAndSts>",
                "<TxInfAndSts><OrgnlInstrId>I-2</OrgnlInstrId><TxSts>RJCT</TxSts></TxInfAndSts>")), "r11.xml");

        assertThat(statusOf("transactions", new Document("pmtId.instrId", "I-1")).getString("code")).isEqualTo("ACSC");
        assertThat(statusOf("transactions", new Document("pmtId.instrId", "I-2")).getString("code")).isEqualTo("RJCT");

        // EndToEndId E2E-2 is on two transactions; the report links to the first.
        load(pain002("R-12", "2026-09-27T13:00:00Z", "S-7", null, pmtInf("S-7-B1", null,
                "<TxInfAndSts><OrgnlEndToEndId>E2E-2</OrgnlEndToEndId><TxSts>ACCC</TxSts></TxInfAndSts>")), "r12.xml");
        Document link = report("R-12").get("link", Document.class);
        assertThat(link.getString("status")).isEqualTo("LINKED");
        assertThat(link.getList("issues", Document.class).get(0).getString("code")).isEqualTo("AMBIGUOUS_TX");
        assertThat(statusOf("transactions", new Document("seq", 1)).getString("code")).isEqualTo("ACCC");
    }

    @Test
    void anEndToEndIdAndInstructionIdMustBothMatchAndMissingPmtInfIdSearchesTheWholeFile() {
        load(minimal("S-8", 2).replace("<PmtId><EndToEndId>E2E-1</EndToEndId></PmtId>",
                "<PmtId><InstrId>I-1</InstrId><EndToEndId>E2E-1</EndToEndId></PmtId>"), "s8.xml");
        Document report = Pain002Mapper.map(bytes(pain002("R-13", "2026-09-27T12:00:00Z", "S-8", null, pmtInf("S-8-B1", null,
                "<TxInfAndSts><OrgnlInstrId>I-1</OrgnlInstrId><OrgnlEndToEndId>E2E-1</OrgnlEndToEndId><TxSts>ACSC</TxSts></TxInfAndSts>"))),
                com.paymentsui.support.Samples.SOURCE);
        // Without OrgnlPmtInfId the transaction is looked for across the whole file.
        report.getList("orgnlPmtInfAndSts", Document.class).get(0).remove("orgnlPmtInfId");
        StatusReportService service = new StatusReportService(mongo.db(), GridFSBuckets.create(mongo.db(), "rawXml"));
        service.link(report);
        Document pmtInf = report.getList("orgnlPmtInfAndSts", Document.class).get(0);
        assertThat(pmtInf.get("batchId")).isNull();
        assertThat(pmtInf.getList("txInfAndSts", Document.class).get(0).getObjectId("txId")).isNotNull();

        // A report without CreDtTm (not valid ISO, but possible) is dated by its arrival.
        report.remove("creDtTm");
        service.apply(report);
        assertThat(txStatus("E2E-1").getDate("at")).isEqualTo(java.util.Date.from(com.paymentsui.support.Samples.SOURCE.receivedAt()));
    }

    @Test
    void picksTheOriginalByCreationTimeWhenTwoPartiesReuseAMsgId() {
        load(minimal("S-9", 1), "a.xml");
        load(minimal("S-9", 2).replace("Minimal Ltd", "Other Ltd").replace("2026-09-27T09:00:00Z", "2026-09-26T09:00:00Z"), "b.xml");
        ObjectId other = col("files").find(Filters.eq("initgPty.nm", "Other Ltd")).first().getObjectId("_id");

        load(pain002("R-14", "2026-09-27T12:00:00Z", "S-9", "ACCP").replace("<OrgnlMsgNmId>pain.001.001.09</OrgnlMsgNmId>",
                "<OrgnlMsgNmId>pain.001.001.09</OrgnlMsgNmId><OrgnlCreDtTm>2026-09-26T09:00:00Z</OrgnlCreDtTm>"), "r14.xml");
        assertThat(report("R-14").getObjectId("fileId")).isEqualTo(other);

        // Without OrgnlCreDtTm the most recently received one wins.
        load(pain002("R-15", "2026-09-27T12:00:00Z", "S-9", "ACCP"), "r15.xml");
        assertThat(report("R-15").getObjectId("fileId")).isEqualTo(other);
    }

    @Test
    void rejectsDuplicateReports() {
        load(minimal("S-10", 1), "s10.xml");
        String xml = pain002("R-16", "2026-09-27T12:00:00Z", "S-10", "ACCP");
        load(xml, "r16.xml");
        assertThatThrownBy(() -> load(xml, "again.xml"))
                .isInstanceOf(IngestException.class).hasMessageContaining("identical content");
        assertThatThrownBy(() -> load(xml.replace("ACCP", "ACSC"), "changed.xml"))
                .isInstanceOf(IngestException.class).hasMessageContaining("Duplicate status report MsgId R-16 for original message S-10");
    }

    @Test
    void removesTheStoredXmlWhenTheReportCannotBeSaved() {
        col("statusReports").createIndex(Indexes.ascending("source.fileName"), new IndexOptions().unique(true));
        load(pain002("R-17", "2026-09-27T12:00:00Z", "S-11", "ACCP"), "same.xml");
        assertThatThrownBy(() -> load(pain002("R-18", "2026-09-27T12:00:00Z", "S-11", "ACCP"), "same.xml"))
                .isInstanceOf(IngestException.class).hasMessageContaining("Duplicate status report:");
        assertThat(col("rawXml.files").countDocuments()).isEqualTo(1);
    }

    @Test
    @SuppressWarnings("unchecked")
    void rethrowsOtherStorageFailures() {
        MongoDatabase db = spy(mongo.db());
        MongoCollection<Document> reports = spy(mongo.db().getCollection("statusReports"));
        when(db.getCollection("statusReports")).thenReturn(reports);
        doThrow(new IllegalStateException("disk full")).when(reports).insertOne(any(Document.class));
        StatusReportService service = new StatusReportService(db, GridFSBuckets.create(mongo.db(), "rawXml"));

        assertThatThrownBy(() -> service.ingest(bytes(pain002("R-19", "2026-09-27T12:00:00Z", "S-12", "ACCP")), "x.xml", "test"))
                .isInstanceOf(IllegalStateException.class).hasMessage("disk full");
        assertThat(col("rawXml.files").countDocuments()).isZero();
    }

    @Test
    void refusesOtherMessagesAndReportsWithoutAnOriginalMessageId() {
        assertThatThrownBy(() -> Pain002Mapper.map(bytes(minimal("S-13", 1)), com.paymentsui.support.Samples.SOURCE))
                .isInstanceOf(IngestException.class).hasMessageContaining("Not a pain.002.001.10 message");
        String noOriginal = """
                <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.002.001.10"><CstmrPmtStsRpt>
                <GrpHdr><MsgId>R</MsgId><CreDtTm>2026-09-27T12:00:00Z</CreDtTm></GrpHdr>
                </CstmrPmtStsRpt></Document>""";
        assertThatThrownBy(() -> load(noOriginal, "bad.xml"))
                .isInstanceOf(IngestException.class).hasMessageContaining("OrgnlGrpInfAndSts/OrgnlMsgId");
        assertThatThrownBy(() -> load("<Document xmlns=\"urn:iso:std:iso:20022:tech:xsd:pain.002.001.10\"/>", "empty.xml"))
                .isInstanceOf(IngestException.class);
    }

    @Test
    void theLoaderAlsoTakesPaymentFiles() {
        assertThat(load(minimal("S-14", 2), "s14.xml")).isEqualTo("file S-14 (2 transactions, VALID)");
        assertThat(List.of(col("files").countDocuments())).containsExactly(1L);
    }
}
