package com.paymentsui.ingest;

import static com.paymentsui.support.Samples.map;
import static com.paymentsui.support.Samples.minimal;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.bson.Document;
import org.bson.types.Decimal128;
import org.junit.jupiter.api.Test;

import com.paymentsui.support.Samples;

/** Edge cases of the pain.001 to document mapping, each built from a minimal message. */
class Pain001MapperEdgeCaseTest {

    private static Document view(Pain001Mapper.Mapped m, int tx) {
        return m.transactions().get(tx).get("view", Document.class);
    }

    private static List<String> codes(Document withValidation) {
        return withValidation.get("validation", Document.class).getList("issues", Document.class)
                .stream().map(d -> d.getString("code")).toList();
    }

    private static String status(Document withValidation) {
        return withValidation.get("validation", Document.class).getString("status");
    }

    @Test
    void minimalMessageIsValidAndFullyLinked() {
        Pain001Mapper.Mapped m = map(minimal("MIN-1", 2));
        Document file = m.file();
        assertThat(status(file)).isEqualTo("VALID");
        assertThat(file.getInteger("nbOfTxs")).isEqualTo(2);
        assertThat(file.get("source", Document.class).getString("channel")).isEqualTo("test");
        assertThat(file.get("source", Document.class).getLong("sizeBytes")).isPositive();
        Document batch = m.batches().getFirst();
        assertThat(batch.get("reqdExctnDt", Document.class).getBoolean("hasTime")).isFalse();
        assertThat(batch.get("stats", Document.class).getList("totalsByCcy", Document.class))
                .singleElement().satisfies(t -> {
                    assertThat(t.getString("ccy")).isEqualTo("EUR");
                    assertThat(t.get("amount")).isEqualTo(new Decimal128(new BigDecimal("2.00")));
                    assertThat(t.getInteger("count")).isEqualTo(2);
                });
        Document v = view(m, 0);
        assertThat(v.getString("initgPtyNm")).isEqualTo("Minimal Ltd");
        assertThat(v.getDate("creDtTm").toInstant().toString()).isEqualTo("2026-09-27T09:00:00Z");
        assertThat(v.getDate("receivedAt")).isEqualTo(java.util.Date.from(Samples.SOURCE.receivedAt()));
        assertThat(v.getString("pmtMtd")).isEqualTo("TRF");
        assertThat(v.getString("dbtrBic")).isEqualTo("NWBKGB2L");
        assertThat(v).doesNotContainKeys("cdtrBic", "rmtInf");
    }

    @Test
    void equivalentAmountsAndMissingCurrencies() {
        String xml = minimal("MIN-2", 3)
                .replaceFirst("<InstdAmt Ccy=\"EUR\">1.00</InstdAmt>",
                        "<EqvtAmt><Amt Ccy=\"USD\">2.50</Amt><CcyOfTrf>EUR</CcyOfTrf></EqvtAmt>")
                .replaceFirst("<InstdAmt Ccy=\"EUR\">1.00</InstdAmt>", "<InstdAmt>3.00</InstdAmt>");
        Pain001Mapper.Mapped m = map(xml);

        assertThat(view(m, 0).getString("ccy")).isEqualTo("USD");
        assertThat(view(m, 0).get("amount")).isEqualTo(new Decimal128(new BigDecimal("2.50")));
        assertThat(m.file().get("stats", Document.class).getList("totalsByCcy", Document.class))
                .extracting(d -> d.getString("ccy")).containsExactly("???", "EUR", "USD");
    }

    @Test
    void transactionsWithoutAmountOrIdentifiersStillLoad() {
        String xml = minimal("MIN-3", 2)
                .replaceFirst("<Amt><InstdAmt Ccy=\"EUR\">1.00</InstdAmt></Amt>", "")
                .replaceFirst("<PmtId><EndToEndId>E2E-2</EndToEndId></PmtId>", "")
                .replaceFirst("(?s)<Amt><InstdAmt Ccy=\"EUR\">1.00</InstdAmt></Amt>", "<Amt></Amt>");
        Pain001Mapper.Mapped m = map(xml);

        assertThat(view(m, 0)).doesNotContainKeys("amount", "ccy");
        assertThat(view(m, 1)).doesNotContainKeys("amount", "ccy");
        assertThat(m.transactions().get(1)).doesNotContainKey("pmtId");
    }

    @Test
    void executionDateTimeAndMissingDate() {
        Document withTime = map(minimal("MIN-4", 1).replace("<Dt>2026-09-28</Dt>", "<DtTm>2026-09-28T08:00:00Z</DtTm>"))
                .batches().getFirst().get("reqdExctnDt", Document.class);
        assertThat(withTime.getBoolean("hasTime")).isTrue();
        assertThat(withTime.getDate("date").toInstant().toString()).isEqualTo("2026-09-28T08:00:00Z");

        Pain001Mapper.Mapped noDate = map(minimal("MIN-5", 1).replace("<ReqdExctnDt><Dt>2026-09-28</Dt></ReqdExctnDt>", ""));
        assertThat(noDate.batches().getFirst().get("reqdExctnDt", Document.class).get("date")).isNull();
        assertThat(view(noDate, 0)).doesNotContainKey("reqdExctnDt");

        Pain001Mapper.Mapped emptyChoice = map(minimal("MIN-6", 1).replace("<Dt>2026-09-28</Dt>", ""));
        assertThat(emptyChoice.batches().getFirst().get("reqdExctnDt", Document.class).get("date")).isNull();
    }

    @Test
    void warnsAboutPastExecutionDatesAndDuplicateEndToEndIds() {
        Pain001Mapper.Mapped past = map(minimal("MIN-7", 1).replace("<Dt>2026-09-28</Dt>", "<Dt>2026-09-01</Dt>"));
        assertThat(status(past.file())).isEqualTo("WARN");
        assertThat(codes(past.batches().getFirst())).containsExactly("PAST_EXECUTION_DATE");

        Pain001Mapper.Mapped dup = map(minimal("MIN-8", 3).replace("E2E-2", "E2E-1"));
        assertThat(codes(dup.file())).containsExactly("DUPLICATE_E2E");

        Pain001Mapper.Mapped notProvided = map(minimal("MIN-9", 2).replaceAll("E2E-\\d", "NOTPROVIDED"));
        assertThat(status(notProvided.file())).isEqualTo("VALID");

        Pain001Mapper.Mapped noCreated = map(minimal("MIN-10", 1)
                .replace("<CreDtTm>2026-09-27T09:00:00Z</CreDtTm>", "").replace("2026-09-28", "2000-01-01"));
        assertThat(codes(noCreated.file())).doesNotContain("PAST_EXECUTION_DATE");
        assertThat(view(noCreated, 0)).doesNotContainKey("creDtTm");
    }

    @Test
    void flagsBadCountsAndControlSums() {
        Pain001Mapper.Mapped bad = map(minimal("MIN-11", 2)
                .replaceFirst("<NbOfTxs>2</NbOfTxs>", "<NbOfTxs>two</NbOfTxs>")
                .replace("<PmtMtd>TRF</PmtMtd>", "<PmtMtd>TRF</PmtMtd><CtrlSum>9.99</CtrlSum>"));
        assertThat(status(bad.file())).isEqualTo("INVALID");
        assertThat(codes(bad.file())).containsExactlyInAnyOrder("BAD_NB_OF_TXS", "CTRL_SUM_MISMATCH");
        assertThat(bad.file().get("nbOfTxs")).isNull();
    }

    @Test
    void handlesSparsePartiesAccountsAndAgents() {
        String xml = minimal("MIN-12", 3)
                .replace("<InitgPty><Nm>Minimal Ltd</Nm></InitgPty>", "")
                .replace("<PmtMtd>TRF</PmtMtd>", "")
                .replace("<DbtrAgt><FinInstnId><BICFI>NWBKGB2L</BICFI></FinInstnId></DbtrAgt>",
                        "<DbtrAgt><BrnchId><Id>001</Id></BrnchId></DbtrAgt>")
                .replaceFirst("<IBAN>DE89370400440532013000</IBAN>", "<Othr><Id>ACC-1</Id></Othr>")
                .replaceFirst("<CdtrAcct><Id><IBAN>DE89370400440532013000</IBAN></Id></CdtrAcct>", "<CdtrAcct><Nm>No id</Nm></CdtrAcct>")
                .replaceFirst("<Cdtr><Nm>Creditor 3</Nm></Cdtr>", "")
                .replaceFirst("<CdtrAcct><Id><IBAN>DE89370400440532013000</IBAN></Id></CdtrAcct>",
                        "<CdtrAcct><Id></Id></CdtrAcct><CdtrAgt><BrnchId><Id>9</Id></BrnchId></CdtrAgt><RmtInf><Strd/></RmtInf>");
        Pain001Mapper.Mapped m = map(xml);

        assertThat(m.file()).doesNotContainKey("initgPty");
        assertThat(view(m, 0).getString("cdtrAcct")).isEqualTo("ACC-1");
        assertThat(view(m, 0)).doesNotContainKeys("initgPtyNm", "pmtMtd", "dbtrBic");
        assertThat(view(m, 1)).doesNotContainKey("cdtrAcct");
        assertThat(view(m, 2)).doesNotContainKeys("cdtrNm", "cdtrAcct", "cdtrBic", "rmtInf");
    }

    @Test
    void rejectsWhatIsNotAPain001V09Message() {
        assertThatThrownBy(() -> map("<Document/>")).isInstanceOf(IngestException.class)
                .hasMessageContaining("namespace");
        assertThatThrownBy(() -> map("<x>" + Pain001Mapper.NAMESPACE + "</x>")).isInstanceOf(IngestException.class)
                .hasMessageContaining("Could not parse");
        String noBatches = minimal("MIN-13", 1).replaceAll("(?s)<PmtInf>.*</PmtInf>", "");
        assertThatThrownBy(() -> map(noBatches)).isInstanceOf(IngestException.class);
        String noHeader = minimal("MIN-14", 1).replaceAll("(?s)<GrpHdr>.*</GrpHdr>", "");
        assertThatThrownBy(() -> map(noHeader)).isInstanceOf(IngestException.class);
    }

    @Test
    void hashesContent() {
        assertThat(Pain001Mapper.sha256("abc".getBytes(StandardCharsets.UTF_8)))
                .isEqualTo("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    }
}
