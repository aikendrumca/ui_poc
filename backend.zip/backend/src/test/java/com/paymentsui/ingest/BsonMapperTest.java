package com.paymentsui.ingest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.xml.datatype.DatatypeFactory;

import org.bson.Document;
import org.bson.types.Decimal128;
import org.junit.jupiter.api.Test;

class BsonMapperTest {

    /** Mirrors a JAXB code list: the XML value comes from value(). */
    enum Coded {
        TRF;

        public String value() {
            return "TRF-CODE";
        }
    }

    enum Plain {
        SLEV
    }

    /** value() that does not return a String falls back to the constant name. */
    enum OddValue {
        X;

        public Integer value() {
            return 1;
        }
    }

    static class Base {
        protected String inherited = "from-base";
    }

    static class Inner {
        protected String nm;

        Inner(String nm) {
            this.nm = nm;
        }
    }

    @SuppressWarnings("unused")
    static class Sample extends Base {
        static final String CONSTANT = "ignored";
        protected transient String cache = "ignored";
        protected String text = "hello";
        protected String empty = "";
        protected String missing;
        protected Boolean flag = true;
        protected Integer count = 3;
        protected Long big = 5L;
        protected BigDecimal amount = new BigDecimal("12.34");
        protected BigInteger whole = BigInteger.TEN;
        protected LocalDate date = LocalDate.of(2026, 9, 27);
        protected LocalDateTime dateTime = LocalDateTime.of(2026, 9, 27, 10, 30);
        protected OffsetDateTime offsetDateTime = OffsetDateTime.of(2026, 9, 27, 10, 30, 0, 0, ZoneOffset.ofHours(2));
        protected LocalTime time = LocalTime.of(10, 30);
        protected OffsetTime offsetTime = OffsetTime.of(10, 30, 0, 0, ZoneOffset.UTC);
        protected byte[] bytes = {1, 2};
        protected Coded coded = Coded.TRF;
        protected Plain plain = Plain.SLEV;
        protected OddValue odd = OddValue.X;
        protected List<Object> list = new ArrayList<>(Arrays.asList("a", null, "", new Inner("b")));
        protected List<String> emptyList = new ArrayList<>();
        protected List<String> onlyEmpty = new ArrayList<>(List.of(""));
        protected Inner nested = new Inner("n");
        protected Inner emptyNested = new Inner(null);
    }

    @Test
    void mapsEveryValueType() throws Exception {
        Document d = BsonMapper.toDocument(new Sample());

        assertThat(d.getString("text")).isEqualTo("hello");
        assertThat(d.getString("inherited")).isEqualTo("from-base");
        assertThat(d).doesNotContainKeys("CONSTANT", "cache", "empty", "missing", "emptyList", "onlyEmpty", "emptyNested");
        assertThat(d.getBoolean("flag")).isTrue();
        assertThat(d.getInteger("count")).isEqualTo(3);
        assertThat(d.getLong("big")).isEqualTo(5L);
        assertThat(d.get("amount")).isEqualTo(new Decimal128(new BigDecimal("12.34")));
        assertThat(d.get("whole")).isEqualTo(new Decimal128(BigDecimal.TEN));
        assertThat(d.getDate("date")).isEqualTo(Date.from(LocalDate.of(2026, 9, 27).atStartOfDay(ZoneOffset.UTC).toInstant()));
        assertThat(d.getDate("dateTime").toInstant().toString()).isEqualTo("2026-09-27T10:30:00Z");
        assertThat(d.getDate("offsetDateTime").toInstant().toString()).isEqualTo("2026-09-27T08:30:00Z");
        assertThat(d.getString("time")).isEqualTo("10:30");
        assertThat(d.getString("offsetTime")).isEqualTo("10:30Z");
        assertThat((byte[]) d.get("bytes")).containsExactly(1, 2);
        assertThat(d.getString("coded")).isEqualTo("TRF-CODE");
        assertThat(d.getString("plain")).isEqualTo("SLEV");
        assertThat(d.getString("odd")).isEqualTo("X");
        assertThat(d.getList("list", Object.class)).containsExactly("a", new Document("nm", "b"));
        assertThat(d.get("nested", Document.class).getString("nm")).isEqualTo("n");
    }

    @Test
    void convertsXmlCalendarsAndHonoursExclusions() throws Exception {
        var cal = DatatypeFactory.newInstance().newXMLGregorianCalendar("2026-09-27T10:30:00Z");
        assertThat(((Date) BsonMapper.convert(cal)).toInstant().toString()).isEqualTo("2026-09-27T10:30:00Z");

        Document d = BsonMapper.toDocument(new Sample(), Set.of("text", "nested"));
        assertThat(d).doesNotContainKeys("text", "nested").containsKey("flag");
    }

    @Test
    void cachesFieldsPerClass() {
        assertThat(BsonMapper.toDocument(new Inner("x"))).isEqualTo(new Document("nm", "x"));
        assertThat(BsonMapper.toDocument(new Inner("y"))).isEqualTo(new Document("nm", "y"));
    }

    @Test
    void failsLoudlyOnClassesThatCannotBeOpened() {
        // JDK-internal fields are closed to reflection by the module system.
        assertThatThrownBy(() -> BsonMapper.toDocument(new StringBuilder("x")))
                .isInstanceOf(RuntimeException.class);
    }
}
