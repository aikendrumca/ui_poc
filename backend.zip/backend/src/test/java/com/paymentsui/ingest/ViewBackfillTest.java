package com.paymentsui.ingest;

import static com.paymentsui.support.Samples.bytes;
import static com.paymentsui.support.Samples.minimal;
import static org.assertj.core.api.Assertions.assertThat;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.paymentsui.support.InMemoryMongo;

class ViewBackfillTest {

    @RegisterExtension
    InMemoryMongo mongo = new InMemoryMongo();

    private MongoCollection<Document> txs() {
        return mongo.db().getCollection("transactions");
    }

    private void stripViewFields() {
        txs().updateMany(new Document(),
                Updates.combine(Updates.unset("view.initgPtyNm"), Updates.unset("view.creDtTm"), Updates.unset("view.receivedAt")));
    }

    @Test
    void copiesPartyAndFileTimesOntoOlderTransactions() {
        IngestService ingest = new IngestService(mongo.db());
        ingest.ingest(bytes(minimal("BF-1", 3)), "a.xml", "test");
        ingest.ingest(bytes(minimal("BF-2", 2).replace("<InitgPty><Nm>Minimal Ltd</Nm></InitgPty>", "<InitgPty/>")), "b.xml", "test");
        stripViewFields();

        new ViewBackfill(mongo.db()).run();

        assertThat(txs().countDocuments(Filters.exists("view.receivedAt", false))).isZero();
        assertThat(txs().countDocuments(Filters.eq("view.initgPtyNm", "Minimal Ltd"))).isEqualTo(3);
        assertThat(txs().countDocuments(Filters.exists("view.creDtTm"))).isEqualTo(5);
    }

    @Test
    void doesNothingWhenEveryTransactionIsCurrent() {
        new IngestService(mongo.db()).ingest(bytes(minimal("BF-3", 1)), "c.xml", "test");
        Document before = txs().find().first();

        new ViewBackfill(mongo.db()).run();

        assertThat(txs().find().first()).isEqualTo(before);
    }
}
