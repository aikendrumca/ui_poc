package com.paymentsui.ingest;

import static com.paymentsui.support.Samples.bytes;
import static com.paymentsui.support.Samples.minimal;
import static com.paymentsui.support.Samples.xml;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.mockito.Answers;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.model.Indexes;
import com.paymentsui.support.InMemoryMongo;

class IngestServiceTest {

    @RegisterExtension
    InMemoryMongo mongo = new InMemoryMongo();

    @Test
    void storesFileBatchesTransactionsAndOriginalXml() {
        IngestService service = new IngestService(mongo.db());
        IngestService.Result r = service.ingest(bytes(xml("ING-1")), "ing-1.xml", "test");

        assertThat(r.msgId()).isEqualTo("ING-1");
        assertThat(r.validationStatus()).isEqualTo("VALID");
        assertThat(mongo.db().getCollection("files").countDocuments()).isEqualTo(1);
        assertThat(mongo.db().getCollection("batches").countDocuments(Filters.eq("fileId", r.fileId()))).isEqualTo(r.batches());
        assertThat(mongo.db().getCollection("transactions").countDocuments(Filters.eq("fileId", r.fileId()))).isEqualTo(r.transactions());
        Document file = mongo.db().getCollection("files").find().first();
        assertThat(file.getObjectId("rawXmlRef")).isNotNull();
        assertThat(mongo.db().getCollection("rawXml.files").countDocuments()).isEqualTo(1);
    }

    @Test
    void insertsLargeFilesInChunks() {
        IngestService.Result r = new IngestService(mongo.db()).ingest(bytes(minimal("ING-BIG", 1_205)), "big.xml", "test");
        assertThat(r.transactions()).isEqualTo(1_205);
        assertThat(mongo.db().getCollection("transactions").countDocuments()).isEqualTo(1_205);
    }

    @Test
    void rejectsIdenticalContentAndRepeatedMessageIds() {
        IngestService service = new IngestService(mongo.db());
        service.ingest(bytes(minimal("ING-2", 1)), "a.xml", "test");

        assertThatThrownBy(() -> service.ingest(bytes(minimal("ING-2", 1)), "again.xml", "test"))
                .isInstanceOf(IngestException.class).hasMessageContaining("identical content");
        // Same MsgId and initiating party, different content.
        assertThatThrownBy(() -> service.ingest(bytes(minimal("ING-2", 2)), "b.xml", "test"))
                .isInstanceOf(IngestException.class).hasMessageContaining("Duplicate MsgId ING-2");
        // Without an initiating party name the MsgId check still applies.
        String nameless = minimal("ING-3", 1).replace("<InitgPty><Nm>Minimal Ltd</Nm></InitgPty>", "<InitgPty/>");
        service.ingest(bytes(nameless), "c.xml", "test");
        assertThatThrownBy(() -> service.ingest(bytes(nameless.replace("E2E-1", "E2E-X")), "d.xml", "test"))
                .isInstanceOf(IngestException.class).hasMessageContaining("Duplicate MsgId ING-3");
    }

    @Test
    void rollsBackEverythingWhenTheFileInsertHitsAUniqueIndex() {
        MongoDatabase db = mongo.db();
        db.getCollection("files").createIndex(Indexes.ascending("source.fileName"), new IndexOptions().unique(true));
        IngestService service = new IngestService(db);
        service.ingest(bytes(minimal("ING-4", 1)), "same-name.xml", "test");

        assertThatThrownBy(() -> service.ingest(bytes(minimal("ING-5", 3)), "same-name.xml", "test"))
                .isInstanceOf(IngestException.class).hasMessageContaining("Duplicate file");
        assertThat(db.getCollection("files").countDocuments()).isEqualTo(1);
        assertThat(db.getCollection("batches").countDocuments()).isEqualTo(1);
        assertThat(db.getCollection("transactions").countDocuments()).isEqualTo(1);
        assertThat(db.getCollection("rawXml.files").countDocuments()).isEqualTo(1);
    }

    @Test
    @SuppressWarnings("unchecked")
    void rethrowsOtherFailuresAndSurvivesAFailedRollback() {
        MongoDatabase db = mock(MongoDatabase.class, Answers.RETURNS_DEEP_STUBS);
        MongoCollection<Document> broken = mock(MongoCollection.class, Answers.RETURNS_DEEP_STUBS);
        when(db.getCollection(anyString())).thenReturn(broken);
        when(broken.find(any(org.bson.conversions.Bson.class)).first()).thenReturn(null);
        when(broken.insertMany(any())).thenThrow(new IllegalStateException("disk full"));
        when(broken.insertMany(any(java.util.List.class), any(com.mongodb.client.model.InsertManyOptions.class))).thenThrow(new IllegalStateException("disk full"));
        when(broken.deleteMany(any())).thenThrow(new IllegalStateException("still down"));
        IngestService service = new IngestService(db);

        assertThatThrownBy(() -> service.ingest(bytes(minimal("ING-6", 1)), "x.xml", "test"))
                .isInstanceOf(IllegalStateException.class).hasMessage("disk full");
    }
}
