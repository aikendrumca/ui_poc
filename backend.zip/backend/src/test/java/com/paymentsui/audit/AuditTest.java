package com.paymentsui.audit;

import static com.paymentsui.support.Samples.bytes;
import static com.paymentsui.support.Samples.minimal;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bson.Document;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Sorts;
import com.paymentsui.api.PaymentsController;
import com.paymentsui.api.StatusReportsController;
import com.paymentsui.ingest.IngestService;
import com.paymentsui.support.InMemoryMongo;

/** API calls and UI events end up in auditLog with the source IP, client ids and a user id placeholder. */
class AuditTest {

    @RegisterExtension
    InMemoryMongo mongo = new InMemoryMongo();

    IngestService.Result file;

    @BeforeEach
    void load() {
        file = new IngestService(mongo.db()).ingest(bytes(minimal("AUD-1", 2)), "aud-1.xml", "test");
    }

    private MockMvc mvc(AuditService audit, boolean apiRequests) {
        return MockMvcBuilders.standaloneSetup(new PaymentsController(mongo.db()), new StatusReportsController(mongo.db()),
                new AuditController(audit)).addFilters(new AuditFilter(audit, apiRequests)).build();
    }

    private MockMvc mvc() {
        return mvc(new AuditService(mongo.db(), UserResolver.remoteUser(), true), true);
    }

    private List<Document> entries() {
        return mongo.db().getCollection(AuditService.COLLECTION).find().sort(Sorts.ascending("at", "_id")).into(new ArrayList<>());
    }

    private Document only() {
        List<Document> all = entries();
        assertThat(all).hasSize(1);
        return all.get(0);
    }

    // ---- API requests --------------------------------------------------

    @Test
    void anApiCallIsLoggedWithItsTargetOutcomeAndEveryClientIdentifier() throws Exception {
        String id = file.fileId().toHexString();
        mvc().perform(get("/api/files/" + id)
                        .header("X-Client-Id", "client-1")
                        .header("X-Session-Id", "session-1")
                        .header("X-Request-Id", "req-1")
                        .header("X-Forwarded-For", "203.0.113.7, 10.0.0.2")
                        .header("X-Real-IP", "10.0.0.2")
                        .header("User-Agent", "JUnit")
                        .header("Referer", "http://localhost:3000/files")
                        .header("Origin", "http://localhost:3000")
                        .header("Accept-Language", "en-GB"))
                .andExpect(status().isOk())
                .andExpect(header().string("X-Request-Id", "req-1"));

        Document e = only();
        assertThat(e.getString("source")).isEqualTo("api");
        assertThat(e.getString("action")).isEqualTo("file.view");
        assertThat(e.containsKey("userId")).isTrue();
        assertThat(e.get("userId")).isNull();
        assertThat(e.get("target", Document.class)).isEqualTo(new Document("type", "file").append("id", id));
        Document client = e.get("client", Document.class);
        assertThat(client.getString("ip")).isEqualTo("203.0.113.7");
        assertThat(client.getString("remoteAddr")).isEqualTo("127.0.0.1");
        assertThat(client.getList("forwardedFor", String.class)).containsExactly("203.0.113.7", "10.0.0.2");
        assertThat(client.getString("realIp")).isEqualTo("10.0.0.2");
        assertThat(client.getString("clientId")).isEqualTo("client-1");
        assertThat(client.getString("sessionId")).isEqualTo("session-1");
        assertThat(client.getString("requestId")).isEqualTo("req-1");
        assertThat(client.getString("userAgent")).isEqualTo("JUnit");
        assertThat(client.getString("referer")).isEqualTo("http://localhost:3000/files");
        assertThat(client.getString("origin")).isEqualTo("http://localhost:3000");
        assertThat(client.getString("acceptLanguage")).isEqualTo("en-GB");
        Document request = e.get("request", Document.class);
        assertThat(request.getString("method")).isEqualTo("GET");
        assertThat(request.getString("route")).isEqualTo("/api/files/{id}");
        assertThat(request.getInteger("status")).isEqualTo(200);
        assertThat(request.getLong("durationMs")).isNotNegative();
    }

    @Test
    void listFiltersAreKeptAndARequestIdIsIssuedWhenTheCallerSentNone() throws Exception {
        String rid = mvc().perform(get("/api/transactions?party=Minimal Ltd&ccy=EUR&ccy=GBP&$where=1&a.b=2")
                        .header("X-Client-Id", "not an id!"))
                .andExpect(status().isOk()).andReturn().getResponse().getHeader("X-Request-Id");

        Document e = only();
        assertThat(e.getString("action")).isEqualTo("transactions.list");
        assertThat(e.containsKey("target")).isFalse();
        assertThat(e.get("details", Document.class)).isEqualTo(new Document("party", "Minimal Ltd").append("ccy", List.of("EUR", "GBP")));
        Document client = e.get("client", Document.class);
        assertThat(client.getString("ip")).isEqualTo("127.0.0.1");
        assertThat(client.containsKey("forwardedFor")).isFalse();
        assertThat(client.containsKey("clientId")).isFalse();
        assertThat(client.getString("requestId")).isEqualTo(rid).hasSize(36);
    }

    @Test
    void failedAndUnknownCallsAreLoggedToo() throws Exception {
        MockMvc mvc = mvc();
        mvc.perform(get("/api/reports/not-an-id")).andExpect(status().isNotFound());
        mvc.perform(get("/api/nothing-here")).andExpect(status().isNotFound());

        List<Document> all = entries();
        assertThat(all).extracting(d -> d.getString("action")).containsExactly("report.view", "api.request");
        assertThat(all.get(0).get("request", Document.class).getInteger("status")).isEqualTo(404);
        assertThat(all.get(0).get("target", Document.class).getString("type")).isEqualTo("report");
        assertThat(all.get(1).containsKey("target")).isFalse();
    }

    @Test
    void routesWithoutAnIdHaveNoTargetAndUnlistedRoutesAreGeneric() throws Exception {
        MockMvc mvc = mvc();
        mvc.perform(get("/api/summary")).andExpect(status().isOk());
        mvc.perform(get("/api/files/" + file.fileId() + "/graph")).andExpect(status().isOk());
        assertThat(entries()).extracting(d -> d.getString("action")).containsExactly("summary.view", "file.graph");
        assertThat(AuditFilter.ACTIONS).hasSize(16);
    }

    @Test
    void theForwardedAddressIsOnlyUsedWhenTrusted() throws Exception {
        mvc(new AuditService(mongo.db(), UserResolver.remoteUser(), false), true)
                .perform(get("/api/parties").header("X-Forwarded-For", "198.51.100.1")).andExpect(status().isOk());
        Document client = only().get("client", Document.class);
        assertThat(client.getString("ip")).isEqualTo("127.0.0.1");
        assertThat(client.getList("forwardedFor", String.class)).containsExactly("198.51.100.1");
    }

    @Test
    void apiLoggingCanBeSwitchedOff() throws Exception {
        mvc(new AuditService(mongo.db(), UserResolver.remoteUser(), true), false)
                .perform(get("/api/summary")).andExpect(status().isOk());
        assertThat(entries()).isEmpty();
    }

    @Test
    void theUserIdComesFromTheResolverOnceSignInExists() throws Exception {
        mvc().perform(get("/api/summary").with(r -> {
            r.setRemoteUser("bear");
            return r;
        })).andExpect(status().isOk());
        assertThat(only().getString("userId")).isEqualTo("bear");

        AuditService custom = new AuditService(mongo.db(), r -> "user-42", true);
        assertThat(custom.entry(new MockHttpServletRequest(), "ui", "x").getString("userId")).isEqualTo("user-42");

        // Spring's constructor falls back to the remote user when no resolver bean exists.
        AuditService spring = new AuditService(mongo.db(), new DefaultListableBeanFactory().getBeanProvider(UserResolver.class), true);
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRemoteUser("alice");
        assertThat(spring.entry(request, "ui", "x").getString("userId")).isEqualTo("alice");
    }

    // ---- UI events -----------------------------------------------------

    private String postEvents(MockMvc mvc, String json, String... headers) throws Exception {
        var req = post("/api/audit/events").contentType(MediaType.APPLICATION_JSON).content(json);
        for (int i = 0; i < headers.length; i += 2) {
            req.header(headers[i], headers[i + 1]);
        }
        return mvc.perform(req).andExpect(status().isAccepted()).andReturn().getResponse().getContentAsString();
    }

    @Test
    void uiEventsAreStoredOneEntryEach() throws Exception {
        String longText = "x".repeat(900);
        String json = """
                {"clientId": "body-client", "sessionId": "body-session", "events": [
                  {"action": "page.view", "path": "/files/abc?tab=graph", "at": "2026-09-27T19:00:00Z",
                   "target": {"type": "file", "id": "abc", "label": "MSG-1", "extra": "dropped"}},
                  {"action": "list.filter", "at": "yesterday",
                   "details": {"list": "/files", "changes": {"party": "Contoso", "min": 10.5, "page": 2, "on": true, "none": null},
                               "$set": 1, "a.b": 2, "": 3, "text": "%s", "tags": ["a", {"b": {"c": {"d": 1}}}],
                               "big": 123456789012345678901234567890}},
                  {"action": "search.open", "target": {}, "details": {}},
                  {"action": "Bad Action"},
                  "not an object"
                ]}
                """.formatted(longText);
        MockMvc mvc = mvc();
        mvc.perform(post("/api/audit/events").contentType(MediaType.APPLICATION_JSON).content(json)
                        .header("X-Session-Id", "header-session").header("X-Forwarded-For", "192.0.2.10"))
                .andExpect(status().isAccepted())
                .andExpect(jsonPath("$.accepted").value(3))
                .andExpect(jsonPath("$.rejected").value(2));

        List<Document> all = entries();
        assertThat(all).extracting(d -> d.getString("action")).containsExactly("page.view", "list.filter", "search.open");
        assertThat(all).allSatisfy(d -> {
            assertThat(d.getString("source")).isEqualTo("ui");
            assertThat(d.containsKey("userId")).isTrue();
            Document client = d.get("client", Document.class);
            assertThat(client.getString("ip")).isEqualTo("192.0.2.10");
            // The header wins over the body; the body fills in what the headers lack.
            assertThat(client.getString("sessionId")).isEqualTo("header-session");
            assertThat(client.getString("clientId")).isEqualTo("body-client");
        });

        Document view = all.get(0);
        assertThat(view.get("target", Document.class)).isEqualTo(new Document("type", "file").append("id", "abc").append("label", "MSG-1"));
        assertThat(view.getString("page")).isEqualTo("/files/abc?tab=graph");
        assertThat(view.getDate("clientAt").toInstant()).hasToString("2026-09-27T19:00:00Z");

        Document filter = all.get(1);
        assertThat(filter.containsKey("clientAt")).isFalse();
        Document details = filter.get("details", Document.class);
        assertThat(details.keySet()).containsExactly("list", "changes", "text", "tags", "big");
        assertThat(details.get("changes", Document.class)).isEqualTo(new Document("party", "Contoso").append("min", 10.5)
                .append("page", 2).append("on", true).append("none", null));
        assertThat(details.getString("text")).hasSize(500);
        assertThat(details.getList("tags", Object.class)).containsExactly("a", new Document("b", new Document()));
        assertThat(details.getString("big")).isEqualTo("123456789012345678901234567890");

        assertThat(all.get(2).containsKey("target")).isFalse();
        assertThat(all.get(2).containsKey("details")).isFalse();
    }

    @Test
    void theEventEndpointIsNotAlsoLoggedAsAnApiCall() throws Exception {
        postEvents(mvc(), "{\"events\": [{\"action\": \"page.view\"}]}", "X-Client-Id", "c-1");
        assertThat(only().get("client", Document.class).getString("clientId")).isEqualTo("c-1");
    }

    @Test
    void rejectsMalformedBatches() throws Exception {
        MockMvc mvc = mvc();
        StringBuilder many = new StringBuilder("{\"events\": [");
        for (int i = 0; i <= AuditController.MAX_EVENTS; i++) {
            many.append(i == 0 ? "" : ",").append("{\"action\": \"page.view\"}");
        }
        many.append("]}");
        for (String body : List.of("{}", "{\"events\": []}", "{\"events\": \"x\"}", many.toString())) {
            mvc.perform(post("/api/audit/events").contentType(MediaType.APPLICATION_JSON).content(body)).andExpect(status().isBadRequest());
        }
        assertThat(entries()).isEmpty();
    }

    @Test
    void aBatchOfOnlyInvalidEventsWritesNothing() throws Exception {
        postEvents(mvc(), "{\"events\": [{\"action\": 5}, {}]}");
        assertThat(entries()).isEmpty();
    }

    // ---- storage -------------------------------------------------------

    @Test
    @SuppressWarnings("unchecked")
    void aFailedWriteNeverBreaksTheRequest() throws Exception {
        MongoDatabase db = mock(MongoDatabase.class);
        MongoCollection<Document> broken = mock(MongoCollection.class);
        when(db.getCollection(AuditService.COLLECTION)).thenReturn(broken);
        when(broken.insertMany(anyList())).thenThrow(new IllegalStateException("down"));
        AuditService audit = new AuditService(db, UserResolver.remoteUser(), true);

        mvc(audit, true).perform(get("/api/summary")).andExpect(status().isOk());
        audit.record(List.of(new Document("a", 1), new Document("b", 2)));
        audit.record(List.of());
        assertThat(mongo.db().getCollection(AuditService.COLLECTION).countDocuments(Filters.empty())).isZero();
    }

    @Test
    void clientIdsAndForwardingChainsAreSanitised() {
        assertThat(ClientInfo.id(null)).isNull();
        assertThat(ClientInfo.id(" abc-123 ")).isEqualTo("abc-123");
        assertThat(ClientInfo.id("<script>")).isNull();
        assertThat(ClientInfo.id("x".repeat(129))).isNull();
        assertThat(ClientInfo.forwardedFor(null)).isEmpty();
        assertThat(ClientInfo.forwardedFor(" , 1.1.1.1 ,,2.2.2.2")).containsExactly("1.1.1.1", "2.2.2.2");
        assertThat(ClientInfo.forwardedFor("1,2,3,4,5,6,7,8,9,10,11,12")).hasSize(10);

        MockHttpServletRequest blank = new MockHttpServletRequest();
        blank.addHeader("User-Agent", "   ");
        blank.addHeader("Referer", "r".repeat(400));
        Document client = ClientInfo.from(blank, true);
        assertThat(client.containsKey("userAgent")).isFalse();
        assertThat(client.getString("referer")).hasSize(ClientInfo.MAX_HEADER);
        assertThat(AuditController.clean(Map.of("k", new StringBuilder("sb")), 0)).isEqualTo(new Document("k", "sb"));
        assertThat((List<?>) AuditController.clean(java.util.stream.IntStream.range(0, 40).boxed().toList(), 0)).hasSize(30);
        Map<String, Object> wide = new java.util.LinkedHashMap<>();
        for (int i = 0; i < 40; i++) {
            wide.put("k" + i, i);
        }
        assertThat((Document) AuditController.clean(wide, 0)).hasSize(30);
    }
}
