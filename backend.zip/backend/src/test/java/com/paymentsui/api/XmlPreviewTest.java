package com.paymentsui.api;

import static com.paymentsui.support.Samples.bytes;
import static com.paymentsui.support.Samples.minimal;
import static com.paymentsui.support.Samples.pain002;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mongodb.client.model.Filters;
import com.paymentsui.ingest.IngestService;
import com.paymentsui.support.InMemoryMongo;

/** The Original XML tab gets only the start of a large file; Download always gets all of it. */
class XmlPreviewTest {

    private static final long LIMIT = 1000;

    @RegisterExtension
    InMemoryMongo mongo = new InMemoryMongo();

    String big;
    String small;
    String report;
    byte[] bigXml;

    @BeforeEach
    void load() {
        IngestService ingest = new IngestService(mongo.db());
        bigXml = bytes(minimal("BIG-1", 20));
        big = ingest.ingest(bigXml, "big.xml", "test").fileId().toHexString();
        small = ingest.ingest(bytes(minimal("S-1", 1)), "s.xml", "test").fileId().toHexString();
        ingest.load(bytes(pain002("R-BIG", "2026-09-27T10:00:00Z", "BIG-1", "ACTC")), "r.xml", "test");
        report = mongo.db().getCollection("statusReports").find(Filters.eq("msgId", "R-BIG")).first().getObjectId("_id").toHexString();
        assertThat(bigXml.length).isGreaterThan((int) LIMIT);
    }

    private MockMvc mvc(long limit) {
        return MockMvcBuilders.standaloneSetup(new PaymentsController(mongo.db(), limit),
                new StatusReportsController(mongo.db(), limit)).build();
    }

    private MockHttpServletResponse fetch(MockMvc mvc, String url) throws Exception {
        return mvc.perform(get(url)).andExpect(status().isOk()).andReturn().getResponse();
    }

    @Test
    void aLargeFileIsCutAtALineBreakWithinTheLimit() throws Exception {
        MockHttpServletResponse r = fetch(mvc(LIMIT), "/api/files/" + big + "/xml?preview=true");
        byte[] body = r.getContentAsByteArray();
        assertThat(r.getHeader(RawXml.TRUNCATED)).isEqualTo("true");
        assertThat(r.getHeader(RawXml.TOTAL_BYTES)).isEqualTo(Integer.toString(bigXml.length));
        assertThat(body.length).isLessThanOrEqualTo((int) LIMIT).isGreaterThan(0);
        assertThat(body[body.length - 1]).isEqualTo((byte) '\n');
        assertThat(new String(bigXml, StandardCharsets.UTF_8)).startsWith(new String(body, StandardCharsets.UTF_8));
    }

    @Test
    void downloadAndSmallFilesAreWhole() throws Exception {
        MockMvc mvc = mvc(LIMIT);
        MockHttpServletResponse whole = fetch(mvc, "/api/files/" + big + "/xml");
        assertThat(whole.getContentAsByteArray()).isEqualTo(bigXml);
        assertThat(whole.getHeader(RawXml.TRUNCATED)).isEqualTo("false");

        MockHttpServletResponse preview = fetch(mvc, "/api/files/" + small + "/xml?preview=true");
        assertThat(preview.getHeader(RawXml.TRUNCATED)).isEqualTo("false");
        assertThat(preview.getContentAsByteArray()).hasSize(Integer.parseInt(preview.getHeader(RawXml.TOTAL_BYTES)));
    }

    @Test
    void theDefaultLimitIsFiveMegabytes() throws Exception {
        assertThat(PaymentsController.DEFAULT_XML_PREVIEW_BYTES).isEqualTo(5L * 1024 * 1024);
        MockMvc mvc = MockMvcBuilders.standaloneSetup(new PaymentsController(mongo.db()), new StatusReportsController(mongo.db())).build();
        mvc.perform(get("/api/files/" + big + "/xml?preview=true")).andExpect(header().string(RawXml.TRUNCATED, "false"));
        mvc.perform(get("/api/reports/" + report + "/xml?preview=true")).andExpect(header().string(RawXml.TRUNCATED, "false"));
    }

    @Test
    void statusReportsUseTheSameLimit() throws Exception {
        MockMvc mvc = mvc(200);
        MockHttpServletResponse r = fetch(mvc, "/api/reports/" + report + "/xml?preview=true");
        assertThat(r.getHeader(RawXml.TRUNCATED)).isEqualTo("true");
        assertThat(r.getContentAsByteArray().length).isLessThanOrEqualTo(200);
        MockHttpServletResponse whole = fetch(mvc, "/api/reports/" + report + "/xml");
        assertThat(whole.getHeader(RawXml.TRUNCATED)).isEqualTo("false");
        assertThat(whole.getContentAsByteArray()).hasSize(Integer.parseInt(whole.getHeader(RawXml.TOTAL_BYTES)));
    }

    @Test
    void aFileWithoutLineBreaksIsCutOnACharacterBoundary() {
        byte[] ascii = "<a>abc</a>".getBytes(StandardCharsets.UTF_8);
        assertThat(RawXml.cut(ascii)).isEqualTo(ascii);
        assertThat(RawXml.cut(new byte[0])).isEmpty();

        // "é" is 2 bytes, "€" is 3 and "😀" is 4; a cut inside one drops the partial character.
        byte[] text = "xé€😀".getBytes(StandardCharsets.UTF_8);
        assertThat(RawXml.cut(text)).isEqualTo(text);
        assertThat(new String(RawXml.cut(java.util.Arrays.copyOf(text, 2)), StandardCharsets.UTF_8)).isEqualTo("x");
        assertThat(new String(RawXml.cut(java.util.Arrays.copyOf(text, 5)), StandardCharsets.UTF_8)).isEqualTo("xé");
        assertThat(new String(RawXml.cut(java.util.Arrays.copyOf(text, 9)), StandardCharsets.UTF_8)).isEqualTo("xé€");
        assertThat(new String(RawXml.cut(java.util.Arrays.copyOf(text, 3)), StandardCharsets.UTF_8)).isEqualTo("xé");

        byte[] lines = "<a>\n<b>é</b>".getBytes(StandardCharsets.UTF_8);
        assertThat(new String(RawXml.cut(lines), StandardCharsets.UTF_8)).isEqualTo("<a>\n");
    }
}
