package com.paymentsui.api;

import static com.paymentsui.support.Samples.bytes;
import static com.paymentsui.support.Samples.minimal;
import static com.paymentsui.support.Samples.pain002;
import static com.paymentsui.support.Samples.pmtInf;
import static com.paymentsui.support.Samples.tx;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.net.URI;
import java.util.List;

import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.jayway.jsonpath.JsonPath;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.paymentsui.ingest.IngestService;
import com.paymentsui.support.InMemoryMongo;

/** pain.002 status reports through the API: the reports themselves and the status they give files, batches and transactions. */
class StatusApiTest {

    @RegisterExtension
    InMemoryMongo mongo = new InMemoryMongo();

    MockMvc mvc;
    IngestService.Result file;
    IngestService.Result other;

    @BeforeEach
    void load() {
        IngestService ingest = new IngestService(mongo.db());
        file = ingest.ingest(bytes(minimal("API-2", 3)), "api-2.xml", "test");
        other = ingest.ingest(bytes(minimal("API-3", 2)), "api-3.xml", "test");
        ingest.load(bytes(pain002("R-A", "2026-09-27T10:00:00Z", "API-2", "ACTC")), "r-a.xml", "test");
        ingest.load(bytes(pain002("R-B", "2026-09-27T12:00:00Z", "API-2", "PART",
                pmtInf("API-2-B1", "PART", tx("E2E-2", "RJCT", "AC04", "Account closed")))), "r-b.xml", "test");
        ingest.load(bytes(pain002("R-C", "2026-09-27T12:00:00Z", "NOPE", "ACCP")), "r-c.xml", "test");
        ingest.load(bytes(pain002("R-D", "2026-09-27T13:00:00Z", "API-3", null, pmtInf("API-3-B1", "ACSC"))), "r-d.xml", "test");
        mvc = MockMvcBuilders.standaloneSetup(new PaymentsController(mongo.db()), new StatusReportsController(mongo.db())).build();
    }

    private String body(String url) throws Exception {
        return mvc.perform(get(URI.create(url))).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
    }

    private int total(String url) throws Exception {
        return JsonPath.read(body(url), "$.total");
    }

    private String id(String collection, String field, Object value) {
        return mongo.db().getCollection(collection).find(Filters.eq(field, value)).first().getObjectId("_id").toHexString();
    }

    @Test
    void summaryCountsReportsAndTransactionStatuses() throws Exception {
        String s = body("/api/summary");
        assertThat((Integer) JsonPath.read(s, "$.counts.statusReports")).isEqualTo(4);
        assertThat(JsonPath.<List<Integer>>read(s, "$.paymentStatus[?(@.code == 'ACTC')].count")).containsExactly(2);
        assertThat(JsonPath.<List<Integer>>read(s, "$.paymentStatus[?(@.code == 'RJCT')].count")).containsExactly(1);
        assertThat(JsonPath.<List<Integer>>read(s, "$.paymentStatus[?(@.code == 'ACSC')].count")).containsExactly(2);
    }

    @Test
    void searchFindsReportsByTheirOwnOrTheOriginalMessageId() throws Exception {
        assertThat(JsonPath.<List<String>>read(body("/api/search?q=R-B"), "$.hits[*].detail")).containsExactly("Status report for API-2 · PART");
        assertThat(JsonPath.<List<String>>read(body("/api/search?q=API-3"), "$.hits[?(@.type == 'report')].detail"))
                .containsExactly("Status report for API-3");
    }

    @Test
    void filtersFilesAndTransactionsByPaymentStatus() throws Exception {
        assertThat(total("/api/files?sts=part")).isEqualTo(1);
        assertThat(total("/api/files?sts=NONE")).isEqualTo(1);
        assertThat(total("/api/transactions?sts=RJCT")).isEqualTo(1);
        assertThat(total("/api/transactions?sts=ACSC&fileId=" + other.fileId())).isEqualTo(2);
        assertThat(total("/api/transactions?sts=none")).isZero();
        assertThat((String) JsonPath.read(body("/api/transactions?sts=RJCT"), "$.items[0].status.rsn")).isEqualTo("AC04");
    }

    @Test
    void fileStatusListsReportsAndCounts() throws Exception {
        String s = body("/api/files/" + file.fileId() + "/status");
        assertThat((String) JsonPath.read(s, "$.status.code")).isEqualTo("PART");
        assertThat(JsonPath.<List<String>>read(s, "$.reports[*].msgId")).containsExactly("R-A", "R-B");
        assertThat(JsonPath.<List<String>>read(s, "$.batchesByStatus[*].code")).containsExactly("PART");
        assertThat(JsonPath.<List<String>>read(s, "$.transactionsByStatus[*].code")).containsExactly("ACTC", "RJCT");

        String none = body("/api/files/" + other.fileId() + "/status");
        assertThat(JsonPath.<Object>read(none, "$.status")).isNull();
        mvc.perform(get("/api/files/" + new ObjectId() + "/status")).andExpect(status().isNotFound());
    }

    @Test
    void graphCarriesStatusesAndReports() throws Exception {
        String g = body("/api/files/" + file.fileId() + "/graph");
        assertThat((String) JsonPath.read(g, "$.file.status.code")).isEqualTo("PART");
        assertThat((String) JsonPath.read(g, "$.batches[0].status.code")).isEqualTo("PART");
        assertThat(JsonPath.<List<String>>read(g, "$.batches[0].transactions[*].status.code")).containsExactly("ACTC", "RJCT", "ACTC");
        assertThat(JsonPath.<List<String>>read(g, "$.reports[*].orgnlGrpInfAndSts.grpSts")).containsExactly("ACTC", "PART");
    }

    @Test
    void batchAndTransactionDetailCarryTheirStatusHistory() throws Exception {
        String batch = body("/api/batches/" + id("batches", "pmtInfId", "API-2-B1"));
        // The PART batch status is part of the batch's own history.
        assertThat(JsonPath.<List<String>>read(batch, "$.statusHistory[*].code")).containsExactly("ACTC", "PART");
        assertThat(JsonPath.<List<String>>read(batch, "$.statusHistory[*].level")).containsExactly("GROUP", "PMTINF");

        String tx2 = mongo.db().getCollection("transactions")
                .find(Filters.and(Filters.eq("fileId", file.fileId()), Filters.eq("pmtId.endToEndId", "E2E-2"))).first().getObjectId("_id").toHexString();
        String h = body("/api/transactions/" + tx2);
        assertThat(JsonPath.<List<String>>read(h, "$.statusHistory[*].code")).containsExactly("ACTC", "RJCT");
        assertThat(JsonPath.<List<String>>read(h, "$.statusHistory[*].rsn")).containsExactly("AC04");

        String tx1 = mongo.db().getCollection("transactions")
                .find(Filters.and(Filters.eq("fileId", file.fileId()), Filters.eq("pmtId.endToEndId", "E2E-1"))).first().getObjectId("_id").toHexString();
        // The PART report says nothing about E2E-1, so only the ACTC shows.
        assertThat(JsonPath.<List<String>>read(body("/api/transactions/" + tx1), "$.statusHistory[*].code")).containsExactly("ACTC");

        String tx3 = mongo.db().getCollection("transactions")
                .find(Filters.eq("fileId", other.fileId())).first().getObjectId("_id").toHexString();
        String h3 = body("/api/transactions/" + tx3);
        assertThat(JsonPath.<List<String>>read(h3, "$.statusHistory[*].level")).containsExactly("PMTINF");
    }

    @Test
    void listsAndFiltersReports() throws Exception {
        assertThat(total("/api/reports")).isEqualTo(4);
        assertThat(total("/api/reports?q=nope")).isEqualTo(1);
        assertThat(total("/api/reports?sts=part")).isEqualTo(1);
        assertThat(total("/api/reports?link=unmatched")).isEqualTo(1);
        assertThat(total("/api/reports?fileId=" + file.fileId())).isEqualTo(2);
        assertThat(total("/api/reports?timeField=created&from=2026-09-27T11:00:00Z&to=2026-09-27")).isEqualTo(3);
        assertThat(total("/api/reports?timeField=received&to=2000-01-01")).isZero();
        assertThat(JsonPath.<List<String>>read(body("/api/reports?sort=msgId&dir=asc"), "$.items[*].msgId"))
                .containsExactly("R-A", "R-B", "R-C", "R-D");
        mvc.perform(get("/api/reports?from=soon")).andExpect(status().isBadRequest());
    }

    @Test
    void servesAReportWithItsFileAndXml() throws Exception {
        String rb = id("statusReports", "msgId", "R-B");
        mvc.perform(get("/api/reports/" + rb)).andExpect(status().isOk())
                .andExpect(jsonPath("$.file.msgId").value("API-2"))
                .andExpect(jsonPath("$.link.status").value("LINKED"))
                .andExpect(jsonPath("$.orgnlPmtInfAndSts[0].txInfAndSts[0].txId").isString());
        mvc.perform(get("/api/reports/" + id("statusReports", "msgId", "R-C"))).andExpect(status().isOk())
                .andExpect(jsonPath("$.file").doesNotExist())
                .andExpect(jsonPath("$.link.status").value("UNMATCHED"));

        mvc.perform(get("/api/reports/" + rb + "/xml")).andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("<MsgId>R-B</MsgId>")));
        mongo.db().getCollection("statusReports").updateOne(Filters.eq("msgId", "R-B"), Updates.unset("rawXmlRef"));
        mvc.perform(get("/api/reports/" + rb + "/xml")).andExpect(status().isNotFound());
        mvc.perform(get("/api/reports/nope")).andExpect(status().isNotFound());
        mvc.perform(get("/api/reports/" + new ObjectId())).andExpect(status().isNotFound());
    }
}
