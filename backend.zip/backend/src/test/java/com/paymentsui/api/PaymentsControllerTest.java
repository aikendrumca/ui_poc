package com.paymentsui.api;

import static com.paymentsui.support.Samples.bytes;
import static com.paymentsui.support.Samples.minimal;
import static com.paymentsui.support.Samples.xml;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.math.BigDecimal;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.jayway.jsonpath.JsonPath;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import com.paymentsui.ingest.IngestService;
import com.paymentsui.support.InMemoryMongo;

/** Every API endpoint and filter, against an in-memory MongoDB. */
class PaymentsControllerTest {

    @RegisterExtension
    InMemoryMongo mongo = new InMemoryMongo();

    MockMvc mvc;
    IngestService.Result big;
    IngestService.Result small;

    @BeforeEach
    void load() {
        IngestService ingest = new IngestService(mongo.db());
        big = ingest.ingest(bytes(xml("API-1")), "api-1.xml", "test");
        small = ingest.ingest(bytes(minimal("API-2", 3)), "api-2.xml", "test");
        mvc = MockMvcBuilders.standaloneSetup(new PaymentsController(mongo.db())).build();
    }

    private String body(String url) throws Exception {
        return mvc.perform(get(URI.create(url))).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
    }

    private int total(String url) throws Exception {
        return JsonPath.read(body(url), "$.total");
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20");
    }

    // ---- overview and search ------------------------------------------

    @Test
    void summarisesEverything() throws Exception {
        String s = body("/api/summary");
        assertThat((Integer) JsonPath.read(s, "$.counts.files")).isEqualTo(2);
        assertThat((Integer) JsonPath.read(s, "$.counts.transactions")).isEqualTo(big.transactions() + 3);
        assertThat((Integer) JsonPath.read(s, "$.validation.VALID")).isEqualTo(2);
        assertThat(JsonPath.<List<String>>read(s, "$.totalsByCcy[*].ccy")).contains("EUR");
        assertThat(JsonPath.<List<Object>>read(s, "$.perDay")).isNotNull();
        assertThat(JsonPath.<List<String>>read(s, "$.recentFiles[*].msgId")).containsExactlyInAnyOrder("API-1", "API-2");
    }

    @Test
    void searchFindsFilesBatchesAndTransactionsByReference() throws Exception {
        assertThat(JsonPath.<List<Object>>read(body("/api/search?q=%20"), "$.hits")).isEmpty();

        String hits = body("/api/search?q=API-2");
        assertThat(JsonPath.<List<String>>read(hits, "$.hits[*].type")).contains("file", "batch");

        assertThat(JsonPath.<List<String>>read(body("/api/search?q=E2E-2"), "$.hits[*].label")).containsExactly("E2E-2");

        String uetr = mongo.db().getCollection("transactions").find(Filters.eq("fileId", big.fileId())).first()
                .get("pmtId", Document.class).getString("uetr");
        assertThat(JsonPath.<List<String>>read(body("/api/search?q=" + uetr.toUpperCase()), "$.hits[*].type")).containsExactly("transaction");
    }

    @Test
    void listsInitiatingParties() throws Exception {
        String parties = body("/api/parties");
        assertThat(JsonPath.<List<String>>read(parties, "$.items[*].name")).contains("Minimal Ltd");
        assertThat(JsonPath.<List<Integer>>read(parties, "$.items[?(@.name == 'Minimal Ltd')].transactions")).containsExactly(3);
    }

    // ---- files ----------------------------------------------------------

    @Test
    void filtersFiles() throws Exception {
        assertThat(total("/api/files")).isEqualTo(2);
        assertThat(total("/api/files?q=api-2")).isEqualTo(1);
        assertThat(total("/api/files?status=VALID")).isEqualTo(2);
        assertThat(total("/api/files?status=INVALID")).isZero();
        assertThat(total("/api/files?party=Minimal%20Ltd")).isEqualTo(1);

        Instant now = Instant.now();
        assertThat(total("/api/files?from=" + now.minus(1, ChronoUnit.HOURS) + "&to=" + now.plus(1, ChronoUnit.MINUTES))).isEqualTo(2);
        assertThat(total("/api/files?timeField=received&from=" + now.plus(1, ChronoUnit.HOURS))).isZero();
        assertThat(total("/api/files?timeField=created&from=2026-09-27T09:00&to=2026-09-27")).isGreaterThanOrEqualTo(1);
        assertThat(total("/api/files?timeField=created&to=2000-01-01")).isZero();

        // API-2 has a single EUR total of 3.00.
        assertThat(total("/api/files?ccy=eur&min=2.99&max=3.01")).isEqualTo(1);
        assertThat(total("/api/files?min=3.01&max=3.02")).isZero();
        assertThat(total("/api/files?max=3")).isEqualTo(1);
        assertThat(total("/api/files?ccy=JPY")).isZero();
    }

    @Test
    void sortsAndPagesFiles() throws Exception {
        assertThat(JsonPath.<List<String>>read(body("/api/files?sort=msgId&dir=asc"), "$.items[*].msgId")).containsExactly("API-1", "API-2");
        assertThat(JsonPath.<List<String>>read(body("/api/files?sort=msgId&dir=desc"), "$.items[*].msgId")).containsExactly("API-2", "API-1");
        String page = body("/api/files?sort=bogus&page=-3&size=0");
        assertThat((Integer) JsonPath.read(page, "$.page")).isZero();
        assertThat((Integer) JsonPath.read(page, "$.size")).isEqualTo(1);
        assertThat((Integer) JsonPath.read(body("/api/files?size=5000"), "$.size")).isEqualTo(200);
    }

    @Test
    void servesFileDetailBatchesGraphAndXml() throws Exception {
        String id = small.fileId().toHexString();
        mvc.perform(get("/api/files/" + id)).andExpect(status().isOk()).andExpect(jsonPath("$.msgId").value("API-2"))
                // Amounts are strings, ids are hex, dates are ISO-8601.
                .andExpect(jsonPath("$.stats.totalsByCcy[0].amount").value("3.00"))
                .andExpect(jsonPath("$._id").value(id))
                .andExpect(jsonPath("$.creDtTm").value("2026-09-27T09:00:00Z"));
        assertThat(JsonPath.<List<String>>read(body("/api/files/" + id + "/batches"), "$.items[*].pmtInfId")).containsExactly("API-2-B1");

        String graph = body("/api/files/" + id + "/graph?perBatch=2");
        assertThat(JsonPath.<List<Object>>read(graph, "$.batches[0].transactions")).hasSize(2);
        assertThat((Integer) JsonPath.read(graph, "$.batches[0].more")).isEqualTo(1);
        assertThat((Integer) JsonPath.read(body("/api/files/" + id + "/graph?perBatch=-1"), "$.batches[0].more")).isEqualTo(3);
        assertThat(JsonPath.<List<Object>>read(body("/api/files/" + id + "/graph?perBatch=500"), "$.batches[0].transactions")).hasSize(3);

        mvc.perform(get("/api/files/" + id + "/xml")).andExpect(status().isOk())
                .andExpect(content().string(org.hamcrest.Matchers.containsString("<MsgId>API-2</MsgId>")));
        mongo.db().getCollection("files").updateOne(Filters.eq("_id", small.fileId()), Updates.unset("rawXmlRef"));
        mvc.perform(get("/api/files/" + id + "/xml")).andExpect(status().isNotFound());
    }

    @Test
    void unknownOrMalformedIdsAreNotFound() throws Exception {
        String missing = new ObjectId().toHexString();
        for (String url : List.of("/api/files/nope", "/api/files/" + missing, "/api/batches/" + missing,
                "/api/transactions/" + missing, "/api/files/" + missing + "/graph", "/api/files/" + missing + "/xml")) {
            mvc.perform(get(url)).andExpect(status().isNotFound());
        }
    }

    // ---- batches and transactions ------------------------------------------

    @Test
    void servesBatchesAndTheirTransactions() throws Exception {
        String batchId = mongo.db().getCollection("batches").find(Filters.eq("fileId", small.fileId())).first()
                .getObjectId("_id").toHexString();
        mvc.perform(get("/api/batches/" + batchId)).andExpect(status().isOk()).andExpect(jsonPath("$.pmtInfId").value("API-2-B1"));

        assertThat(JsonPath.<List<Integer>>read(body("/api/batches/" + batchId + "/transactions"), "$.items[*].seq")).containsExactly(0, 1, 2);
        assertThat(JsonPath.<List<Integer>>read(body("/api/batches/" + batchId + "/transactions?sort=seq&dir=desc&size=2"), "$.items[*].seq"))
                .containsExactly(2, 1);
    }

    @Test
    void filtersTransactions() throws Exception {
        int all = big.transactions() + 3;
        assertThat(total("/api/transactions?size=1")).isEqualTo(all);
        assertThat(total("/api/transactions?ref=E2E-2")).isEqualTo(1);
        assertThat(total("/api/transactions?account=DE89%203704%200044%200532%200130%2000")).isEqualTo(3);
        assertThat(total("/api/transactions?account=GB29NWBK60161331926819")).isEqualTo(3);
        assertThat(total("/api/transactions?ccy=eur&min=1&max=1")).isGreaterThanOrEqualTo(3);
        assertThat(total("/api/transactions?party=" + enc("Minimal Ltd"))).isEqualTo(3);
        assertThat(total("/api/transactions?fileId=" + small.fileId())).isEqualTo(3);

        String batchId = mongo.db().getCollection("batches").find(Filters.eq("fileId", small.fileId())).first()
                .getObjectId("_id").toHexString();
        assertThat(total("/api/transactions?batchId=" + batchId)).isEqualTo(3);

        assertThat(total("/api/transactions?fileId=" + small.fileId() + "&from=2026-09-28&to=2026-09-28")).isEqualTo(3);
        assertThat(total("/api/transactions?fileId=" + small.fileId() + "&timeField=created&from=2026-09-27T09:00:00Z&to=2026-09-27T09:00:00Z")).isEqualTo(3);
        assertThat(total("/api/transactions?timeField=received&to=2000-01-01")).isZero();
        assertThat(total("/api/transactions?timeField=bogus&from=2026-09-28&to=2026-09-28&fileId=" + small.fileId())).isEqualTo(3);
    }

    @Test
    void sortsTransactionsByAmount() throws Exception {
        List<String> amounts = JsonPath.read(body("/api/transactions?fileId=" + big.fileId() + "&sort=amount&dir=desc&size=200"), "$.items[*].view.amount");
        List<BigDecimal> values = amounts.stream().map(BigDecimal::new).toList();
        assertThat(values).isSortedAccordingTo(java.util.Comparator.reverseOrder());
    }

    @Test
    void transactionDetailCarriesBatchAndFileContext() throws Exception {
        String txId = mongo.db().getCollection("transactions").find(Filters.eq("fileId", small.fileId())).first()
                .getObjectId("_id").toHexString();
        mvc.perform(get("/api/transactions/" + txId)).andExpect(status().isOk())
                .andExpect(jsonPath("$.context.batch.pmtInfId").value("API-2-B1"))
                .andExpect(jsonPath("$.context.batch.stats").doesNotExist())
                .andExpect(jsonPath("$.context.file.msgId").value("API-2"));
    }

    @Test
    void rejectsMalformedTimes() throws Exception {
        mvc.perform(get("/api/transactions?from=yesterday")).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value(org.hamcrest.Matchers.containsString("yesterday")));
        mvc.perform(get("/api/files?to=27/09/2026")).andExpect(status().isBadRequest());
    }
}
