package com.paymentsui.api;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;

import org.bson.types.ObjectId;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSDownloadStream;

/**
 * Serves an original XML file from GridFS, either whole (for download) or only its
 * first {@code limit} bytes (for the Original XML tab), so a very large file never
 * has to be read in full just to be shown.
 */
final class RawXml {

    /** Size of the whole stored file, sent with every response. */
    static final String TOTAL_BYTES = "X-Xml-Total-Bytes";
    /** "true" when the body is only the start of the file. */
    static final String TRUNCATED = "X-Xml-Truncated";

    private RawXml() {
    }

    /**
     * @param limit maximum bytes to return; null (or not below the file size) returns the whole file
     */
    static ResponseEntity<byte[]> respond(GridFSBucket bucket, ObjectId ref, Long limit) {
        try (GridFSDownloadStream in = bucket.openDownloadStream(ref)) {
            long total = in.getGridFSFile().getLength();
            boolean truncated = limit != null && limit < total;
            byte[] body = truncated ? cut(read(in, limit.intValue())) : read(in, (int) total);
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_XML)
                    .header(TOTAL_BYTES, Long.toString(total))
                    .header(TRUNCATED, Boolean.toString(truncated))
                    .body(body);
        }
    }

    private static byte[] read(InputStream in, int max) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(max, 1 << 20));
            byte[] buf = new byte[64 * 1024];
            int left = max;
            int n;
            while (left > 0 && (n = in.read(buf, 0, Math.min(buf.length, left))) > 0) {
                out.write(buf, 0, n);
                left -= n;
            }
            return out.toByteArray();
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /**
     * Ends a partial file at the last complete line, so the preview never stops in the
     * middle of a tag or of a multi-byte character. A file without line breaks is only
     * trimmed back to a whole UTF-8 character.
     */
    static byte[] cut(byte[] part) {
        int end = part.length;
        for (int i = part.length - 1; i >= 0; i--) {
            if (part[i] == '\n') {
                return java.util.Arrays.copyOf(part, i + 1);
            }
        }
        // Step back over continuation bytes (10xxxxxx) and the lead byte they belong to.
        int i = end - 1;
        while (i >= 0 && (part[i] & 0xC0) == 0x80) {
            i--;
        }
        if (i >= 0 && (part[i] & 0x80) != 0) {
            int need = (part[i] & 0xE0) == 0xC0 ? 2 : (part[i] & 0xF0) == 0xE0 ? 3 : 4;
            if (end - i < need) {
                end = i;
            }
        }
        return java.util.Arrays.copyOf(part, end);
    }
}
