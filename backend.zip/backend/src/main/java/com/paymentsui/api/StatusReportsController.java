package com.paymentsui.api;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.or;
import static com.mongodb.client.model.Filters.regex;

import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.model.Projections;

/** Read-only API over the pain.002 status reports in the statusReports collection. */
@RestController
@RequestMapping(path = "/api/reports", produces = MediaType.APPLICATION_JSON_VALUE)
public class StatusReportsController {

    private static final Map<String, String> SORTS = Map.of(
            "received", "source.receivedAt", "created", "creDtTm", "msgId", "msgId");
    private static final Map<String, String> TIME_FIELDS = Map.of(
            "received", "source.receivedAt", "created", "creDtTm");
    private static final Bson LIST_FIELDS = Projections.include(
            "msgId", "creDtTm", "fileId", "dbtrAgt", "orgnlGrpInfAndSts.orgnlMsgId", "orgnlGrpInfAndSts.grpSts",
            "orgnlGrpInfAndSts.stsRsnInf", "source", "stats", "link.status");

    private final MongoCollection<Document> reports;
    private final MongoCollection<Document> files;
    private final GridFSBucket rawXml;
    private final long xmlPreviewBytes;

    public StatusReportsController(MongoDatabase db) {
        this(db, PaymentsController.DEFAULT_XML_PREVIEW_BYTES);
    }

    @Autowired
    public StatusReportsController(MongoDatabase db, @Value("${payments.xml.preview-bytes:5242880}") long xmlPreviewBytes) {
        this.xmlPreviewBytes = xmlPreviewBytes;
        this.reports = db.getCollection("statusReports");
        this.files = db.getCollection("files");
        this.rawXml = GridFSBuckets.create(db, "rawXml");
    }

    @GetMapping
    public String list(@RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "25") int size,
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String sts,
            @RequestParam(required = false) String link,
            @RequestParam(required = false) String fileId,
            @RequestParam(defaultValue = "received") String timeField,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(defaultValue = "received") String sort,
            @RequestParam(defaultValue = "desc") String dir) {
        List<Bson> filters = new ArrayList<>();
        if (PaymentsController.notBlank(q)) {
            Pattern p = Pattern.compile(Pattern.quote(q.trim()), Pattern.CASE_INSENSITIVE);
            filters.add(or(regex("msgId", p), regex("orgnlGrpInfAndSts.orgnlMsgId", p), regex("source.fileName", p)));
        }
        if (PaymentsController.notBlank(sts)) {
            filters.add(eq("orgnlGrpInfAndSts.grpSts", sts.trim().toUpperCase()));
        }
        if (PaymentsController.notBlank(link)) {
            filters.add(eq("link.status", link.trim().toUpperCase()));
        }
        if (PaymentsController.notBlank(fileId)) {
            filters.add(eq("fileId", PaymentsController.oid(fileId)));
        }
        PaymentsController.addTimeRange(filters, TIME_FIELDS.getOrDefault(timeField, "source.receivedAt"), from, to);
        Bson filter = filters.isEmpty() ? new Document() : and(filters);
        return PaymentsController.page(reports.find(filter).projection(LIST_FIELDS), reports.countDocuments(filter),
                SORTS.getOrDefault(sort, "source.receivedAt"), dir, page, size);
    }

    /** The whole report plus a short summary of the original file it answers, when that is loaded. */
    @GetMapping("/{id}")
    public String report(@PathVariable String id) {
        Document report = PaymentsController.require(reports.find(eq("_id", PaymentsController.oid(id))).first());
        ObjectId fileId = report.getObjectId("fileId");
        Document file = fileId == null ? null : files.find(eq("_id", fileId))
                .projection(Projections.include("msgId", "creDtTm", "initgPty.nm", "nbOfTxs", "status", "stats.txCount")).first();
        return Json.of(report.append("file", file));
    }

    @GetMapping(path = "/{id}/xml", produces = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<byte[]> xml(@PathVariable String id, @RequestParam(defaultValue = "false") boolean preview) {
        Document report = PaymentsController.require(reports.find(eq("_id", PaymentsController.oid(id)))
                .projection(Projections.include("rawXmlRef")).first());
        ObjectId ref = report.getObjectId("rawXmlRef");
        if (ref == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Original XML not stored for this report");
        }
        return RawXml.respond(rawXml, ref, preview ? xmlPreviewBytes : null);
    }

    @ExceptionHandler(DateTimeParseException.class)
    ResponseEntity<String> badDate(DateTimeParseException e) {
        return PaymentsController.badDateResponse(e);
    }
}
