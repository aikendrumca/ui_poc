package com.paymentsui.api;

import java.time.Instant;
import java.util.List;

import org.bson.Document;
import org.bson.json.JsonMode;
import org.bson.json.JsonWriterSettings;

/**
 * Writes BSON documents as plain JSON for the UI: ObjectIds as hex strings,
 * Decimal128 amounts as strings (no floating-point rounding), dates as ISO-8601.
 */
final class Json {

    static final JsonWriterSettings SETTINGS = JsonWriterSettings.builder()
            .outputMode(JsonMode.RELAXED)
            .objectIdConverter((v, w) -> w.writeString(v.toHexString()))
            .decimal128Converter((v, w) -> w.writeString(v.bigDecimalValue().toPlainString()))
            .dateTimeConverter((v, w) -> w.writeString(Instant.ofEpochMilli(v).toString()))
            .int64Converter((v, w) -> w.writeNumber(Long.toString(v)))
            .build();

    private Json() {
    }

    static String of(Document doc) {
        return doc.toJson(SETTINGS);
    }

    static String page(List<Document> items, long total, int page, int size) {
        return of(new Document("items", items).append("total", total).append("page", page).append("size", size));
    }
}
