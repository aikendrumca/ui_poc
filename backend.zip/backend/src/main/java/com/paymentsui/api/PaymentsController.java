package com.paymentsui.api;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.elemMatch;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.gte;
import static com.mongodb.client.model.Filters.lt;
import static com.mongodb.client.model.Filters.lte;
import static com.mongodb.client.model.Filters.or;
import static com.mongodb.client.model.Filters.regex;
import static com.mongodb.client.model.Filters.text;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.Decimal128;
import org.bson.types.ObjectId;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Sorts;
import com.paymentsui.ingest.StatusReportService;

/**
 * Read-only API over the files, batches and transactions collections, including
 * the pain.002 status each of them last received.
 */
@RestController
@RequestMapping(path = "/api", produces = MediaType.APPLICATION_JSON_VALUE)
public class PaymentsController {

    private static final int MAX_PAGE_SIZE = 200;
    private static final Map<String, String> FILE_SORTS = Map.of(
            "received", "source.receivedAt", "created", "creDtTm", "msgId", "msgId", "txCount", "stats.txCount");
    private static final Map<String, String> TX_SORTS = Map.of(
            "amount", "view.amount", "date", "view.reqdExctnDt", "creditor", "view.cdtrNm", "seq", "seq");
    private static final Map<String, String> FILE_TIME_FIELDS = Map.of(
            "received", "source.receivedAt", "created", "creDtTm");
    private static final Map<String, String> TX_TIME_FIELDS = Map.of(
            "execution", "view.reqdExctnDt", "created", "view.creDtTm", "received", "view.receivedAt");
    private static final Bson TX_LIST_FIELDS = Projections.include(
            "fileId", "batchId", "msgId", "pmtInfId", "seq", "pmtId", "view", "status");
    private static final Bson REPORT_SUMMARY_FIELDS = Projections.include(
            "msgId", "creDtTm", "fileId", "orgnlGrpInfAndSts.orgnlMsgId", "orgnlGrpInfAndSts.grpSts",
            "orgnlGrpInfAndSts.stsRsnInf", "source.fileName", "source.receivedAt", "stats", "link.status");

    /** 5 MB: about 9,000 transactions, so only unusually large files are cut short. */
    public static final long DEFAULT_XML_PREVIEW_BYTES = 5L * 1024 * 1024;

    private final MongoCollection<Document> files;
    private final MongoCollection<Document> batches;
    private final MongoCollection<Document> transactions;
    private final MongoCollection<Document> reports;
    private final GridFSBucket rawXml;
    private final long xmlPreviewBytes;

    public PaymentsController(MongoDatabase db) {
        this(db, DEFAULT_XML_PREVIEW_BYTES);
    }

    /** Files larger than {@code xmlPreviewBytes} are cut short in the Original XML tab. */
    @Autowired
    public PaymentsController(MongoDatabase db, @Value("${payments.xml.preview-bytes:5242880}") long xmlPreviewBytes) {
        this.xmlPreviewBytes = xmlPreviewBytes;
        this.files = db.getCollection("files");
        this.batches = db.getCollection("batches");
        this.transactions = db.getCollection("transactions");
        this.reports = db.getCollection("statusReports");
        this.rawXml = GridFSBuckets.create(db, "rawXml");
    }

    // ---- overview -------------------------------------------------------

    @GetMapping("/summary")
    public String summary() {
        Document counts = new Document("files", files.countDocuments())
                .append("batches", batches.countDocuments())
                .append("transactions", transactions.countDocuments())
                .append("statusReports", reports.countDocuments());

        Document byStatus = new Document();
        files.aggregate(List.of(Aggregates.group("$validation.status", Accumulators.sum("n", 1))))
                .forEach(d -> byStatus.append(String.valueOf(d.get("_id")), d.get("n")));

        // Latest pain.002 status of every transaction; NONE when no report has covered it yet.
        List<Document> paymentStatus = transactions.aggregate(List.of(
                Aggregates.group(new Document("$ifNull", List.of("$status.code", "NONE")), Accumulators.sum("count", 1)),
                Aggregates.sort(Sorts.descending("count")),
                Aggregates.project(Projections.fields(Projections.excludeId(),
                        Projections.computed("code", "$_id"), Projections.include("count")))))
                .into(new ArrayList<>());

        List<Document> totals = files.aggregate(List.of(
                Aggregates.unwind("$stats.totalsByCcy"),
                Aggregates.group("$stats.totalsByCcy.ccy",
                        Accumulators.sum("amount", "$stats.totalsByCcy.amount"),
                        Accumulators.sum("count", "$stats.totalsByCcy.count")),
                Aggregates.sort(Sorts.descending("count")),
                Aggregates.project(Projections.fields(Projections.excludeId(),
                        Projections.computed("ccy", "$_id"), Projections.include("amount", "count")))))
                .into(new ArrayList<>());

        Date since = Date.from(LocalDate.now(ZoneOffset.UTC).minusDays(13).atStartOfDay(ZoneOffset.UTC).toInstant());
        List<Document> perDay = files.aggregate(List.of(
                Aggregates.match(gte("source.receivedAt", since)),
                Aggregates.group(new Document("$dateToString", new Document("format", "%Y-%m-%d").append("date", "$source.receivedAt")),
                        Accumulators.sum("files", 1), Accumulators.sum("transactions", "$stats.txCount")),
                Aggregates.sort(Sorts.ascending("_id")),
                Aggregates.project(Projections.fields(Projections.excludeId(),
                        Projections.computed("day", "$_id"), Projections.include("files", "transactions")))))
                .into(new ArrayList<>());

        List<Document> recent = files.find().sort(Sorts.descending("source.receivedAt")).limit(8)
                .projection(fileListFields()).into(new ArrayList<>());

        return Json.of(new Document("counts", counts).append("validation", byStatus)
                .append("paymentStatus", paymentStatus)
                .append("totalsByCcy", totals).append("perDay", perDay).append("recentFiles", recent));
    }

    @GetMapping("/search")
    public String search(@RequestParam String q) {
        String term = q.trim();
        List<Document> hits = new ArrayList<>();
        if (term.isEmpty()) {
            return Json.of(new Document("hits", hits));
        }
        files.find(regex("msgId", "^" + Pattern.quote(term))).limit(5).projection(fileListFields())
                .forEach(d -> hits.add(hit("file", d.getObjectId("_id"), d.getString("msgId"), partyName(d, "initgPty"))));
        batches.find(regex("pmtInfId", "^" + Pattern.quote(term))).limit(5)
                .projection(Projections.include("pmtInfId", "msgId", "dbtr.nm"))
                .forEach(d -> hits.add(hit("batch", d.getObjectId("_id"), d.getString("pmtInfId"), d.getString("msgId"))));
        reports.find(or(regex("msgId", "^" + Pattern.quote(term)), regex("orgnlGrpInfAndSts.orgnlMsgId", "^" + Pattern.quote(term))))
                .limit(5).projection(REPORT_SUMMARY_FIELDS)
                .forEach(d -> {
                    Document grp = d.get("orgnlGrpInfAndSts", Document.class);
                    hits.add(hit("report", d.getObjectId("_id"), d.getString("msgId"),
                            "Status report for " + grp.getString("orgnlMsgId")
                                    + (grp.getString("grpSts") == null ? "" : " · " + grp.getString("grpSts"))));
                });
        transactions.find(or(
                        regex("pmtId.endToEndId", "^" + Pattern.quote(term)),
                        regex("pmtId.instrId", "^" + Pattern.quote(term)),
                        eq("pmtId.uetr", term.toLowerCase())))
                .limit(10).projection(TX_LIST_FIELDS)
                .forEach(d -> {
                    Document v = d.get("view", Document.class);
                    hits.add(hit("transaction", d.getObjectId("_id"), d.get("pmtId", Document.class).getString("endToEndId"),
                            v.getString("cdtrNm") + " · " + v.get("amount") + " " + v.getString("ccy")));
                });
        return Json.of(new Document("hits", hits));
    }

    /** Initiating parties seen so far, for the party filter. */
    @GetMapping("/parties")
    public String parties() {
        List<Document> items = files.aggregate(List.of(
                Aggregates.match(new Document("initgPty.nm", new Document("$type", "string"))),
                Aggregates.group("$initgPty.nm", Accumulators.sum("files", 1), Accumulators.sum("transactions", "$stats.txCount")),
                Aggregates.sort(Sorts.ascending("_id")),
                Aggregates.project(Projections.fields(Projections.excludeId(),
                        Projections.computed("name", "$_id"), Projections.include("files", "transactions")))))
                .into(new ArrayList<>());
        return Json.of(new Document("items", items));
    }

    // ---- files ----------------------------------------------------------

    @GetMapping("/files")
    public String listFiles(@RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "25") int size,
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String sts,
            @RequestParam(required = false) String party,
            @RequestParam(defaultValue = "received") String timeField,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(required = false) String ccy,
            @RequestParam(required = false) BigDecimal min,
            @RequestParam(required = false) BigDecimal max,
            @RequestParam(defaultValue = "received") String sort,
            @RequestParam(defaultValue = "desc") String dir) {
        List<Bson> filters = new ArrayList<>();
        if (notBlank(q)) {
            Pattern p = Pattern.compile(Pattern.quote(q.trim()), Pattern.CASE_INSENSITIVE);
            filters.add(or(regex("msgId", p), regex("initgPty.nm", p), regex("source.fileName", p)));
        }
        if (notBlank(status)) {
            filters.add(eq("validation.status", status));
        }
        addPaymentStatus(filters, sts);
        if (notBlank(party)) {
            filters.add(eq("initgPty.nm", party));
        }
        addTimeRange(filters, FILE_TIME_FIELDS.getOrDefault(timeField, "source.receivedAt"), from, to);
        // A file matches an amount range when one of its per-currency totals falls inside it.
        List<Bson> total = new ArrayList<>();
        if (notBlank(ccy)) {
            total.add(eq("ccy", ccy.trim().toUpperCase()));
        }
        if (min != null) {
            total.add(gte("amount", new Decimal128(min)));
        }
        if (max != null) {
            total.add(lte("amount", new Decimal128(max)));
        }
        if (!total.isEmpty()) {
            filters.add(elemMatch("stats.totalsByCcy", and(total)));
        }
        Bson filter = filters.isEmpty() ? new Document() : and(filters);
        String sortField = FILE_SORTS.getOrDefault(sort, "source.receivedAt");
        return page(files.find(filter).projection(fileListFields()), files.countDocuments(filter),
                sortField, dir, page, size);
    }

    @GetMapping("/files/{id}")
    public String file(@PathVariable String id) {
        return Json.of(require(files.find(eq("_id", oid(id))).first()));
    }

    @GetMapping(path = "/files/{id}/xml", produces = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<byte[]> fileXml(@PathVariable String id, @RequestParam(defaultValue = "false") boolean preview) {
        Document file = require(files.find(eq("_id", oid(id))).projection(Projections.include("rawXmlRef", "source")).first());
        ObjectId ref = file.getObjectId("rawXmlRef");
        if (ref == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Original XML not stored for this file");
        }
        return RawXml.respond(rawXml, ref, preview ? xmlPreviewBytes : null);
    }

    @GetMapping("/files/{id}/batches")
    public String fileBatches(@PathVariable String id) {
        List<Document> items = batches.find(eq("fileId", oid(id))).sort(Sorts.ascending("seq")).into(new ArrayList<>());
        return Json.of(new Document("items", items));
    }

    /**
     * The file's pain.002 picture: its current status, every status report that
     * answers it (oldest first), and how many batches and transactions are in
     * each status now.
     */
    @GetMapping("/files/{id}/status")
    public String fileStatus(@PathVariable String id) {
        ObjectId fileId = oid(id);
        Document file = require(files.find(eq("_id", fileId)).projection(Projections.include("status")).first());
        List<Document> list = reports.find(eq("fileId", fileId)).sort(Sorts.ascending("creDtTm", "_id"))
                .projection(REPORT_SUMMARY_FIELDS).into(new ArrayList<>());
        return Json.of(new Document("status", file.get("status")).append("reports", list)
                .append("batchesByStatus", countByStatus(batches, fileId))
                .append("transactionsByStatus", countByStatus(transactions, fileId)));
    }

    /**
     * The file, its batches and the first {@code perBatch} transactions of each
     * batch, for the link graph. {@code more} says how many were left out.
     */
    @GetMapping("/files/{id}/graph")
    public String fileGraph(@PathVariable String id, @RequestParam(defaultValue = "25") int perBatch) {
        ObjectId fileId = oid(id);
        Document file = require(files.find(eq("_id", fileId)).projection(fileListFields()).first());
        int limit = Math.max(0, Math.min(perBatch, 100));
        List<Document> nodes = new ArrayList<>();
        for (Document b : batches.find(eq("fileId", fileId)).sort(Sorts.ascending("seq"))
                .projection(Projections.include("seq", "pmtInfId", "pmtMtd", "reqdExctnDt", "dbtr.nm", "dbtrAcct.id", "nbOfTxs", "stats", "validation.status", "status"))) {
            // limit(0) means "no limit" to MongoDB, so ask for nothing explicitly.
            List<Document> txs = limit == 0 ? new ArrayList<>()
                    : transactions.find(eq("batchId", b.getObjectId("_id"))).sort(Sorts.ascending("seq"))
                            .limit(limit).projection(Projections.include("seq", "pmtId", "view", "status")).into(new ArrayList<>());
            int total = b.get("stats", Document.class).getInteger("txCount", txs.size());
            nodes.add(b.append("transactions", txs).append("more", Math.max(0, total - txs.size())));
        }
        List<Document> statusReports = reports.find(eq("fileId", fileId)).sort(Sorts.ascending("creDtTm", "_id"))
                .projection(REPORT_SUMMARY_FIELDS).into(new ArrayList<>());
        return Json.of(new Document("file", file).append("batches", nodes).append("reports", statusReports));
    }

    // ---- batches --------------------------------------------------------

    @GetMapping("/batches/{id}")
    public String batch(@PathVariable String id) {
        Document batch = require(batches.find(eq("_id", oid(id))).first());
        return Json.of(batch.append("statusHistory", history(batch.getObjectId("fileId"), batch.getObjectId("_id"), null)));
    }

    @GetMapping("/batches/{id}/transactions")
    public String batchTransactions(@PathVariable String id,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size,
            @RequestParam(defaultValue = "seq") String sort,
            @RequestParam(defaultValue = "asc") String dir) {
        Bson filter = eq("batchId", oid(id));
        return page(transactions.find(filter).projection(TX_LIST_FIELDS), transactions.countDocuments(filter),
                TX_SORTS.getOrDefault(sort, "seq"), dir, page, size);
    }

    // ---- transactions ---------------------------------------------------

    @GetMapping("/transactions")
    public String listTransactions(@RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size,
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String ref,
            @RequestParam(required = false) String account,
            @RequestParam(required = false) String ccy,
            @RequestParam(required = false) BigDecimal min,
            @RequestParam(required = false) BigDecimal max,
            @RequestParam(required = false) String party,
            @RequestParam(required = false) String sts,
            @RequestParam(defaultValue = "execution") String timeField,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(required = false) String fileId,
            @RequestParam(required = false) String batchId,
            @RequestParam(defaultValue = "date") String sort,
            @RequestParam(defaultValue = "desc") String dir) {
        List<Bson> filters = new ArrayList<>();
        if (notBlank(q)) {
            filters.add(text(q.trim()));
        }
        if (notBlank(ref)) {
            String r = ref.trim();
            filters.add(or(eq("pmtId.endToEndId", r), eq("pmtId.instrId", r), eq("pmtId.uetr", r.toLowerCase())));
        }
        if (notBlank(account)) {
            String a = account.replace(" ", "").toUpperCase();
            filters.add(or(eq("view.cdtrAcct", a), eq("view.dbtrAcct", a)));
        }
        if (notBlank(ccy)) {
            filters.add(eq("view.ccy", ccy.trim().toUpperCase()));
        }
        if (min != null) {
            filters.add(gte("view.amount", new Decimal128(min)));
        }
        if (max != null) {
            filters.add(lte("view.amount", new Decimal128(max)));
        }
        if (notBlank(party)) {
            filters.add(eq("view.initgPtyNm", party));
        }
        addPaymentStatus(filters, sts);
        addTimeRange(filters, TX_TIME_FIELDS.getOrDefault(timeField, "view.reqdExctnDt"), from, to);
        if (notBlank(fileId)) {
            filters.add(eq("fileId", oid(fileId)));
        }
        if (notBlank(batchId)) {
            filters.add(eq("batchId", oid(batchId)));
        }
        Bson filter = filters.isEmpty() ? new Document() : and(filters);
        return page(transactions.find(filter).projection(TX_LIST_FIELDS), transactions.countDocuments(filter),
                TX_SORTS.getOrDefault(sort, "view.reqdExctnDt"), dir, page, size);
    }

    /** The transaction plus the batch and file context needed to draw its full party chain. */
    @GetMapping("/transactions/{id}")
    public String transaction(@PathVariable String id) {
        Document tx = require(transactions.find(eq("_id", oid(id))).first());
        Document batch = batches.find(eq("_id", tx.getObjectId("batchId")))
                .projection(Projections.exclude("stats")).first();
        Document file = files.find(eq("_id", tx.getObjectId("fileId")))
                .projection(Projections.include("msgId", "creDtTm", "initgPty", "validation.status", "source.fileName")).first();
        return Json.of(tx.append("context", new Document("batch", batch).append("file", file))
                .append("statusHistory", history(tx.getObjectId("fileId"), tx.getObjectId("batchId"), tx.getObjectId("_id"))));
    }

    // ---- helpers --------------------------------------------------------

    /** {@code sts} is a pain.002 status code, or NONE for items no report has covered yet. */
    static void addPaymentStatus(List<Bson> filters, String sts) {
        if (notBlank(sts)) {
            String code = sts.trim().toUpperCase();
            filters.add("NONE".equals(code) ? eq("status", null) : eq("status.code", code));
        }
    }

    private List<Document> countByStatus(MongoCollection<Document> collection, ObjectId fileId) {
        return collection.aggregate(List.of(
                Aggregates.match(eq("fileId", fileId)),
                Aggregates.group(new Document("$ifNull", List.of("$status.code", "NONE")), Accumulators.sum("count", 1)),
                Aggregates.sort(Sorts.ascending("_id")),
                Aggregates.project(Projections.fields(Projections.excludeId(),
                        Projections.computed("code", "$_id"), Projections.include("count")))))
                .into(new ArrayList<>());
    }

    /**
     * Every status the reports for a file gave a batch (txId null) or a
     * transaction, oldest first, at the most specific level each report used.
     */
    private List<Document> history(ObjectId fileId, ObjectId batchId, ObjectId txId) {
        List<Document> out = new ArrayList<>();
        for (Document report : reports.find(eq("fileId", fileId)).sort(Sorts.ascending("creDtTm", "_id"))) {
            Document entry = statusFor(report, batchId, txId);
            if (entry != null) {
                out.add(entry);
            }
        }
        return out;
    }

    private static Document statusFor(Document report, ObjectId batchId, ObjectId txId) {
        Date at = report.getDate("creDtTm");
        Document pmtInfLevel = null;
        for (Document pmtInf : report.getList("orgnlPmtInfAndSts", Document.class)) {
            if (txId != null) {
                for (Document tx : pmtInf.getList("txInfAndSts", Document.class)) {
                    if (txId.equals(tx.getObjectId("txId")) && tx.getString("txSts") != null) {
                        return StatusReportService.status(report, at, "TX", tx.getString("txSts"), tx);
                    }
                }
            }
            if (pmtInfLevel == null && batchId.equals(pmtInf.getObjectId("batchId")) && pmtInf.getString("pmtInfSts") != null
                    && (txId == null || !"PART".equals(pmtInf.getString("pmtInfSts")))) {
                pmtInfLevel = StatusReportService.status(report, at, "PMTINF", pmtInf.getString("pmtInfSts"), pmtInf);
            }
        }
        if (pmtInfLevel != null) {
            return pmtInfLevel;
        }
        Document grp = report.get("orgnlGrpInfAndSts", Document.class);
        String grpSts = grp.getString("grpSts");
        return grpSts == null || "PART".equals(grpSts) ? null : StatusReportService.status(report, at, "GROUP", grpSts, grp);
    }

    private static Bson fileListFields() {
        return Projections.include("msgId", "creDtTm", "nbOfTxs", "ctrlSum", "initgPty.nm", "source", "stats", "validation.status", "status");
    }

    static String page(FindIterable<Document> find, long total, String sortField, String dir, int page, int size) {
        int s = Math.max(1, Math.min(size, MAX_PAGE_SIZE));
        int p = Math.max(0, page);
        Bson sort = "asc".equalsIgnoreCase(dir) ? Sorts.ascending(sortField, "_id") : Sorts.descending(sortField, "_id");
        List<Document> items = find.sort(sort).skip(p * s).limit(s).into(new ArrayList<>());
        return Json.page(items, total, p, s);
    }

    /**
     * Adds a time window. Bounds are either a date ({@code 2026-09-27}: the whole
     * UTC day, so {@code to} is inclusive of that day) or an ISO-8601 date-time with
     * an offset ({@code 2026-09-27T14:30:00Z}); a date-time without one is read as UTC.
     */
    static void addTimeRange(List<Bson> filters, String field, String from, String to) {
        if (notBlank(from)) {
            filters.add(gte(field, Date.from(instant(from.trim(), false))));
        }
        if (notBlank(to)) {
            String t = to.trim();
            filters.add(isDateOnly(t) ? lt(field, Date.from(instant(t, true))) : lte(field, Date.from(instant(t, false))));
        }
    }

    private static boolean isDateOnly(String s) {
        return s.length() == 10;
    }

    private static Instant instant(String s, boolean endOfDay) {
        if (isDateOnly(s)) {
            LocalDate d = LocalDate.parse(s);
            return (endOfDay ? d.plusDays(1) : d).atStartOfDay(ZoneOffset.UTC).toInstant();
        }
        try {
            return OffsetDateTime.parse(s).toInstant();
        } catch (DateTimeParseException e) {
            return LocalDateTime.parse(s).toInstant(ZoneOffset.UTC);
        }
    }

    private static Document hit(String type, ObjectId id, String label, String detail) {
        return new Document("type", type).append("id", id).append("label", label).append("detail", detail);
    }

    private static String partyName(Document d, String key) {
        Document party = d.get(key, Document.class);
        return party == null ? null : party.getString("nm");
    }

    static boolean notBlank(String s) {
        return s != null && !s.isBlank();
    }

    static ObjectId oid(String id) {
        if (!ObjectId.isValid(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Unknown id " + id);
        }
        return new ObjectId(id);
    }

    static Document require(Document doc) {
        if (doc == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Not found");
        }
        return doc;
    }

    @ExceptionHandler(DateTimeParseException.class)
    ResponseEntity<String> badDate(DateTimeParseException e) {
        return badDateResponse(e);
    }

    static ResponseEntity<String> badDateResponse(DateTimeParseException e) {
        return ResponseEntity.badRequest().contentType(MediaType.APPLICATION_JSON)
                .body(Json.of(new Document("error",
                        "Times must be YYYY-MM-DD or an ISO date-time such as 2026-09-27T14:30:00Z: " + e.getParsedString())));
    }
}
