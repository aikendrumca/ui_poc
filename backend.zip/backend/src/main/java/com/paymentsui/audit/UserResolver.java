package com.paymentsui.audit;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Says which user made a request, for the audit log. There is no sign-in yet, so
 * the default answer is null; when authentication is added, provide a bean of
 * this type (or let the servlet container set the remote user) and every audit
 * entry picks up the user id without other changes.
 */
@FunctionalInterface
public interface UserResolver {

    String userId(HttpServletRequest request);

    /** The authenticated user's name as the servlet container knows it; null until sign-in exists. */
    static UserResolver remoteUser() {
        return HttpServletRequest::getRemoteUser;
    }
}
