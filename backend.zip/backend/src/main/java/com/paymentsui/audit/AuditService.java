package com.paymentsui.audit;

import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Writes user actions to the {@code auditLog} collection. Every entry has the
 * same shape whether it came from an API call or a UI event:
 *
 * <pre>
 * { at, source: "api" | "ui", action, target { type, id, label }, details { … },
 *   userId (null until sign-in exists), client { ip, remoteAddr, forwardedFor[], clientId,
 *   sessionId, requestId, userAgent, … }, request { method, path, status, durationMs } }
 * </pre>
 *
 * Logging never breaks the request it describes: a failed write is logged and dropped.
 */
@Service
public class AuditService {

    public static final String COLLECTION = "auditLog";
    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    private final MongoCollection<Document> entries;
    private final UserResolver users;
    private final boolean trustForwardedFor;

    @Autowired
    public AuditService(MongoDatabase db, ObjectProvider<UserResolver> users,
            @Value("${payments.audit.trust-forwarded-for:true}") boolean trustForwardedFor) {
        this(db, users.getIfAvailable(UserResolver::remoteUser), trustForwardedFor);
    }

    public AuditService(MongoDatabase db, UserResolver users, boolean trustForwardedFor) {
        this.entries = db.getCollection(COLLECTION);
        this.users = users;
        this.trustForwardedFor = trustForwardedFor;
    }

    /** The fields every entry shares: when, who (a placeholder for now) and from where. */
    public Document entry(HttpServletRequest request, String source, String action) {
        return new Document("at", new Date())
                .append("source", source)
                .append("action", action)
                .append("userId", users.userId(request))
                .append("client", ClientInfo.from(request, trustForwardedFor));
    }

    public void record(List<Document> batch) {
        if (batch.isEmpty()) {
            return;
        }
        try {
            entries.insertMany(batch);
        } catch (RuntimeException e) {
            log.warn("Could not write {} audit entr{}: {}", batch.size(), batch.size() == 1 ? "y" : "ies", e.toString());
        }
    }
}
