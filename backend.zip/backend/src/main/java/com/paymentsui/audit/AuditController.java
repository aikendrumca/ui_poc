package com.paymentsui.audit;

import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.bson.Document;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Receives what users do in the UI (page views, searches, filter changes, opening
 * a file, batch, transaction or report, downloads) and writes one audit entry per
 * event. Body: {@code {"events": [{"action", "target": {type, id, label}, "details": {...},
 * "path", "at"}], "clientId", "sessionId"}}. The ids in the body are only used
 * when the headers are missing, as with navigator.sendBeacon.
 */
@RestController
@RequestMapping(path = AuditController.PATH, produces = MediaType.APPLICATION_JSON_VALUE)
public class AuditController {

    static final String PATH = "/api/audit";
    static final int MAX_EVENTS = 50;
    private static final Pattern ACTION = Pattern.compile("[a-z][a-z0-9._-]{0,63}");
    private static final int MAX_STRING = 500;
    private static final int MAX_KEYS = 30;
    private static final int MAX_DEPTH = 3;

    private final AuditService audit;

    public AuditController(AuditService audit) {
        this.audit = audit;
    }

    @PostMapping(path = "/events", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Object>> events(@RequestBody Map<String, Object> body, HttpServletRequest request) {
        if (!(body.get("events") instanceof List<?> events) || events.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Expected a non-empty events array");
        }
        if (events.size() > MAX_EVENTS) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "At most " + MAX_EVENTS + " events per call");
        }
        List<Document> batch = new ArrayList<>();
        int rejected = 0;
        for (Object e : events) {
            Document entry = e instanceof Map<?, ?> event ? toEntry(event, body, request) : null;
            if (entry == null) {
                rejected++;
            } else {
                batch.add(entry);
            }
        }
        audit.record(batch);
        return ResponseEntity.accepted().body(Map.of("accepted", batch.size(), "rejected", rejected));
    }

    private Document toEntry(Map<?, ?> event, Map<String, Object> body, HttpServletRequest request) {
        String action = event.get("action") instanceof String s ? s : null;
        if (action == null || !ACTION.matcher(action).matches()) {
            return null;
        }
        Document entry = audit.entry(request, "ui", action);
        Document client = entry.get("client", Document.class);
        fillFromBody(client, "clientId", body.get("clientId"));
        fillFromBody(client, "sessionId", body.get("sessionId"));
        if (event.get("target") instanceof Map<?, ?> t) {
            Document target = new Document();
            for (String key : List.of("type", "id", "label")) {
                if (t.get(key) != null) {
                    target.append(key, ClientInfo.truncate(String.valueOf(t.get(key)), 200));
                }
            }
            if (!target.isEmpty()) {
                entry.append("target", target);
            }
        }
        if (event.get("details") instanceof Map<?, ?> d) {
            Document details = (Document) clean(d, 0);
            if (!details.isEmpty()) {
                entry.append("details", details);
            }
        }
        if (event.get("path") instanceof String path) {
            entry.append("page", ClientInfo.truncate(path, MAX_STRING));
        }
        if (event.get("at") instanceof String at) {
            try {
                entry.append("clientAt", Date.from(Instant.parse(at)));
            } catch (DateTimeParseException ignored) {
                // A bad client clock value is not worth losing the event over.
            }
        }
        return entry;
    }

    private static void fillFromBody(Document client, String key, Object value) {
        if (!client.containsKey(key) && value instanceof String s && ClientInfo.id(s) != null) {
            client.append(key, ClientInfo.id(s));
        }
    }

    /**
     * Keeps free-form details storable and small: nested at most three deep, at
     * most 30 keys per level, strings cut to 500 characters, and no keys MongoDB
     * would treat as operators or paths.
     */
    static Object clean(Object value, int depth) {
        if (value instanceof Map<?, ?> map) {
            Document out = new Document();
            if (depth >= MAX_DEPTH) {
                return out;
            }
            for (Map.Entry<?, ?> e : map.entrySet()) {
                String key = String.valueOf(e.getKey());
                if (out.size() >= MAX_KEYS || key.isEmpty() || key.startsWith("$") || key.contains(".")) {
                    continue;
                }
                out.append(ClientInfo.truncate(key, 64), clean(e.getValue(), depth + 1));
            }
            return out;
        }
        if (value instanceof List<?> list) {
            List<Object> out = new ArrayList<>();
            for (Object o : list.subList(0, Math.min(list.size(), MAX_KEYS))) {
                out.add(clean(o, depth + 1));
            }
            return out;
        }
        if (value instanceof String s) {
            return ClientInfo.truncate(s, MAX_STRING);
        }
        if (value == null || value instanceof Integer || value instanceof Long || value instanceof Double || value instanceof Boolean) {
            return value;
        }
        return ClientInfo.truncate(String.valueOf(value), MAX_STRING);
    }
}
