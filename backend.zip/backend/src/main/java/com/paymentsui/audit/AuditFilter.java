package com.paymentsui.audit;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.servlet.HandlerMapping;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Logs every call to the read API as an audit entry: what was asked for (an
 * action name and the file, batch, transaction or report), with which filters,
 * the outcome and where the call came from. Each response carries an
 * X-Request-Id, the caller's own when it sent one, so a UI event and the API
 * calls behind it can be matched.
 */
@Component
public class AuditFilter extends OncePerRequestFilter {

    /** Action per API route; routes not listed are logged as api.request. */
    static final Map<String, String> ACTIONS = Map.ofEntries(
            Map.entry("/api/summary", "summary.view"),
            Map.entry("/api/search", "search"),
            Map.entry("/api/parties", "parties.list"),
            Map.entry("/api/files", "files.list"),
            Map.entry("/api/files/{id}", "file.view"),
            Map.entry("/api/files/{id}/status", "file.status"),
            Map.entry("/api/files/{id}/batches", "file.batches"),
            Map.entry("/api/files/{id}/graph", "file.graph"),
            Map.entry("/api/files/{id}/xml", "file.xml"),
            Map.entry("/api/batches/{id}", "batch.view"),
            Map.entry("/api/batches/{id}/transactions", "batch.transactions"),
            Map.entry("/api/transactions", "transactions.list"),
            Map.entry("/api/transactions/{id}", "transaction.view"),
            Map.entry("/api/reports", "reports.list"),
            Map.entry("/api/reports/{id}", "report.view"),
            Map.entry("/api/reports/{id}/xml", "report.xml"));
    private static final Map<String, String> TARGET_TYPES = Map.of(
            "files", "file", "batches", "batch", "transactions", "transaction", "reports", "report");

    private final AuditService audit;
    private final boolean enabled;

    public AuditFilter(AuditService audit, @Value("${payments.audit.api-requests:true}") boolean enabled) {
        this.audit = audit;
        this.enabled = enabled;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        // UI events are logged by AuditController, one entry per event.
        return !enabled || !path.startsWith("/api/") || path.startsWith(AuditController.PATH);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String requestId = ClientInfo.id(request.getHeader(ClientInfo.REQUEST_ID));
        if (requestId == null) {
            requestId = UUID.randomUUID().toString();
        }
        response.setHeader(ClientInfo.REQUEST_ID, requestId);
        long start = System.nanoTime();
        try {
            chain.doFilter(request, response);
        } finally {
            long ms = (System.nanoTime() - start) / 1_000_000;
            audit.record(List.of(entry(request, response.getStatus(), ms, requestId)));
        }
    }

    private Document entry(HttpServletRequest request, int status, long ms, String requestId) {
        Object pattern = request.getAttribute(HandlerMapping.BEST_MATCHING_PATTERN_ATTRIBUTE);
        String route = pattern == null ? null : pattern.toString();
        Document entry = audit.entry(request, "api", route == null ? "api.request" : ACTIONS.getOrDefault(route, "api.request"));
        entry.get("client", Document.class).put("requestId", requestId);

        Document target = target(route, request);
        if (target != null) {
            entry.append("target", target);
        }
        Document params = new Document();
        request.getParameterMap().forEach((k, v) -> {
            if (!k.startsWith("$") && !k.contains(".")) {
                params.append(k, v.length == 1 ? ClientInfo.truncate(v[0], 500) : List.of(v));
            }
        });
        if (!params.isEmpty()) {
            entry.append("details", params);
        }
        entry.append("request", new Document("method", request.getMethod())
                .append("path", ClientInfo.truncate(request.getRequestURI(), 500))
                .append("route", route)
                .append("status", status)
                .append("durationMs", ms));
        return entry;
    }

    @SuppressWarnings("unchecked")
    private static Document target(String route, HttpServletRequest request) {
        Object vars = request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        if (route == null || !(vars instanceof Map<?, ?> map) || !map.containsKey("id")) {
            return null;
        }
        String type = TARGET_TYPES.get(route.split("/")[2]);
        return new Document("type", type).append("id", ClientInfo.truncate(((Map<String, String>) map).get("id"), 64));
    }
}
