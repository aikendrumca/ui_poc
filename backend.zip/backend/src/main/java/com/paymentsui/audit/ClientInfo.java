package com.paymentsui.audit;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.bson.Document;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Where a request came from: the source IP and every client identifier the
 * request carries. The UI sends X-Client-Id (kept in the browser), X-Session-Id
 * (one per browser tab session) and X-Request-Id (one per call).
 */
public final class ClientInfo {

    public static final String CLIENT_ID = "X-Client-Id";
    public static final String SESSION_ID = "X-Session-Id";
    public static final String REQUEST_ID = "X-Request-Id";
    static final int MAX_HEADER = 256;
    private static final Pattern ID = Pattern.compile("[A-Za-z0-9._:-]{1,128}");

    private ClientInfo() {
    }

    /**
     * {@code ip} is the first address in X-Forwarded-For when that header is
     * present and trusted (a proxy such as the Docker setup's nginx sets it),
     * otherwise the address of the connection. Both are kept, along with the
     * whole forwarding chain, so a spoofed header can still be told apart.
     */
    public static Document from(HttpServletRequest request, boolean trustForwardedFor) {
        List<String> forwarded = forwardedFor(request.getHeader("X-Forwarded-For"));
        String remote = request.getRemoteAddr();
        String ip = trustForwardedFor && !forwarded.isEmpty() ? forwarded.get(0) : remote;
        Document client = new Document("ip", ip).append("remoteAddr", remote);
        if (!forwarded.isEmpty()) {
            client.append("forwardedFor", forwarded);
        }
        append(client, "realIp", header(request, "X-Real-IP"));
        append(client, "clientId", id(request.getHeader(CLIENT_ID)));
        append(client, "sessionId", id(request.getHeader(SESSION_ID)));
        append(client, "requestId", id(request.getHeader(REQUEST_ID)));
        append(client, "userAgent", header(request, "User-Agent"));
        append(client, "referer", header(request, "Referer"));
        append(client, "origin", header(request, "Origin"));
        append(client, "acceptLanguage", header(request, "Accept-Language"));
        return client;
    }

    static List<String> forwardedFor(String header) {
        List<String> out = new ArrayList<>();
        if (header != null) {
            for (String part : header.split(",")) {
                String p = part.trim();
                if (!p.isEmpty() && out.size() < 10) {
                    out.add(truncate(p, 64));
                }
            }
        }
        return out;
    }

    /** A client-supplied id, kept only if it looks like one. */
    static String id(String value) {
        return value != null && ID.matcher(value.trim()).matches() ? value.trim() : null;
    }

    private static String header(HttpServletRequest request, String name) {
        String v = request.getHeader(name);
        return v == null || v.isBlank() ? null : truncate(v.trim(), MAX_HEADER);
    }

    static String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max);
    }

    private static void append(Document d, String key, Object value) {
        if (value != null) {
            d.append(key, value);
        }
    }
}
