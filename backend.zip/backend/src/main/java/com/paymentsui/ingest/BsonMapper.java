package com.paymentsui.ingest;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.datatype.XMLGregorianCalendar;

import org.bson.Document;
import org.bson.types.Decimal128;

/**
 * Converts the JAXB model of an ISO 20022 message into BSON documents.
 *
 * <p>JAXB field names are the ISO XML tags with a lower-case first letter
 * ({@code PmtInfId} becomes {@code pmtInfId}), so the stored documents keep the
 * ISO vocabulary without a hand-written mapping for every component.
 * Amounts become {@link Decimal128}, dates become BSON dates, code enums become
 * their ISO code, and empty values are dropped.
 */
public final class BsonMapper {

    private static final Map<Class<?>, List<Field>> FIELDS = new ConcurrentHashMap<>();

    private BsonMapper() {
    }

    /** Maps a JAXB object to a document, leaving out the named fields. */
    public static Document toDocument(Object source, Set<String> exclude) {
        Document doc = new Document();
        for (Field field : fieldsOf(source.getClass())) {
            if (exclude.contains(field.getName())) {
                continue;
            }
            Object value;
            try {
                value = convert(field.get(source));
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Cannot read " + field, e);
            }
            if (value != null) {
                doc.append(field.getName(), value);
            }
        }
        return doc;
    }

    public static Document toDocument(Object source) {
        return toDocument(source, Set.of());
    }

    static Object convert(Object value) {
        return switch (value) {
            case null -> null;
            case String s -> s.isEmpty() ? null : s;
            case Boolean b -> b;
            case Integer i -> i;
            case Long l -> l;
            case BigDecimal d -> new Decimal128(d);
            case BigInteger i -> new Decimal128(new BigDecimal(i));
            case LocalDate d -> Date.from(d.atStartOfDay(ZoneOffset.UTC).toInstant());
            case LocalDateTime d -> Date.from(d.toInstant(ZoneOffset.UTC));
            case OffsetDateTime d -> Date.from(d.toInstant());
            case LocalTime t -> t.toString();
            case OffsetTime t -> t.toString();
            case XMLGregorianCalendar c -> c.toGregorianCalendar().getTime();
            case byte[] bytes -> bytes;
            case Enum<?> e -> codeOf(e);
            case Collection<?> c -> {
                List<Object> list = new ArrayList<>(c.size());
                for (Object item : c) {
                    Object converted = convert(item);
                    if (converted != null) {
                        list.add(converted);
                    }
                }
                yield list.isEmpty() ? null : list;
            }
            default -> {
                Document nested = toDocument(value);
                yield nested.isEmpty() ? null : nested;
            }
        };
    }

    /** ISO code enums expose the XML value through {@code value()}; fall back to the constant name. */
    private static String codeOf(Enum<?> e) {
        try {
            return (String) e.getClass().getMethod("value").invoke(e);
        } catch (ReflectiveOperationException | ClassCastException ex) {
            return e.name();
        }
    }

    private static List<Field> fieldsOf(Class<?> type) {
        return FIELDS.computeIfAbsent(type, t -> {
            List<Field> fields = new ArrayList<>();
            for (Class<?> c = t; c != null && c != Object.class; c = c.getSuperclass()) {
                for (Field f : c.getDeclaredFields()) {
                    int mod = f.getModifiers();
                    if (Modifier.isStatic(mod) || Modifier.isTransient(mod) || f.isSynthetic()) {
                        continue;
                    }
                    f.setAccessible(true);
                    fields.add(f);
                }
            }
            return List.copyOf(fields);
        });
    }
}
