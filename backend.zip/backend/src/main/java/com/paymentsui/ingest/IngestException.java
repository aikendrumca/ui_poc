package com.paymentsui.ingest;

/** A file that cannot be loaded; the message says why and is shown to operators. */
public class IngestException extends RuntimeException {

    public IngestException(String message) {
        super(message);
    }
}
