package com.paymentsui.ingest;

import java.io.ByteArrayInputStream;
import java.time.Instant;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.InsertManyOptions;

/**
 * Loads pain.001 files and, through {@link StatusReportService}, pain.002 status
 * reports. A mapped pain.001 file is stored as follows. Transactions and batches are written before the
 * file document, so a file only shows up in the UI once all of its children are
 * present; a failure part-way removes whatever was written. This works on a
 * standalone MongoDB, which has no multi-document transactions.
 */
@Service
public class IngestService {

    private static final Logger log = LoggerFactory.getLogger(IngestService.class);

    private final MongoDatabase db;
    private final GridFSBucket rawXml;
    private final StatusReportService statusReports;

    public IngestService(MongoDatabase db) {
        this.db = db;
        this.rawXml = GridFSBuckets.create(db, "rawXml");
        this.statusReports = new StatusReportService(db, rawXml);
    }

    /** Loads a pain.001 or pain.002 message, picked by its namespace, and says what was loaded. */
    public String load(byte[] xml, String fileName, String channel) {
        if (new String(xml, java.nio.charset.StandardCharsets.UTF_8).contains(Pain002Mapper.NAMESPACE)) {
            StatusReportService.Result r = statusReports.ingest(xml, fileName, channel);
            return "status report " + r.msgId() + " for " + r.orgnlMsgId() + " (" + r.linkStatus() + ")";
        }
        Result r = ingest(xml, fileName, channel);
        return "file " + r.msgId() + " (" + r.transactions() + " transactions, " + r.validationStatus() + ")";
    }

    public record Result(ObjectId fileId, String msgId, int batches, int transactions, String validationStatus) {
    }

    public Result ingest(byte[] xml, String fileName, String channel) {
        Pain001Mapper.Mapped mapped = Pain001Mapper.map(xml, new Pain001Mapper.Source(fileName, Instant.now(), channel));
        Document file = mapped.file();
        ObjectId fileId = file.getObjectId("_id");
        String msgId = file.getString("msgId");
        String sha = file.get("source", Document.class).getString("sha256");

        if (db.getCollection("files").find(Filters.eq("source.sha256", sha)).first() != null) {
            throw new IngestException("Duplicate file: identical content already loaded (sha256 " + sha + ")");
        }
        Document initgPty = file.get("initgPty", Document.class);
        String initgNm = initgPty == null ? null : initgPty.getString("nm");
        if (db.getCollection("files").find(Filters.and(Filters.eq("msgId", msgId), Filters.eq("initgPty.nm", initgNm))).first() != null) {
            throw new IngestException("Duplicate MsgId " + msgId + " for initiating party " + initgNm);
        }

        ObjectId rawId = null;
        try {
            insertAll("transactions", mapped.transactions());
            insertAll("batches", mapped.batches());
            rawId = rawXml.uploadFromStream(fileName, new ByteArrayInputStream(xml));
            file.append("rawXmlRef", rawId);
            db.getCollection("files").insertOne(file);
        } catch (RuntimeException e) {
            rollback(fileId, rawId);
            if (e instanceof MongoWriteException mwe && mwe.getError().getCode() == 11000) {
                throw new IngestException("Duplicate file: " + mwe.getError().getMessage());
            }
            throw e;
        }

        // Status reports that arrived before this file are linked now.
        statusReports.relink(msgId);
        String status = file.get("validation", Document.class).getString("status");
        log.info("Loaded {} msgId={} batches={} txs={} validation={}", fileName, msgId,
                mapped.batches().size(), mapped.transactions().size(), status);
        return new Result(fileId, msgId, mapped.batches().size(), mapped.transactions().size(), status);
    }

    private void insertAll(String collection, List<Document> docs) {
        int chunk = 1000;
        for (int i = 0; i < docs.size(); i += chunk) {
            db.getCollection(collection).insertMany(docs.subList(i, Math.min(docs.size(), i + chunk)),
                    new InsertManyOptions().ordered(true));
        }
    }

    private void rollback(ObjectId fileId, ObjectId rawId) {
        try {
            if (rawId != null) {
                rawXml.delete(rawId);
            }
            db.getCollection("transactions").deleteMany(Filters.eq("fileId", fileId));
            db.getCollection("batches").deleteMany(Filters.eq("fileId", fileId));
            db.getCollection("files").deleteOne(Filters.eq("_id", fileId));
        } catch (RuntimeException e) {
            log.error("Rollback of partially loaded file {} failed", fileId, e);
        }
    }
}
