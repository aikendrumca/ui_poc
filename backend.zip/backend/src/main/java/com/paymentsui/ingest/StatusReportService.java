package com.paymentsui.ingest;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.exists;
import static com.mongodb.client.model.Filters.lte;
import static com.mongodb.client.model.Filters.or;

import java.io.ByteArrayInputStream;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.Updates;

/**
 * Stores pain.002 status reports, links them to the original pain.001 file,
 * batches and transactions, and copies the latest status onto each of them.
 *
 * <p>Links follow the ISO references: OrgnlMsgId finds the file, OrgnlPmtInfId
 * the batch, and OrgnlUETR, OrgnlEndToEndId or OrgnlInstrId the transaction.
 * A group status other than PART applies to every batch and transaction of the
 * file, and a payment information status other than PART to every transaction
 * of the batch, unless a more specific status in the same or a later report
 * says otherwise. The newest report (by its CreDtTm) wins. A report whose
 * original file is not loaded yet is kept unlinked and linked when that file
 * arrives.
 */
public class StatusReportService {

    private static final Logger log = LoggerFactory.getLogger(StatusReportService.class);
    static final String PARTIAL = "PART";

    private final MongoCollection<Document> reports;
    private final MongoCollection<Document> files;
    private final MongoCollection<Document> batches;
    private final MongoCollection<Document> transactions;
    private final GridFSBucket rawXml;

    public StatusReportService(MongoDatabase db, GridFSBucket rawXml) {
        this.reports = db.getCollection("statusReports");
        this.files = db.getCollection("files");
        this.batches = db.getCollection("batches");
        this.transactions = db.getCollection("transactions");
        this.rawXml = rawXml;
    }

    public record Result(ObjectId reportId, String msgId, String orgnlMsgId, ObjectId fileId, String linkStatus) {
    }

    public Result ingest(byte[] xml, String fileName, String channel) {
        Document report = Pain002Mapper.map(xml, new Pain001Mapper.Source(fileName, Instant.now(), channel));
        String sha = report.get("source", Document.class).getString("sha256");
        String msgId = report.getString("msgId");
        String orgnlMsgId = report.get("orgnlGrpInfAndSts", Document.class).getString("orgnlMsgId");

        if (reports.find(eq("source.sha256", sha)).first() != null) {
            throw new IngestException("Duplicate status report: identical content already loaded (sha256 " + sha + ")");
        }
        if (reports.find(and(eq("msgId", msgId), eq("orgnlGrpInfAndSts.orgnlMsgId", orgnlMsgId))).first() != null) {
            throw new IngestException("Duplicate status report MsgId " + msgId + " for original message " + orgnlMsgId);
        }

        link(report);
        ObjectId rawId = rawXml.uploadFromStream(fileName, new ByteArrayInputStream(xml));
        report.append("rawXmlRef", rawId);
        try {
            reports.insertOne(report);
        } catch (RuntimeException e) {
            rawXml.delete(rawId);
            if (e instanceof MongoWriteException mwe && mwe.getError().getCode() == 11000) {
                throw new IngestException("Duplicate status report: " + mwe.getError().getMessage());
            }
            throw e;
        }
        apply(report);

        String linkStatus = report.get("link", Document.class).getString("status");
        log.info("Loaded status report {} msgId={} for {} link={}", fileName, msgId, orgnlMsgId, linkStatus);
        return new Result(report.getObjectId("_id"), msgId, orgnlMsgId, report.getObjectId("fileId"), linkStatus);
    }

    /** Links and applies reports that arrived before their original file. Returns how many were linked. */
    public int relink(String msgId) {
        int linked = 0;
        for (Document report : reports.find(and(eq("orgnlGrpInfAndSts.orgnlMsgId", msgId), eq("fileId", null)))
                .sort(Sorts.ascending("creDtTm", "_id"))) {
            link(report);
            if (report.getObjectId("fileId") != null) {
                reports.replaceOne(eq("_id", report.getObjectId("_id")), report);
                apply(report);
                linked++;
            }
        }
        return linked;
    }

    /** Fills in fileId, batchId and txId references and a {@code link} summary of what could not be matched. */
    void link(Document report) {
        Document grp = report.get("orgnlGrpInfAndSts", Document.class);
        List<Document> issues = new ArrayList<>();
        Document file = findFile(grp);
        report.put("fileId", file == null ? null : file.getObjectId("_id"));
        List<Document> pmtInfs = report.getList("orgnlPmtInfAndSts", Document.class);
        if (file == null) {
            issues.add(issue("ERROR", "UNKNOWN_ORIGINAL", "OrgnlGrpInfAndSts/OrgnlMsgId",
                    "No loaded pain.001 file has MsgId " + grp.getString("orgnlMsgId")));
            pmtInfs.forEach(p -> {
                p.put("batchId", null);
                p.getList("txInfAndSts", Document.class).forEach(t -> t.put("txId", null));
            });
            report.put("link", new Document("status", "UNMATCHED").append("issues", issues));
            return;
        }
        ObjectId fileId = file.getObjectId("_id");
        Integer declared = parseCount(grp.getString("orgnlNbOfTxs"));
        Integer actual = file.getInteger("nbOfTxs");
        if (declared != null && !declared.equals(actual)) {
            issues.add(issue("WARN", "COUNT_DIFFERS", "OrgnlGrpInfAndSts/OrgnlNbOfTxs",
                    "Report says the original had " + declared + " transactions, the loaded file declares " + actual));
        }
        for (Document pmtInf : pmtInfs) {
            String path = "OrgnlPmtInfAndSts[" + pmtInf.getInteger("seq") + "]";
            String pmtInfId = pmtInf.getString("orgnlPmtInfId");
            Document batch = pmtInfId == null ? null
                    : batches.find(and(eq("fileId", fileId), eq("pmtInfId", pmtInfId))).projection(Projections.include("_id")).first();
            if (pmtInfId != null && batch == null) {
                issues.add(issue("ERROR", "UNKNOWN_BATCH", path + "/OrgnlPmtInfId", "No batch " + pmtInfId + " in the original file"));
            }
            ObjectId batchId = batch == null ? null : batch.getObjectId("_id");
            pmtInf.put("batchId", batchId);
            for (Document tx : pmtInf.getList("txInfAndSts", Document.class)) {
                tx.put("txId", findTransaction(fileId, batchId, tx, path + "/TxInfAndSts[" + tx.getInteger("seq") + "]", issues));
            }
        }
        boolean errors = issues.stream().anyMatch(i -> "ERROR".equals(i.getString("severity")));
        report.put("link", new Document("status", errors ? "PARTIAL" : "LINKED").append("issues", issues));
    }

    private Document findFile(Document grp) {
        List<Document> candidates = files.find(eq("msgId", grp.getString("orgnlMsgId")))
                .projection(Projections.include("_id", "creDtTm", "nbOfTxs"))
                .sort(Sorts.descending("source.receivedAt")).into(new ArrayList<>());
        // The same MsgId can come from different initiating parties; OrgnlCreDtTm tells them apart.
        Date created = grp.getDate("orgnlCreDtTm");
        return candidates.stream().filter(f -> created != null && created.equals(f.getDate("creDtTm"))).findFirst()
                .orElse(candidates.isEmpty() ? null : candidates.get(0));
    }

    private ObjectId findTransaction(ObjectId fileId, ObjectId batchId, Document tx, String path, List<Document> issues) {
        List<Bson> filters = new ArrayList<>();
        filters.add(eq("fileId", fileId));
        if (batchId != null) {
            filters.add(eq("batchId", batchId));
        }
        String uetr = tx.getString("orgnlUETR");
        String e2e = tx.getString("orgnlEndToEndId");
        String instrId = tx.getString("orgnlInstrId");
        String ref;
        if (uetr != null) {
            filters.add(eq("pmtId.uetr", uetr.toLowerCase()));
            ref = "UETR " + uetr;
        } else if (e2e != null && !"NOTPROVIDED".equals(e2e)) {
            filters.add(eq("pmtId.endToEndId", e2e));
            if (instrId != null) {
                filters.add(eq("pmtId.instrId", instrId));
            }
            ref = "EndToEndId " + e2e;
        } else if (instrId != null) {
            filters.add(eq("pmtId.instrId", instrId));
            ref = "InstrId " + instrId;
        } else {
            issues.add(issue("ERROR", "NO_TX_REFERENCE", path, "No OrgnlUETR, OrgnlEndToEndId or OrgnlInstrId to match on"));
            return null;
        }
        List<Document> matches = transactions.find(and(filters)).projection(Projections.include("_id"))
                .sort(Sorts.ascending("seq")).limit(2).into(new ArrayList<>());
        if (matches.isEmpty()) {
            issues.add(issue("ERROR", "UNKNOWN_TX", path, "No transaction with " + ref + " in the original file"));
            return null;
        }
        if (matches.size() > 1) {
            issues.add(issue("WARN", "AMBIGUOUS_TX", path, "More than one transaction has " + ref + "; linked to the first"));
        }
        return matches.get(0).getObjectId("_id");
    }

    /** Copies the report's statuses onto the linked file, batches and transactions, unless they hold a newer one. */
    void apply(Document report) {
        ObjectId fileId = report.getObjectId("fileId");
        if (fileId == null) {
            return;
        }
        Date created = report.getDate("creDtTm");
        Date at = created != null ? created : report.get("source", Document.class).getDate("receivedAt");
        Document grp = report.get("orgnlGrpInfAndSts", Document.class);
        String grpSts = grp.getString("grpSts");
        if (grpSts != null) {
            Document status = status(report, at, "GROUP", grpSts, grp);
            files.updateOne(newerThan(eq("_id", fileId), at), Updates.set("status", status));
            if (!PARTIAL.equals(grpSts)) {
                batches.updateMany(newerThan(eq("fileId", fileId), at), Updates.set("status", status));
                transactions.updateMany(newerThan(eq("fileId", fileId), at), Updates.set("status", status));
            }
        }
        for (Document pmtInf : report.getList("orgnlPmtInfAndSts", Document.class)) {
            ObjectId batchId = pmtInf.getObjectId("batchId");
            String sts = pmtInf.getString("pmtInfSts");
            if (batchId != null && sts != null) {
                Document status = status(report, at, "PMTINF", sts, pmtInf);
                batches.updateOne(newerThan(eq("_id", batchId), at), Updates.set("status", status));
                if (!PARTIAL.equals(sts)) {
                    transactions.updateMany(newerThan(eq("batchId", batchId), at), Updates.set("status", status));
                }
            }
            for (Document tx : pmtInf.getList("txInfAndSts", Document.class)) {
                ObjectId txId = tx.getObjectId("txId");
                if (txId != null && tx.getString("txSts") != null) {
                    transactions.updateOne(newerThan(eq("_id", txId), at),
                            Updates.set("status", status(report, at, "TX", tx.getString("txSts"), tx)));
                }
            }
        }
    }

    private static Bson newerThan(Bson target, Date at) {
        return and(target, or(exists("status.at", false), lte("status.at", at)));
    }

    /** The status as copied onto a file, batch or transaction: code, first reason, and which report said so. */
    public static Document status(Document report, Date at, String level, String code, Document source) {
        Document status = new Document("code", code).append("level", level).append("at", at)
                .append("reportId", report.getObjectId("_id")).append("reportMsgId", report.getString("msgId"));
        List<Document> reasons = source.getList("stsRsnInf", Document.class);
        if (reasons != null && !reasons.isEmpty()) {
            Document first = reasons.get(0);
            Document rsn = first.get("rsn", Document.class);
            if (rsn != null) {
                status.append("rsn", rsn.getString("cd") != null ? rsn.getString("cd") : rsn.getString("prtry"));
            }
            List<String> info = first.getList("addtlInf", String.class);
            if (info != null) {
                status.append("addtlInf", String.join(" ", info));
            }
        }
        return status;
    }

    private static Document issue(String severity, String code, String path, String msg) {
        return new Document("severity", severity).append("code", code).append("path", path).append("msg", msg);
    }

    private static Integer parseCount(String value) {
        try {
            return value == null ? null : Integer.valueOf(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
