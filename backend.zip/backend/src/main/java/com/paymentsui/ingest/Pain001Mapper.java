package com.paymentsui.ingest;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.bson.Document;
import org.bson.types.Decimal128;
import org.bson.types.ObjectId;

import com.prowidesoftware.swift.model.mx.MxPain00100109;
import com.prowidesoftware.swift.model.mx.dic.ActiveOrHistoricCurrencyAndAmount;
import com.prowidesoftware.swift.model.mx.dic.BranchAndFinancialInstitutionIdentification6;
import com.prowidesoftware.swift.model.mx.dic.CashAccount38;
import com.prowidesoftware.swift.model.mx.dic.CreditTransferTransaction34;
import com.prowidesoftware.swift.model.mx.dic.CustomerCreditTransferInitiationV09;
import com.prowidesoftware.swift.model.mx.dic.DateAndDateTime2Choice;
import com.prowidesoftware.swift.model.mx.dic.GroupHeader85;
import com.prowidesoftware.swift.model.mx.dic.PartyIdentification135;
import com.prowidesoftware.swift.model.mx.dic.PaymentInstruction30;

/**
 * Turns one pain.001.001.09 XML message into the documents stored in the
 * {@code files}, {@code batches} and {@code transactions} collections, with
 * links, counts, totals and consistency checks filled in.
 */
public final class Pain001Mapper {

    public static final String NAMESPACE = "urn:iso:std:iso:20022:tech:xsd:pain.001.001.09";

    public record Source(String fileName, Instant receivedAt, String channel) {
    }

    public record Mapped(Document file, List<Document> batches, List<Document> transactions) {
    }

    private Pain001Mapper() {
    }

    public static Mapped map(byte[] xml, Source source) {
        String text = new String(xml, StandardCharsets.UTF_8);
        if (!text.contains(NAMESPACE)) {
            throw new IngestException("Not a pain.001.001.09 message (namespace " + NAMESPACE + " not found)");
        }
        MxPain00100109 mx = MxPain00100109.parse(text);
        CustomerCreditTransferInitiationV09 msg = mx == null ? null : mx.getCstmrCdtTrfInitn();
        if (msg == null || msg.getGrpHdr() == null || msg.getPmtInf().isEmpty()) {
            throw new IngestException("Could not parse CstmrCdtTrfInitn with a GrpHdr and at least one PmtInf");
        }

        GroupHeader85 hdr = msg.getGrpHdr();
        ObjectId fileId = new ObjectId();
        Issues fileIssues = new Issues();
        List<Document> batches = new ArrayList<>();
        List<Document> transactions = new ArrayList<>();
        Totals fileTotals = new Totals();
        int fileTxCount = 0;
        BigDecimal fileSum = BigDecimal.ZERO;

        for (int b = 0; b < msg.getPmtInf().size(); b++) {
            PaymentInstruction30 pmtInf = msg.getPmtInf().get(b);
            ObjectId batchId = new ObjectId();
            String path = "PmtInf[" + b + "]";
            Issues batchIssues = new Issues();
            Totals batchTotals = new Totals();
            BigDecimal batchSum = BigDecimal.ZERO;
            Set<String> endToEndIds = new HashSet<>();
            Date reqdExctnDt = dateOf(pmtInf.getReqdExctnDt());

            for (int t = 0; t < pmtInf.getCdtTrfTxInf().size(); t++) {
                CreditTransferTransaction34 tx = pmtInf.getCdtTrfTxInf().get(t);
                ActiveOrHistoricCurrencyAndAmount amt = amountOf(tx);
                if (amt != null && amt.getValue() != null) {
                    batchTotals.add(amt.getCcy(), amt.getValue());
                    batchSum = batchSum.add(amt.getValue());
                }
                String e2e = tx.getPmtId() == null ? null : tx.getPmtId().getEndToEndId();
                if (e2e != null && !"NOTPROVIDED".equals(e2e) && !endToEndIds.add(e2e)) {
                    batchIssues.warn("DUPLICATE_E2E", path + "/CdtTrfTxInf[" + t + "]/PmtId/EndToEndId",
                            "EndToEndId " + e2e + " is used more than once in this batch");
                }

                Document doc = new Document("_id", new ObjectId())
                        .append("fileId", fileId)
                        .append("batchId", batchId)
                        .append("msgId", hdr.getMsgId())
                        .append("pmtInfId", pmtInf.getPmtInfId())
                        .append("seq", t);
                doc.putAll(BsonMapper.toDocument(tx));
                doc.append("view", view(pmtInf, tx, amt, reqdExctnDt)
                        .append("initgPtyNm", hdr.getInitgPty() == null ? null : hdr.getInitgPty().getNm())
                        .append("creDtTm", hdr.getCreDtTm() == null ? null : Date.from(hdr.getCreDtTm().toInstant()))
                        .append("receivedAt", Date.from(source.receivedAt())));
                doc.get("view", Document.class).values().removeIf(java.util.Objects::isNull);
                transactions.add(doc);
            }

            int txCount = pmtInf.getCdtTrfTxInf().size();
            checkCount(batchIssues, path + "/NbOfTxs", pmtInf.getNbOfTxs(), txCount);
            checkSum(batchIssues, path + "/CtrlSum", pmtInf.getCtrlSum(), batchSum);
            if (reqdExctnDt != null && hdr.getCreDtTm() != null
                    && reqdExctnDt.toInstant().isBefore(hdr.getCreDtTm().toLocalDate().atStartOfDay(ZoneOffset.UTC).toInstant())) {
                batchIssues.warn("PAST_EXECUTION_DATE", path + "/ReqdExctnDt", "Requested execution date is before the file creation date");
            }

            Document batch = new Document("_id", batchId)
                    .append("fileId", fileId)
                    .append("msgId", hdr.getMsgId())
                    .append("seq", b);
            batch.putAll(BsonMapper.toDocument(pmtInf, Set.of("cdtTrfTxInf", "nbOfTxs", "reqdExctnDt")));
            batch.append("nbOfTxs", parseCount(pmtInf.getNbOfTxs()));
            batch.append("reqdExctnDt", new Document("date", reqdExctnDt)
                    .append("hasTime", pmtInf.getReqdExctnDt() != null && pmtInf.getReqdExctnDt().getDtTm() != null));
            batch.append("stats", new Document("txCount", txCount)
                    .append("totalsByCcy", batchTotals.toList()));
            batch.append("validation", batchIssues.toDocument());
            batches.add(batch);

            fileIssues.absorb(batchIssues);
            fileTotals.merge(batchTotals);
            fileTxCount += txCount;
            fileSum = fileSum.add(batchSum);
        }

        checkCount(fileIssues, "GrpHdr/NbOfTxs", hdr.getNbOfTxs(), fileTxCount);
        checkSum(fileIssues, "GrpHdr/CtrlSum", hdr.getCtrlSum(), fileSum);

        Document file = new Document("_id", fileId);
        file.putAll(BsonMapper.toDocument(hdr, Set.of("nbOfTxs")));
        file.append("nbOfTxs", parseCount(hdr.getNbOfTxs()));
        file.append("source", new Document("fileName", source.fileName())
                .append("receivedAt", Date.from(source.receivedAt()))
                .append("sha256", sha256(xml))
                .append("sizeBytes", (long) xml.length)
                .append("channel", source.channel()));
        file.append("stats", new Document("batchCount", batches.size())
                .append("txCount", fileTxCount)
                .append("totalsByCcy", fileTotals.toList()));
        file.append("validation", fileIssues.toDocument());
        return new Mapped(file, batches, transactions);
    }

    /** Flat, denormalised fields the list and search screens read without a join. */
    private static Document view(PaymentInstruction30 pmtInf, CreditTransferTransaction34 tx,
            ActiveOrHistoricCurrencyAndAmount amt, Date reqdExctnDt) {
        Document v = new Document();
        if (amt != null) {
            v.append("amount", amt.getValue() == null ? null : new Decimal128(amt.getValue()))
                    .append("ccy", amt.getCcy());
        }
        v.append("reqdExctnDt", reqdExctnDt)
                .append("pmtMtd", pmtInf.getPmtMtd() == null ? null : pmtInf.getPmtMtd().value())
                .append("dbtrNm", name(pmtInf.getDbtr()))
                .append("dbtrAcct", account(pmtInf.getDbtrAcct()))
                .append("dbtrBic", bic(pmtInf.getDbtrAgt()))
                .append("cdtrNm", name(tx.getCdtr()))
                .append("cdtrAcct", account(tx.getCdtrAcct()))
                .append("cdtrBic", bic(tx.getCdtrAgt()));
        if (tx.getRmtInf() != null && !tx.getRmtInf().getUstrd().isEmpty()) {
            v.append("rmtInf", String.join(" ", tx.getRmtInf().getUstrd()));
        }
        v.values().removeIf(java.util.Objects::isNull);
        return v;
    }

    private static ActiveOrHistoricCurrencyAndAmount amountOf(CreditTransferTransaction34 tx) {
        if (tx.getAmt() == null) {
            return null;
        }
        if (tx.getAmt().getInstdAmt() != null) {
            return tx.getAmt().getInstdAmt();
        }
        return tx.getAmt().getEqvtAmt() == null ? null : tx.getAmt().getEqvtAmt().getAmt();
    }

    private static Date dateOf(DateAndDateTime2Choice choice) {
        if (choice == null) {
            return null;
        }
        if (choice.getDtTm() != null) {
            return Date.from(choice.getDtTm().toInstant());
        }
        return choice.getDt() == null ? null : Date.from(choice.getDt().atStartOfDay(ZoneOffset.UTC).toInstant());
    }

    private static String name(PartyIdentification135 party) {
        return party == null ? null : party.getNm();
    }

    private static String account(CashAccount38 acct) {
        if (acct == null || acct.getId() == null) {
            return null;
        }
        if (acct.getId().getIBAN() != null) {
            return acct.getId().getIBAN();
        }
        return acct.getId().getOthr() == null ? null : acct.getId().getOthr().getId();
    }

    private static String bic(BranchAndFinancialInstitutionIdentification6 agent) {
        return agent == null || agent.getFinInstnId() == null ? null : agent.getFinInstnId().getBICFI();
    }

    private static Integer parseCount(String value) {
        try {
            return value == null ? null : Integer.valueOf(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static void checkCount(Issues issues, String path, String declared, int actual) {
        Integer n = parseCount(declared);
        if (n == null) {
            issues.error("BAD_NB_OF_TXS", path, "NbOfTxs '" + declared + "' is not a number");
        } else if (n != actual) {
            issues.error("NB_OF_TXS_MISMATCH", path, "Declared " + n + " transactions, found " + actual);
        }
    }

    private static void checkSum(Issues issues, String path, BigDecimal declared, BigDecimal actual) {
        if (declared != null && declared.compareTo(actual) != 0) {
            issues.error("CTRL_SUM_MISMATCH", path,
                    "Declared control sum " + declared.toPlainString() + ", actual " + actual.toPlainString());
        }
    }

    static String sha256(byte[] data) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Sums amounts per currency; control sums in pain.001 are currency-agnostic, totals are not. */
    private static final class Totals {
        private final Map<String, BigDecimal> byCcy = new TreeMap<>();
        private final Map<String, Integer> counts = new HashMap<>();

        void add(String ccy, BigDecimal amount) {
            String key = ccy == null ? "???" : ccy;
            byCcy.merge(key, amount, BigDecimal::add);
            counts.merge(key, 1, Integer::sum);
        }

        void merge(Totals other) {
            other.byCcy.forEach((k, v) -> byCcy.merge(k, v, BigDecimal::add));
            other.counts.forEach((k, v) -> counts.merge(k, v, Integer::sum));
        }

        List<Document> toList() {
            List<Document> list = new ArrayList<>();
            byCcy.forEach((ccy, amount) -> list.add(new Document("ccy", ccy)
                    .append("amount", new Decimal128(amount))
                    .append("count", counts.get(ccy))));
            return list;
        }
    }

    private static final class Issues {
        private final List<Document> items = new ArrayList<>();
        private boolean error;

        void error(String code, String path, String msg) {
            error = true;
            items.add(new Document("severity", "ERROR").append("code", code).append("path", path).append("msg", msg));
        }

        void warn(String code, String path, String msg) {
            items.add(new Document("severity", "WARN").append("code", code).append("path", path).append("msg", msg));
        }

        void absorb(Issues other) {
            items.addAll(other.items);
            error |= other.error;
        }

        Document toDocument() {
            String status = error ? "INVALID" : items.isEmpty() ? "VALID" : "WARN";
            return new Document("status", status).append("issues", items);
        }
    }
}
