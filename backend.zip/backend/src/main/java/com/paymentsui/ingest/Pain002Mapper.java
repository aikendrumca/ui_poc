package com.paymentsui.ingest;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.bson.Document;
import org.bson.types.ObjectId;

import com.prowidesoftware.swift.model.mx.MxPain00200110;
import com.prowidesoftware.swift.model.mx.dic.CustomerPaymentStatusReportV10;
import com.prowidesoftware.swift.model.mx.dic.OriginalPaymentInstruction32;
import com.prowidesoftware.swift.model.mx.dic.PaymentTransaction105;

/**
 * Turns one pain.002.001.10 customer payment status report into the document
 * stored in the {@code statusReports} collection. Links to the original
 * pain.001 file, batches and transactions are added by {@link StatusReportService}.
 */
public final class Pain002Mapper {

    public static final String NAMESPACE = "urn:iso:std:iso:20022:tech:xsd:pain.002.001.10";

    private Pain002Mapper() {
    }

    public static Document map(byte[] xml, Pain001Mapper.Source source) {
        String text = new String(xml, StandardCharsets.UTF_8);
        if (!text.contains(NAMESPACE)) {
            throw new IngestException("Not a pain.002.001.10 message (namespace " + NAMESPACE + " not found)");
        }
        MxPain00200110 mx = MxPain00200110.parse(text);
        CustomerPaymentStatusReportV10 msg = mx == null ? null : mx.getCstmrPmtStsRpt();
        if (msg == null || msg.getGrpHdr() == null || msg.getOrgnlGrpInfAndSts() == null
                || msg.getOrgnlGrpInfAndSts().getOrgnlMsgId() == null) {
            throw new IngestException("Could not parse CstmrPmtStsRpt with a GrpHdr and OrgnlGrpInfAndSts/OrgnlMsgId");
        }

        Document report = new Document("_id", new ObjectId());
        report.putAll(BsonMapper.toDocument(msg.getGrpHdr()));
        report.append("orgnlGrpInfAndSts", BsonMapper.toDocument(msg.getOrgnlGrpInfAndSts()));

        Map<String, Integer> byStatus = new TreeMap<>();
        List<Document> pmtInfs = new ArrayList<>();
        int txCount = 0;
        for (int b = 0; b < msg.getOrgnlPmtInfAndSts().size(); b++) {
            OriginalPaymentInstruction32 pmtInf = msg.getOrgnlPmtInfAndSts().get(b);
            List<Document> txs = new ArrayList<>();
            for (int t = 0; t < pmtInf.getTxInfAndSts().size(); t++) {
                PaymentTransaction105 tx = pmtInf.getTxInfAndSts().get(t);
                Document doc = new Document("seq", t);
                doc.putAll(BsonMapper.toDocument(tx));
                txs.add(doc);
                if (tx.getTxSts() != null) {
                    byStatus.merge(tx.getTxSts(), 1, Integer::sum);
                }
            }
            txCount += txs.size();
            Document doc = new Document("seq", b);
            doc.putAll(BsonMapper.toDocument(pmtInf, Set.of("txInfAndSts")));
            doc.append("txInfAndSts", txs);
            pmtInfs.add(doc);
        }
        report.append("orgnlPmtInfAndSts", pmtInfs);

        List<Document> counts = new ArrayList<>();
        byStatus.forEach((sts, n) -> counts.add(new Document("sts", sts).append("count", n)));
        report.append("source", new Document("fileName", source.fileName())
                .append("receivedAt", Date.from(source.receivedAt()))
                .append("sha256", Pain001Mapper.sha256(xml))
                .append("sizeBytes", (long) xml.length)
                .append("channel", source.channel()));
        report.append("stats", new Document("pmtInfCount", pmtInfs.size())
                .append("txCount", txCount)
                .append("txByStatus", counts));
        return report;
    }
}
