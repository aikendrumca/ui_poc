package com.paymentsui.ingest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Loads pain.001 files and pain.002 status reports dropped into the inbox folder. A loaded file moves to
 * {@code processed/<date>/}; a rejected one moves to {@code failed/} next to a
 * {@code .error.txt} explaining why.
 */
@Component
@ConditionalOnProperty(name = "payments.inbox.enabled", havingValue = "true", matchIfMissing = true)
public class InboxWatcher {

    private static final Logger log = LoggerFactory.getLogger(InboxWatcher.class);

    private final IngestService ingest;
    private final Path inbox;

    public InboxWatcher(IngestService ingest, @Value("${payments.inbox.dir}") String inbox) throws IOException {
        this.ingest = ingest;
        this.inbox = Path.of(inbox).toAbsolutePath().normalize();
        Files.createDirectories(this.inbox);
        log.info("Watching {} for pain.001.001.09 files and pain.002.001.10 status reports", this.inbox);
    }

    @Scheduled(initialDelayString = "${payments.inbox.initial-delay:2s}", fixedDelayString = "${payments.inbox.poll-interval:10s}")
    public void poll() {
        List<Path> files;
        try (Stream<Path> s = Files.list(inbox)) {
            files = s.filter(Files::isRegularFile)
                    .filter(p -> p.getFileName().toString().toLowerCase().endsWith(".xml"))
                    .sorted()
                    .toList();
        } catch (IOException e) {
            log.error("Cannot list inbox {}", inbox, e);
            return;
        }
        for (Path file : files) {
            load(file);
        }
    }

    private void load(Path file) {
        String name = file.getFileName().toString();
        try {
            byte[] xml = Files.readAllBytes(file);
            ingest.load(xml, name, "inbox");
            move(file, inbox.resolve("processed").resolve(LocalDate.now().toString()));
        } catch (Exception e) {
            String reason = e instanceof IngestException ? e.getMessage() : e.toString();
            log.warn("Rejected {}: {}", name, reason);
            try {
                Path failed = move(file, inbox.resolve("failed"));
                Files.writeString(failed.resolveSibling(failed.getFileName() + ".error.txt"), reason + System.lineSeparator());
            } catch (IOException io) {
                log.error("Cannot move rejected file {}", file, io);
            }
        }
    }

    private static Path move(Path file, Path dir) throws IOException {
        Files.createDirectories(dir);
        Path target = dir.resolve(file.getFileName());
        if (Files.exists(target)) {
            target = dir.resolve(System.currentTimeMillis() + "-" + file.getFileName());
        }
        return Files.move(file, target, StandardCopyOption.ATOMIC_MOVE);
    }
}
