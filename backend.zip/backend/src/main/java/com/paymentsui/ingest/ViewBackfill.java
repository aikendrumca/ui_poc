package com.paymentsui.ingest;

import java.util.Date;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;

/**
 * Transactions loaded before the initiating-party and file-time filters existed
 * lack {@code view.initgPtyNm}, {@code view.creDtTm} and {@code view.receivedAt}.
 * Copies them down from each file once at startup; does nothing when every
 * transaction already has them.
 */
@Component
public class ViewBackfill {

    private static final Logger log = LoggerFactory.getLogger(ViewBackfill.class);

    private final MongoDatabase db;

    public ViewBackfill(MongoDatabase db) {
        this.db = db;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void run() {
        var txs = db.getCollection("transactions");
        if (txs.find(Filters.exists("view.receivedAt", false)).first() == null) {
            return;
        }
        long updated = 0;
        for (Document file : db.getCollection("files").find()
                .projection(Projections.include("initgPty.nm", "creDtTm", "source.receivedAt"))) {
            Document party = file.get("initgPty", Document.class);
            String name = party == null ? null : party.getString("nm");
            Date received = file.get("source", Document.class).getDate("receivedAt");
            var set = Updates.combine(
                    name == null ? Updates.unset("view.initgPtyNm") : Updates.set("view.initgPtyNm", name),
                    Updates.set("view.creDtTm", file.getDate("creDtTm")),
                    Updates.set("view.receivedAt", received));
            updated += txs.updateMany(Filters.and(Filters.eq("fileId", file.getObjectId("_id")),
                    Filters.exists("view.receivedAt", false)), set).getModifiedCount();
        }
        log.info("Backfilled initiating party and file times on {} transactions", updated);
    }
}
