package com.paymentsui.config;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Serves the built React app for its client-side routes (e.g. a reload on
 * /files/123), so deep links work when the UI is served by Spring Boot.
 */
@Controller
public class SpaForwardingController {

    @GetMapping({"/", "/files", "/files/{id}", "/batches/{id}", "/transactions", "/transactions/{id}", "/reports", "/reports/{id}"})
    public String index() {
        return "forward:/index.html";
    }
}
