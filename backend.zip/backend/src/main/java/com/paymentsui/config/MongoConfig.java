package com.paymentsui.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.client.MongoDatabase;

@Configuration
public class MongoConfig {

    /** The API and loader work with plain BSON documents; the ISO model is too wide for entity classes. */
    @Bean
    MongoDatabase paymentsDatabase(MongoTemplate template) {
        return template.getDb();
    }
}
