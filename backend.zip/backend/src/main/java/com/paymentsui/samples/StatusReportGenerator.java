package com.paymentsui.samples;

import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.exists;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.bson.Document;
import org.bson.types.Decimal128;
import org.bson.types.ObjectId;

import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Sorts;

/**
 * Writes pain.002.001.10 status reports for pain.001 files already loaded in
 * MongoDB, so the status screens have something to show. Files that already
 * have a status are skipped.
 *
 * <p>Each file gets a mix of outcomes: accepted as a whole, settled batch by
 * batch (occasionally with a rejected batch), partly accepted with some
 * transactions rejected, or rejected as a whole. Files that failed validation
 * are always rejected with a matching reason code. Many files first receive a
 * technical acceptance (ACTC) report and a final report later.
 *
 * <p>Usage: {@code StatusReportGenerator <outputDir> [count] [seed] [mongoUri]}
 */
public final class StatusReportGenerator {

    static final String NAMESPACE = "urn:iso:std:iso:20022:tech:xsd:pain.002.001.10";
    private static final String[] TX_REJECT_REASONS = {"AC01", "AC04", "AC06", "AM04", "AM05", "BE04", "MS03", "RC01"};
    private static final Map<String, String> VALIDATION_REASONS = Map.of(
            "NB_OF_TXS_MISMATCH", "AM18", "BAD_NB_OF_TXS", "AM18", "CTRL_SUM_MISMATCH", "AM10", "DUPLICATE_E2E", "DUPL");

    private final Random rnd;

    public StatusReportGenerator(long seed) {
        this.rnd = new Random(seed);
    }

    public static void main(String[] args) throws IOException {
        Path out = Path.of(args.length > 0 ? args[0] : "inbox");
        int count = args.length > 1 ? Integer.parseInt(args[1]) : 20;
        long seed = args.length > 2 ? Long.parseLong(args[2]) : System.currentTimeMillis();
        String uri = args.length > 3 ? args[3] : System.getenv().getOrDefault("MONGODB_URI", "mongodb://localhost:27017/payments");
        ConnectionString cs = new ConnectionString(uri);
        try (MongoClient client = MongoClients.create(cs)) {
            MongoDatabase db = client.getDatabase(cs.getDatabase() == null ? "payments" : cs.getDatabase());
            List<Path> written = new StatusReportGenerator(seed).writeAll(db, out, count);
            written.forEach(p -> System.out.println("wrote " + p));
            System.out.println(written.size() + " status report(s) written to " + out.toAbsolutePath());
        }
    }

    /** Writes reports for up to {@code count} loaded files that have no status yet. */
    public List<Path> writeAll(MongoDatabase db, Path out, int count) throws IOException {
        Files.createDirectories(out);
        List<Path> written = new ArrayList<>();
        for (Document file : db.getCollection("files").find(exists("status", false))
                .sort(Sorts.ascending("source.receivedAt", "_id")).limit(count)) {
            ObjectId fileId = file.getObjectId("_id");
            List<Document> batches = db.getCollection("batches").find(eq("fileId", fileId))
                    .projection(Projections.include("pmtInfId", "nbOfTxs", "ctrlSum")).sort(Sorts.ascending("seq")).into(new ArrayList<>());
            List<Document> txs = db.getCollection("transactions").find(eq("fileId", fileId))
                    .projection(Projections.include("batchId", "pmtId", "view")).sort(Sorts.ascending("batchId", "seq")).into(new ArrayList<>());
            List<String> reports = reportsFor(file, batches, txs);
            for (int i = 0; i < reports.size(); i++) {
                Path p = out.resolve("pain002_" + safe(file.getString("msgId")) + "_" + (i + 1) + ".xml");
                Files.writeString(p, reports.get(i), StandardCharsets.UTF_8);
                written.add(p);
            }
        }
        return written;
    }

    /** One or two pain.002 messages for a loaded file, oldest first. */
    public List<String> reportsFor(Document file, List<Document> batches, List<Document> txs) {
        OffsetDateTime created = time(file.getDate("creDtTm"));
        String bic = txs.isEmpty() ? null : txs.get(0).get("view", Document.class).getString("dbtrBic");
        List<String> reports = new ArrayList<>();
        Document validation = file.get("validation", Document.class);
        if (validation != null && "INVALID".equals(validation.getString("status"))) {
            String code = validation.getList("issues", Document.class).stream()
                    .filter(i -> "ERROR".equals(i.getString("severity")))
                    .map(i -> VALIDATION_REASONS.getOrDefault(i.getString("code"), "FF01")).findFirst().orElse("FF01");
            reports.add(report(file, bic, created.plusMinutes(3), 1, "RJCT", reason(code, "File failed validation"), List.of()));
            return reports;
        }
        boolean twoStep = rnd.nextBoolean();
        if (twoStep) {
            reports.add(report(file, bic, created.plusMinutes(2 + rnd.nextInt(10)), 1, "ACTC", "", List.of()));
        }
        OffsetDateTime finalAt = created.plusMinutes(60 + rnd.nextInt(60 * 6));
        int n = reports.size() + 1;
        int scenario = rnd.nextInt(100);
        String report;
        if (scenario < 40) {
            report = report(file, bic, finalAt, n, "ACCP", "", List.of());
        } else if (scenario < 65) {
            report = byBatch(file, bic, finalAt, n, batches);
        } else if (scenario < 92) {
            report = partial(file, bic, finalAt, n, batches, txs);
        } else {
            report = report(file, bic, finalAt, n, "RJCT", reason(rnd.nextBoolean() ? "AM04" : "AG01", null), List.of());
        }
        reports.add(report);
        return reports;
    }

    /** Settled batch by batch; now and then a batch is rejected for insufficient funds. */
    private String byBatch(Document file, String bic, OffsetDateTime at, int n, List<Document> batches) {
        List<String> blocks = new ArrayList<>();
        boolean anyRejected = false;
        for (Document b : batches) {
            boolean reject = batches.size() > 1 && rnd.nextInt(4) == 0;
            anyRejected |= reject;
            blocks.add(pmtInf(b, reject ? "RJCT" : "ACSC", reject ? reason("AM04", "Insufficient funds on debtor account") : "", ""));
        }
        return report(file, bic, at, n, anyRejected ? "PART" : "ACSC", "", blocks);
    }

    /** Most transactions settled, one to three rejected with transaction-level reasons. */
    private String partial(Document file, String bic, OffsetDateTime at, int n, List<Document> batches, List<Document> txs) {
        int rejects = Math.min(txs.size(), 1 + rnd.nextInt(3));
        List<Integer> rejected = new ArrayList<>();
        while (rejected.size() < rejects) {
            int i = rnd.nextInt(txs.size());
            if (!rejected.contains(i)) {
                rejected.add(i);
            }
        }
        List<String> blocks = new ArrayList<>();
        for (Document b : batches) {
            StringBuilder txBlocks = new StringBuilder();
            boolean batchHasReject = false;
            for (int i = 0; i < txs.size(); i++) {
                Document tx = txs.get(i);
                if (!b.getObjectId("_id").equals(tx.getObjectId("batchId"))) {
                    continue;
                }
                boolean reject = rejected.contains(i);
                batchHasReject |= reject;
                txBlocks.append(tx(tx, reject ? "RJCT" : "ACSC",
                        reject ? reason(TX_REJECT_REASONS[rnd.nextInt(TX_REJECT_REASONS.length)], null) : "", at));
            }
            blocks.add(pmtInf(b, batchHasReject ? "PART" : "ACSC", "", txBlocks.toString()));
        }
        return report(file, bic, at, n, "PART", "", blocks);
    }

    private String report(Document file, String bic, OffsetDateTime at, int n, String grpSts, String grpReason, List<String> pmtInfs) {
        String msgId = file.getString("msgId");
        return """
                <?xml version="1.0" encoding="UTF-8"?>
                <Document xmlns="%s">
                  <CstmrPmtStsRpt>
                    <GrpHdr>
                      <MsgId>%s</MsgId>
                      <CreDtTm>%s</CreDtTm>
                %s    </GrpHdr>
                    <OrgnlGrpInfAndSts>
                      <OrgnlMsgId>%s</OrgnlMsgId>
                      <OrgnlMsgNmId>pain.001.001.09</OrgnlMsgNmId>
                      <OrgnlCreDtTm>%s</OrgnlCreDtTm>
                      <OrgnlNbOfTxs>%s</OrgnlNbOfTxs>
                %s      <GrpSts>%s</GrpSts>
                %s    </OrgnlGrpInfAndSts>
                %s  </CstmrPmtStsRpt>
                </Document>
                """.formatted(NAMESPACE, esc(truncate("STS-" + msgId, 31) + "-" + n), at,
                bic == null ? "" : "      <DbtrAgt><FinInstnId><BICFI>" + bic + "</BICFI></FinInstnId></DbtrAgt>\n",
                esc(msgId), time(file.getDate("creDtTm")), file.get("nbOfTxs"),
                ctrlSum("      ", "OrgnlCtrlSum", file.get("ctrlSum")),
                grpSts, indent(grpReason, "      "), String.join("", pmtInfs));
    }

    private static String pmtInf(Document batch, String sts, String reason, String txs) {
        return """
                    <OrgnlPmtInfAndSts>
                      <OrgnlPmtInfId>%s</OrgnlPmtInfId>
                      <OrgnlNbOfTxs>%s</OrgnlNbOfTxs>
                %s      <PmtInfSts>%s</PmtInfSts>
                %s%s    </OrgnlPmtInfAndSts>
                """.formatted(esc(batch.getString("pmtInfId")), batch.get("nbOfTxs"),
                ctrlSum("      ", "OrgnlCtrlSum", batch.get("ctrlSum")), sts, indent(reason, "      "), txs);
    }

    private String tx(Document tx, String sts, String reason, OffsetDateTime at) {
        Document id = tx.get("pmtId", Document.class);
        Document v = tx.get("view", Document.class);
        StringBuilder refs = new StringBuilder();
        if (id.getString("instrId") != null) {
            refs.append("        <OrgnlInstrId>").append(esc(id.getString("instrId"))).append("</OrgnlInstrId>\n");
        }
        refs.append("        <OrgnlEndToEndId>").append(esc(id.getString("endToEndId"))).append("</OrgnlEndToEndId>\n");
        if (id.getString("uetr") != null) {
            refs.append("        <OrgnlUETR>").append(id.getString("uetr")).append("</OrgnlUETR>\n");
        }
        String accepted = "ACSC".equals(sts) ? "        <AccptncDtTm>" + at + "</AccptncDtTm>\n" : "";
        return """
                      <TxInfAndSts>
                        <StsId>%s</StsId>
                %s        <TxSts>%s</TxSts>
                %s%s        <OrgnlTxRef>
                          <Amt><InstdAmt Ccy="%s">%s</InstdAmt></Amt>
                          <Cdtr><Pty><Nm>%s</Nm></Pty></Cdtr>
                        </OrgnlTxRef>
                      </TxInfAndSts>
                """.formatted(Long.toHexString(rnd.nextLong() & Long.MAX_VALUE).toUpperCase(), refs, sts,
                indent(reason, "        "), accepted, v.getString("ccy"), amount(v.get("amount")), esc(v.getString("cdtrNm")));
    }

    private static String reason(String code, String text) {
        return "<StsRsnInf>\n  <Rsn><Cd>" + code + "</Cd></Rsn>\n"
                + (text == null ? "" : "  <AddtlInf>" + esc(text) + "</AddtlInf>\n") + "</StsRsnInf>\n";
    }

    private static String indent(String block, String prefix) {
        if (block.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        block.lines().forEach(l -> sb.append(prefix).append(l).append('\n'));
        return sb.toString();
    }

    private static String ctrlSum(String prefix, String tag, Object value) {
        return value == null ? "" : prefix + "<" + tag + ">" + amount(value) + "</" + tag + ">\n";
    }

    private static String amount(Object value) {
        BigDecimal v = value instanceof Decimal128 d ? d.bigDecimalValue() : new BigDecimal(String.valueOf(value));
        return v.toPlainString();
    }

    private static OffsetDateTime time(Date date) {
        Instant i = date == null ? Instant.now() : date.toInstant();
        return OffsetDateTime.ofInstant(i, ZoneOffset.UTC);
    }

    private static String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max);
    }

    private static String safe(String s) {
        return s.replaceAll("[^A-Za-z0-9._-]", "_");
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }
}
