package com.paymentsui.samples;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Writes realistic pain.001.001.09 files for demos and tests: several debtors,
 * multiple batches per file, mixed currencies, valid IBAN check digits, UETRs
 * and remittance text. Roughly one file in eight carries a deliberate problem
 * (wrong control sum, wrong count or a duplicate EndToEndId) so the UI's
 * validation badges have something to show.
 *
 * <p>Usage: {@code SampleGenerator <outputDir> [count] [seed]}
 */
public final class SampleGenerator {

    record Party(String name, String country, String bic, String iban, String lei) {
    }

    private static final List<Party> DEBTORS = List.of(
            new Party("Northwind Traders Ltd", "GB", "NWBKGB2L", "GB", "5493001KJTIIGC8Y1R12"),
            new Party("Contoso Manufacturing GmbH", "DE", "DEUTDEFF", "DE", "529900T8BM49AURSDO55"),
            new Party("Fabrikam Retail SA", "FR", "BNPAFRPP", "FR", null),
            new Party("Tailspin Logistics BV", "NL", "INGBNL2A", "NL", "724500VKKSH9QOLTFR81"));

    private static final String[] CREDITORS = {
        "Adatum Office Supplies", "Litware Software", "Proseware Consulting", "Wide World Importers",
        "Alpine Ski House", "Coho Winery", "Fourth Coffee", "Lucerne Publishing", "Margie's Travel",
        "Trey Research", "Wingtip Toys", "Blue Yonder Airlines", "City Power & Light", "Humongous Insurance",
        "Graphic Design Institute", "School of Fine Art", "Relecloud", "VanArsdel Ltd", "Woodgrove Bank Services"
    };

    private static final String[][] CREDITOR_BANKS = {
        {"GB", "BARCGB22"}, {"DE", "COBADEFF"}, {"FR", "SOGEFRPP"}, {"NL", "ABNANL2A"},
        {"ES", "CAIXESBB"}, {"IT", "UNCRITMM"}, {"BE", "GEBABEBB"}, {"IE", "AIBKIE2D"}
    };

    private static final String[] PURPOSES = {"SUPP", "SALA", "TAXS", "RENT", "TRAD", "SERV"};

    private final Random rnd;

    public SampleGenerator(long seed) {
        this.rnd = new Random(seed);
    }

    public static void main(String[] args) throws IOException {
        Path out = Path.of(args.length > 0 ? args[0] : "inbox");
        int count = args.length > 1 ? Integer.parseInt(args[1]) : 20;
        long seed = args.length > 2 ? Long.parseLong(args[2]) : System.currentTimeMillis();
        Files.createDirectories(out);
        SampleGenerator gen = new SampleGenerator(seed);
        for (int i = 0; i < count; i++) {
            String msgId = "MSG" + LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE) + "-" + String.format("%05d", gen.rnd.nextInt(100_000)) + i;
            Path file = out.resolve("pain001_" + msgId + ".xml");
            Files.writeString(file, gen.file(msgId, i % 8 == 7), StandardCharsets.UTF_8);
            System.out.println("wrote " + file);
        }
    }

    /** One complete pain.001.001.09 message. */
    public String file(String msgId, boolean withProblem) {
        Party debtor = DEBTORS.get(rnd.nextInt(DEBTORS.size()));
        OffsetDateTime created = OffsetDateTime.now(ZoneOffset.UTC).minusMinutes(rnd.nextInt(60 * 24 * 5)).withNano(0);
        int batchCount = 1 + rnd.nextInt(4);
        int problem = withProblem ? rnd.nextInt(3) : -1;

        StringBuilder batches = new StringBuilder();
        int totalTx = 0;
        BigDecimal totalSum = BigDecimal.ZERO;
        for (int b = 0; b < batchCount; b++) {
            String ccy = b == 0 || rnd.nextInt(3) > 0 ? "EUR" : (rnd.nextBoolean() ? "GBP" : "USD");
            int txCount = 1 + rnd.nextInt(b == 0 ? 40 : 15);
            Batch batch = batch(msgId, b, debtor, ccy, created, txCount, b == 0 && problem == 2);
            batches.append(batch.xml());
            totalTx += txCount;
            totalSum = totalSum.add(batch.sum());
        }

        String declaredCount = String.valueOf(problem == 1 ? totalTx + 1 : totalTx);
        BigDecimal declaredSum = problem == 0 ? totalSum.add(new BigDecimal("100.00")) : totalSum;
        return """
                <?xml version="1.0" encoding="UTF-8"?>
                <Document xmlns="urn:iso:std:iso:20022:tech:xsd:pain.001.001.09">
                  <CstmrCdtTrfInitn>
                    <GrpHdr>
                      <MsgId>%s</MsgId>
                      <CreDtTm>%s</CreDtTm>
                      <NbOfTxs>%s</NbOfTxs>
                      <CtrlSum>%s</CtrlSum>
                      <InitgPty>
                        <Nm>%s</Nm>
                %s      </InitgPty>
                    </GrpHdr>
                %s  </CstmrCdtTrfInitn>
                </Document>
                """.formatted(msgId, created.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME), declaredCount,
                declaredSum.toPlainString(), esc(debtor.name()), orgId(debtor, "        "), batches);
    }

    record Batch(String xml, BigDecimal sum) {
    }

    private Batch batch(String msgId, int seq, Party debtor, String ccy, OffsetDateTime created, int txCount, boolean duplicateE2e) {
        String pmtInfId = msgId + "-B" + (seq + 1);
        LocalDate execDate = created.toLocalDate().plusDays(rnd.nextInt(4));
        boolean urgent = rnd.nextInt(6) == 0;
        String debtorIban = iban(debtor.iban());

        StringBuilder txs = new StringBuilder();
        BigDecimal sum = BigDecimal.ZERO;
        for (int t = 0; t < txCount; t++) {
            BigDecimal amount = amount();
            sum = sum.add(amount);
            String e2e = duplicateE2e && t == 1 ? pmtInfId + "-T1" : pmtInfId + "-T" + (t + 1);
            txs.append(transaction(pmtInfId, t, e2e, ccy, amount));
        }

        String xml = """
                    <PmtInf>
                      <PmtInfId>%s</PmtInfId>
                      <PmtMtd>TRF</PmtMtd>
                      <BtchBookg>%s</BtchBookg>
                      <NbOfTxs>%d</NbOfTxs>
                      <CtrlSum>%s</CtrlSum>
                      <PmtTpInf>
                        <InstrPrty>%s</InstrPrty>
                        <SvcLvl><Cd>%s</Cd></SvcLvl>
                        <CtgyPurp><Cd>%s</Cd></CtgyPurp>
                      </PmtTpInf>
                      <ReqdExctnDt><Dt>%s</Dt></ReqdExctnDt>
                      <Dbtr>
                        <Nm>%s</Nm>
                        <PstlAdr><Ctry>%s</Ctry></PstlAdr>
                %s      </Dbtr>
                      <DbtrAcct><Id><IBAN>%s</IBAN></Id><Ccy>%s</Ccy></DbtrAcct>
                      <DbtrAgt><FinInstnId><BICFI>%s</BICFI></FinInstnId></DbtrAgt>
                      <ChrgBr>%s</ChrgBr>
                %s    </PmtInf>
                """.formatted(pmtInfId, rnd.nextBoolean(), txCount, sum.toPlainString(),
                urgent ? "HIGH" : "NORM", "EUR".equals(ccy) ? "SEPA" : urgent ? "URGP" : "NURG",
                seq == 0 && rnd.nextInt(4) == 0 ? "SALA" : "SUPP", execDate, esc(debtor.name()), debtor.country(),
                orgId(debtor, "          "), debtorIban, ccy, debtor.bic(), "EUR".equals(ccy) ? "SLEV" : "SHAR", txs);
        return new Batch(xml, sum);
    }

    private String transaction(String pmtInfId, int seq, String e2e, String ccy, BigDecimal amount) {
        String creditor = CREDITORS[rnd.nextInt(CREDITORS.length)];
        String[] bank = CREDITOR_BANKS[rnd.nextInt(CREDITOR_BANKS.length)];
        String invoice = "INV-" + (10_000 + rnd.nextInt(90_000));
        String ultimate = rnd.nextInt(10) == 0
                ? "          <UltmtCdtr><Nm>" + esc(creditor) + " Holdings</Nm></UltmtCdtr>\n" : "";
        return """
                      <CdtTrfTxInf>
                        <PmtId>
                          <InstrId>%s-I%d</InstrId>
                          <EndToEndId>%s</EndToEndId>
                          <UETR>%s</UETR>
                        </PmtId>
                        <Amt><InstdAmt Ccy="%s">%s</InstdAmt></Amt>
                        <CdtrAgt><FinInstnId><BICFI>%s</BICFI></FinInstnId></CdtrAgt>
                        <Cdtr>
                          <Nm>%s</Nm>
                          <PstlAdr><TwnNm>%s</TwnNm><Ctry>%s</Ctry></PstlAdr>
                        </Cdtr>
                        <CdtrAcct><Id><IBAN>%s</IBAN></Id></CdtrAcct>
                %s          <Purp><Cd>%s</Cd></Purp>
                        <RmtInf><Ustrd>%s</Ustrd></RmtInf>
                      </CdtTrfTxInf>
                """.formatted(pmtInfId, seq + 1, e2e, uuid(), ccy, amount.toPlainString(), bank[1], esc(creditor),
                town(bank[0]), bank[0], iban(bank[0]), ultimate, PURPOSES[rnd.nextInt(PURPOSES.length)],
                "Invoice " + invoice + " / " + esc(creditor));
    }

    private static String orgId(Party p, String indent) {
        if (p.lei() == null) {
            return "";
        }
        return indent + "<Id><OrgId><LEI>" + p.lei() + "</LEI></OrgId></Id>\n";
    }

    private BigDecimal amount() {
        double r = rnd.nextDouble();
        double value = r < 0.7 ? 50 + rnd.nextDouble() * 4_950 : r < 0.95 ? 5_000 + rnd.nextDouble() * 45_000 : 50_000 + rnd.nextDouble() * 950_000;
        return BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP);
    }

    private String uuid() {
        // UETR must be a version 4 UUID in lower case.
        return new UUID(rnd.nextLong() & 0xffffffffffff0fffL | 0x0000000000004000L,
                rnd.nextLong() & 0x3fffffffffffffffL | 0x8000000000000000L).toString();
    }

    /** Builds an IBAN with correct ISO 7064 mod-97 check digits and the country's length. */
    public String iban(String country) {
        int bbanLength = switch (country) {
            case "GB", "IE" -> 18;
            case "DE" -> 18;
            case "FR", "IT" -> 23;
            case "NL" -> 14;
            case "ES" -> 20;
            case "BE" -> 12;
            default -> 16;
        };
        StringBuilder bban = new StringBuilder();
        if (country.equals("GB") || country.equals("IE") || country.equals("NL")) {
            for (int i = 0; i < 4; i++) {
                bban.append((char) ('A' + rnd.nextInt(26)));
            }
        }
        while (bban.length() < bbanLength) {
            bban.append(rnd.nextInt(10));
        }
        String check = String.format("%02d", 98 - mod97(bban + country + "00"));
        return country + check + bban;
    }

    static int mod97(String s) {
        StringBuilder digits = new StringBuilder();
        for (char c : s.toCharArray()) {
            digits.append(Character.isLetter(c) ? String.valueOf(c - 'A' + 10) : String.valueOf(c));
        }
        return new BigInteger(digits.toString()).mod(BigInteger.valueOf(97)).intValue();
    }

    private static String town(String country) {
        return switch (country) {
            case "GB" -> "London";
            case "DE" -> "Frankfurt";
            case "FR" -> "Paris";
            case "NL" -> "Amsterdam";
            case "ES" -> "Barcelona";
            case "IT" -> "Milan";
            case "BE" -> "Brussels";
            case "IE" -> "Dublin";
            default -> "Zurich";
        };
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&apos;");
    }
}
