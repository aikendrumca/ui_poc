plugins {
    java
    jacoco
    id("org.springframework.boot") version "4.0.8"
    id("io.spring.dependency-management") version "1.1.7"
}

group = "com.paymentsui"
version = "0.1.0"

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(25)
    }
}

repositories {
    mavenCentral()
}

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-webmvc")
    implementation("org.springframework.boot:spring-boot-starter-data-mongodb")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    // JAXB model of every ISO 20022 message, generated from the official XSDs (Apache 2.0).
    implementation("com.prowidesoftware:pw-iso20022:SRU2025-10.4.0")
    compileOnly("jakarta.xml.bind:jakarta.xml.bind-api")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
    // In-memory MongoDB speaking the wire protocol: unit tests need no Docker and no database.
    testImplementation("de.bwaldvogel:mongo-java-server:1.47.0")
    testImplementation("org.springframework.boot:spring-boot-testcontainers")
    testImplementation("org.testcontainers:testcontainers-junit-jupiter")
    testImplementation("org.testcontainers:testcontainers-mongodb")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

// Bundle the built React app (frontend/dist, from `npm run build`) so one jar serves UI and API.
tasks.processResources {
    from("../frontend/dist") { into("static") }
}

tasks.test {
    useJUnitPlatform {
        // ./gradlew test -PunitOnly skips the Docker-based integration tests.
        if (project.hasProperty("unitOnly")) excludeTags("integration")
    }
    finalizedBy(tasks.jacocoTestReport)
}

jacoco {
    toolVersion = "0.8.15"
}

// Only the application entry point is left out: it just starts Spring.
val coverageExclusions = listOf("com/paymentsui/PaymentsUiApplication.class")

tasks.jacocoTestReport {
    dependsOn(tasks.test)
    reports {
        xml.required = true
        html.required = true
        csv.required = false
    }
    classDirectories.setFrom(files(classDirectories.files.map { fileTree(it) { exclude(coverageExclusions) } }))
}

tasks.jacocoTestCoverageVerification {
    dependsOn(tasks.test)
    classDirectories.setFrom(files(classDirectories.files.map { fileTree(it) { exclude(coverageExclusions) } }))
    violationRules {
        rule {
            limit {
                counter = "INSTRUCTION"
                minimum = "0.95".toBigDecimal()
            }
            limit {
                counter = "LINE"
                minimum = "0.95".toBigDecimal()
            }
        }
    }
}

tasks.check {
    dependsOn(tasks.jacocoTestCoverageVerification)
}

// Generate sample pain.001.001.09 files: ./gradlew generateSamples -Pcount=20 -Pout=../inbox
tasks.register<JavaExec>("generateSamples") {
    group = "application"
    description = "Writes sample pain.001.001.09 XML files"
    classpath = sourceSets["main"].runtimeClasspath
    mainClass = "com.paymentsui.samples.SampleGenerator"
    args(
        (findProperty("out") ?: "../inbox").toString(),
        (findProperty("count") ?: "20").toString()
    )
}

// Generate pain.002.001.10 status reports for files already loaded in MongoDB:
// ./gradlew generateStatusReports -Pcount=20 -Pout=../inbox   (reads MONGODB_URI, default mongodb://localhost:27017/payments)
tasks.register<JavaExec>("generateStatusReports") {
    group = "application"
    description = "Writes sample pain.002.001.10 status reports for loaded pain.001 files"
    classpath = sourceSets["main"].runtimeClasspath
    mainClass = "com.paymentsui.samples.StatusReportGenerator"
    args(
        (findProperty("out") ?: "../inbox").toString(),
        (findProperty("count") ?: "20").toString()
    )
}
