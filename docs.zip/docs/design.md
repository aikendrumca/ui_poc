# Payments Operational UI: stack options and MongoDB schema

Status: 2026-09-27. Stack chosen: option A with Java 25, Spring Boot 4.0.8, Gradle 9.8.

Scope agreed so far: a **view-only** UI over MongoDB that shows ISO 20022
**pain.001.001.09** (Customer Credit Transfer Initiation) payment files, their
batches and their transactions, and the links between them.

---

## 1. Tech stack options

| | A. Spring Boot + React (recommended) | B. Full TypeScript (Next.js) | C. Java-only UI (Vaadin) |
|---|---|---|---|
| Backend | Java 25, Spring Boot 4, Spring Data MongoDB, read-only REST API | Next.js route handlers / server components, official MongoDB Node driver | Vaadin Flow on Spring Boot, Spring Data MongoDB |
| Frontend | React + TypeScript (Vite), TanStack Table or AG Grid Community, React Flow for the file → batch → transaction graph | React (same libraries as A), one codebase | Server-side Java components (Grid, TreeGrid); graph needs a JS add-on |
| XML loader | JAXB model of pain.001.001.09 (Prowide ISO 20022, generated from the official XSDs), so parsing is type-safe | fast-xml-parser / xsd bindings are weaker; more hand mapping | Same as A (JAXB) |
| Team fit | Backend in Java (known); frontend in TS (new but mainstream) | Everything in TS: most to learn | Everything in Java: least to learn |
| "Modern & robust" | Strong: clear API boundary, testable, UI can evolve freely | Strong, fastest to prototype, fewer moving parts | Good for internal tools; less flexible look and feel, graph visuals are harder, some components are commercial |
| Risk | Two languages, two builds | Payments parsing in JS is less mature than JAXB | Custom visualisations (link graph) fight the framework |

**Recommendation: A.** The team's Java skills go where they matter most
(XSD-driven parsing, data access, validation) and the UI gets the best
visualisation libraries. A read-only API also makes it easy to add auth
(e.g. Spring Security + OIDC) and audit logging later.

---

## 2. Data model

Four collections in database `payments`. pain.001 is hierarchical:

```
Document/CstmrCdtTrfInitn
 ├─ GrpHdr                     → files         (1 per XML message)
 └─ PmtInf  [1..n]             → batches       (1 per PmtInf block)
     └─ CdtTrfTxInf [1..n]     → transactions  (1 per transaction)
```

pain.002 status reports go in a fourth collection, `statusReports` (section 2.6).

### Linking keys

* `files._id` (ObjectId) is the root.
* `batches.fileId` → `files._id`
* `transactions.batchId` → `batches._id`
* `transactions.fileId` → `files._id` (denormalised so "all transactions in a
  file" is one indexed query, no join)
* Business keys kept alongside for display and search: `files.msgId`,
  `batches.pmtInfId`, `transactions.endToEndId`, `transactions.instrId`,
  `transactions.uetr`.
* A small copy of parent context is stored on children (`batches.msgId`,
  `transactions.msgId`, `transactions.pmtInfId`, debtor name/account on the
  transaction) so list screens never need `$lookup`. This is safe because the
  data is immutable once loaded.

Field names are camelCase versions of the ISO tags, with the ISO path noted.
Amounts are stored as `Decimal128` (never double). Dates are BSON `Date`.

### 2.1 `files` (GrpHdr + file metadata)

| Field | ISO path | Notes |
|---|---|---|
| `_id` | | ObjectId |
| `msgId` | GrpHdr/MsgId | Max35Text, required |
| `creDtTm` | GrpHdr/CreDtTm | required |
| `authstn[]` | GrpHdr/Authstn | `{cd}` or `{prtry}` |
| `nbOfTxs` | GrpHdr/NbOfTxs | declared count (stored as int) |
| `ctrlSum` | GrpHdr/CtrlSum | Decimal128, optional |
| `initgPty` | GrpHdr/InitgPty | PartyIdentification135: `{nm, pstlAdr, id:{orgId{anyBIC, lei, othr[]} \| prvtId}, ctryOfRes, ctctDtls}` |
| `fwdgAgt` | GrpHdr/FwdgAgt | BranchAndFinancialInstitutionIdentification6 |
| `source` | (ops) | `{fileName, receivedAt, sha256, sizeBytes, channel}` |
| `stats` | (ops) | computed on load: `{batchCount, txCount, totalsByCcy:[{ccy, amount}]}` |
| `validation` | (ops) | `{status: VALID\|WARN\|INVALID, issues:[{code, path, msg}]}` e.g. NbOfTxs/CtrlSum mismatch |
| `rawXmlRef` | (ops) | id of the original XML in the GridFS bucket `rawXml` |

### 2.2 `batches` (PmtInf)

| Field | ISO path | Notes |
|---|---|---|
| `_id` | | ObjectId |
| `fileId`, `msgId` | | link to parent |
| `seq` | | position in file (0-based) |
| `pmtInfId` | PmtInf/PmtInfId | required |
| `pmtMtd` | PmtInf/PmtMtd | TRF \| CHK \| TRA |
| `btchBookg` | PmtInf/BtchBookg | bool |
| `nbOfTxs`, `ctrlSum` | PmtInf/NbOfTxs, CtrlSum | declared |
| `pmtTpInf` | PmtInf/PmtTpInf | `{instrPrty, svcLvl[{cd\|prtry}], lclInstrm, ctgyPurp}` |
| `reqdExctnDt` | PmtInf/ReqdExctnDt | v9 is a choice of Dt or DtTm; stored as `{date: Date, hasTime: bool}` |
| `poolgAdjstmntDt` | PmtInf/PoolgAdjstmntDt | |
| `dbtr` | PmtInf/Dbtr | PartyIdentification135 |
| `dbtrAcct` | PmtInf/DbtrAcct | CashAccount38: `{id:{iban \| othr{id}}, tp, ccy, nm, prxy}` |
| `dbtrAgt` | PmtInf/DbtrAgt | `{finInstnId:{bicfi, clrSysMmbId, lei, nm, pstlAdr}, brnchId}` |
| `dbtrAgtAcct` | PmtInf/DbtrAgtAcct | |
| `instrForDbtrAgt` | PmtInf/InstrForDbtrAgt | |
| `ultmtDbtr` | PmtInf/UltmtDbtr | |
| `chrgBr` | PmtInf/ChrgBr | DEBT \| CRED \| SHAR \| SLEV |
| `chrgsAcct`, `chrgsAcctAgt` | PmtInf/ChrgsAcct, ChrgsAcctAgt | |
| `stats`, `validation` | (ops) | as on files |

### 2.3 `transactions` (CdtTrfTxInf)

| Field | ISO path | Notes |
|---|---|---|
| `_id` | | ObjectId |
| `fileId`, `batchId`, `msgId`, `pmtInfId`, `seq` | | links + position in batch |
| `pmtId` | CdtTrfTxInf/PmtId | `{instrId, endToEndId, uetr}` (UETR is new in v9) |
| `pmtTpInf` | CdtTrfTxInf/PmtTpInf | overrides batch level if present |
| `amt` | CdtTrfTxInf/Amt | `{instdAmt:{value: Decimal128, ccy}}` or `{eqvtAmt:{amt, ccyOfTrf}}` |
| `xchgRateInf` | CdtTrfTxInf/XchgRateInf | |
| `chrgBr` | CdtTrfTxInf/ChrgBr | |
| `chqInstr` | CdtTrfTxInf/ChqInstr | only for PmtMtd CHK |
| `ultmtDbtr` | CdtTrfTxInf/UltmtDbtr | |
| `intrmyAgt1..3` (+ `Acct`) | CdtTrfTxInf/IntrmyAgtN | |
| `cdtrAgt`, `cdtrAgtAcct` | CdtTrfTxInf/CdtrAgt | |
| `cdtr` | CdtTrfTxInf/Cdtr | |
| `cdtrAcct` | CdtTrfTxInf/CdtrAcct | |
| `ultmtCdtr` | CdtTrfTxInf/UltmtCdtr | |
| `instrForCdtrAgt[]`, `instrForDbtrAgt` | | |
| `purp` | CdtTrfTxInf/Purp | `{cd \| prtry}` |
| `rgltryRptg[]`, `tax` | | kept as nested documents |
| `rltdRmtInf[]` | CdtTrfTxInf/RltdRmtInf | |
| `rmtInf` | CdtTrfTxInf/RmtInf | `{ustrd[], strd[]}` |
| `splmtryData[]` | | |
| `view` | (ops, denormalised) | `{amount: Decimal128, ccy, reqdExctnDt, pmtMtd, dbtrNm, dbtrAcct, dbtrBic, cdtrNm, cdtrAcct, cdtrBic, rmtInf, initgPtyNm, creDtTm, receivedAt}` for fast list/search screens |

### 2.4 Indexes

```js
// files
{ msgId: 1, "initgPty.nm": 1 }   unique   // MsgId is unique per initiating party
{ creDtTm: -1 }
{ "source.receivedAt": -1 }
{ "source.sha256": 1 }           unique   // duplicate-file detection
{ "validation.status": 1, creDtTm: -1 }
{ "initgPty.nm": 1, "source.receivedAt": -1 }
{ "stats.totalsByCcy.ccy": 1, "stats.totalsByCcy.amount": 1 }

// batches
{ fileId: 1, seq: 1 }            unique
{ pmtInfId: 1 }
{ "reqdExctnDt.date": -1 }
{ "dbtrAcct.id.iban": 1 }

// transactions
{ batchId: 1, seq: 1 }           unique
{ fileId: 1, seq: 1 }
{ "pmtId.endToEndId": 1 }
{ "pmtId.uetr": 1 }              sparse
{ "pmtId.instrId": 1 }           sparse
{ "view.cdtrAcct": 1 }
{ "view.dbtrAcct": 1 }
{ "view.reqdExctnDt": -1, "view.ccy": 1, "view.amount": -1 }
{ "view.initgPtyNm": 1, "view.reqdExctnDt": -1 }
{ "view.creDtTm": -1 }
{ "view.receivedAt": -1 }
{ "view.amount": -1 }
{ "view.cdtrNm": "text", "view.dbtrNm": "text", "view.rmtInf": "text" }
```

### 2.5 Validation

Each collection gets a `$jsonSchema` validator (moderate level) enforcing
required fields, enums (PmtMtd, ChrgBr), `Decimal128` amounts, ISO currency
pattern, and max lengths. See `create-db.js`.

### 2.6 `statusReports` (pain.002.001.10)

One document per `CstmrPmtStsRpt` message, keeping the ISO structure:

```
statusReports
 ├─ msgId, creDtTm, initgPty, dbtrAgt …      (GrpHdr)
 ├─ orgnlGrpInfAndSts { orgnlMsgId, orgnlMsgNmId, orgnlCreDtTm, orgnlNbOfTxs, grpSts, stsRsnInf[] }
 ├─ orgnlPmtInfAndSts[] { orgnlPmtInfId, pmtInfSts, stsRsnInf[], batchId,
 │                        txInfAndSts[] { orgnlEndToEndId, orgnlUETR, txSts, stsRsnInf[], orgnlTxRef, txId } }
 ├─ fileId                                    → files._id (null until the original is loaded)
 ├─ link { status: LINKED | PARTIAL | UNMATCHED, issues[] }
 ├─ source { fileName, receivedAt, sha256, sizeBytes, channel }, rawXmlRef
 └─ stats { pmtInfCount, txCount, txByStatus[] }
```

Matching: OrgnlMsgId finds the file (OrgnlCreDtTm breaks a tie between
parties that reuse a MsgId); OrgnlPmtInfId finds the batch; OrgnlUETR, else
OrgnlEndToEndId (with OrgnlInstrId when given), else OrgnlInstrId finds the
transaction. What does not match is recorded in `link.issues`
(UNKNOWN_ORIGINAL, UNKNOWN_BATCH, UNKNOWN_TX, NO_TX_REFERENCE, AMBIGUOUS_TX,
COUNT_DIFFERS).

Current status: files, batches and transactions carry
`status { code, level: GROUP|PMTINF|TX, at, reportId, reportMsgId, rsn, addtlInf }`.
A GrpSts other than PART applies to the whole file, a PmtInfSts other than PART
to the whole batch, and a TxSts to one transaction. A status is only replaced
by one from a report with the same or a later CreDtTm. The history for any
item is rebuilt from the reports on request, so nothing is stored twice.

Indexes: `{fileId, creDtTm}`, `orgnlGrpInfAndSts.orgnlMsgId`,
`orgnlPmtInfAndSts.batchId`, `orgnlPmtInfAndSts.txInfAndSts.txId`, `creDtTm`,
`source.receivedAt`, `link.status`, unique `{msgId, orgnlGrpInfAndSts.orgnlMsgId}`
and unique `source.sha256`; plus `status.code` on files and transactions.

### 2.7 `auditLog`

One document per user action: `{at, source: "api"|"ui", action, userId (null
until sign-in), target {type, id, label}, details, page, clientAt, client {ip,
remoteAddr, forwardedFor[], realIp, clientId, sessionId, requestId, userAgent,
referer, origin, acceptLanguage}, request {method, path, route, status,
durationMs}}`. API calls are logged by a servlet filter; UI events are batched
by the browser and posted to `/api/audit/events` (at most 50 per call, details
sanitised to 3 levels, 30 keys, 500-character strings, no `$` or dotted keys).
Indexes: `at`, and `{x, at}` for `action`, `client.ip`, `client.clientId`,
`client.sessionId`, `userId` and `{target.type, target.id}`; plus
`client.requestId`.

---

## 3. What the UI would show

* **Files list**: received time, MsgId, initiating party, batch/tx counts,
  totals per currency, validation badge.
* **File detail**: header fields plus an interactive tree/graph
  (file → batches → transactions) with counts and totals on each node;
  click a node to open its detail panel.
* **Batch detail**: debtor, account, agent, execution date, service level,
  transaction grid.
* **Transaction detail**: full party chain (ultimate debtor → debtor → debtor
  agent → intermediaries → creditor agent → creditor → ultimate creditor)
  drawn left to right, remittance info, breadcrumb back to batch and file.
* **Global search**: EndToEndId, UETR, InstrId, IBAN, name.
* **Filters**: time range (received, created, execution date), amount range, initiating party.
* Declared vs actual count/control-sum checks highlighted.
* **Payment status** from pain.002: status badges and filters on every level,
  per-file breakdown, history per batch and transaction, a status reports list
  and detail page, and report nodes in the link graph.

## 4. Getting data in

1. `create-db.js` (mongosh) creates the database, collections, validators and
   indexes. Stack-independent, can be run now.
2. The backend's inbox watcher parses pain.001.001.09 XML files into the three
   collections (see README).
3. A sample-data generator producing realistic pain.001 files so the UI has
   something to show from day one, and a second one that writes pain.002
   status reports for loaded files (`gradlew generateStatusReports`).

## 5. Open questions

* Where the code should live (new GitHub repo?).
* Expected volume (files per day, transactions per file) to size indexes and
  pagination.
* Which pain.002 versions the banks actually send. Only pain.002.001.10 is
  loaded today; another version needs its own mapper.
