import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // xfwd adds X-Forwarded-For, so the audit log records the browser's address.
    proxy: { "/api": { target: "http://localhost:8080", xfwd: true } },
  },
});
