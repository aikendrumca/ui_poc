// Amounts arrive as decimal strings. Format without going through a float for
// the digits: split on the decimal point and group the integer part.
export function money(amount: string | undefined | null, ccy?: string): string {
  if (amount == null) return "—";
  const negative = amount.startsWith("-");
  const [intPart, frac = ""] = amount.replace("-", "").split(".");
  const grouped = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const decimals = (frac + "00").slice(0, Math.max(2, frac.length));
  return `${negative ? "-" : ""}${grouped}.${decimals}${ccy ? ` ${ccy}` : ""}`;
}

export function compactMoney(amount: string, ccy: string): string {
  const n = Number(amount);
  const fmt = new Intl.NumberFormat(undefined, { notation: "compact", maximumFractionDigits: 1 });
  return `${fmt.format(n)} ${ccy}`;
}

export function num(n: number | undefined | null): string {
  return n == null ? "—" : new Intl.NumberFormat().format(n);
}

export function dateTime(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** Execution dates are calendar dates stored at UTC midnight: show them in UTC so they don't shift a day. */
export function date(iso?: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "2-digit", timeZone: "UTC" });
}

export function relative(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.round(mins / 60);
  if (hours < 48) return `${hours} h ago`;
  return `${Math.round(hours / 24)} days ago`;
}

export function bytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

/** Groups an IBAN in blocks of four for reading. */
export function iban(value?: string): string {
  if (!value) return "—";
  return /^[A-Z]{2}\d{2}/.test(value) ? value.replace(/(.{4})/g, "$1 ").trim() : value;
}
