// Types mirror the JSON the Spring Boot API returns: ids are hex strings,
// amounts are decimal strings (never floats), dates are ISO-8601 strings.
import { clientHeaders } from "./audit";

export type Status = "VALID" | "WARN" | "INVALID";

export interface Issue {
  severity: "ERROR" | "WARN";
  code: string;
  path: string;
  msg: string;
}

export interface Validation {
  status: Status;
  issues?: Issue[];
}

/** Latest pain.002 status copied onto a file, batch or transaction. */
export interface PaymentStatus {
  code: string;
  level: "GROUP" | "PMTINF" | "TX";
  at: string;
  reportId: string;
  reportMsgId?: string;
  rsn?: string;
  addtlInf?: string;
}

export interface StatusCount {
  code: string;
  count: number;
}

export interface CcyTotal {
  ccy: string;
  amount: string;
  count: number;
}

export interface Party {
  nm?: string;
  pstlAdr?: Record<string, unknown>;
  id?: Record<string, unknown>;
  ctryOfRes?: string;
  [k: string]: unknown;
}

export interface Account {
  id?: { iban?: string; othr?: { id?: string } };
  ccy?: string;
  nm?: string;
  [k: string]: unknown;
}

export interface Agent {
  finInstnId?: { bicfi?: string; lei?: string; nm?: string; clrSysMmbId?: { mmbId?: string } };
  [k: string]: unknown;
}

export interface FileSummary {
  _id: string;
  msgId: string;
  creDtTm: string;
  nbOfTxs: number;
  ctrlSum?: string;
  initgPty?: Party;
  source: { fileName: string; receivedAt: string; sha256: string; sizeBytes: number; channel?: string };
  stats: { batchCount: number; txCount: number; totalsByCcy: CcyTotal[] };
  validation: Validation;
  status?: PaymentStatus;
}

export interface FileDoc extends FileSummary {
  fwdgAgt?: Agent;
  authstn?: unknown[];
  rawXmlRef?: string;
  [k: string]: unknown;
}

export interface BatchDoc {
  _id: string;
  fileId: string;
  msgId: string;
  seq: number;
  pmtInfId: string;
  pmtMtd: string;
  btchBookg?: boolean;
  nbOfTxs: number;
  ctrlSum?: string;
  pmtTpInf?: Record<string, unknown>;
  reqdExctnDt: { date: string; hasTime: boolean };
  dbtr: Party;
  dbtrAcct: Account;
  dbtrAgt: Agent;
  ultmtDbtr?: Party;
  chrgBr?: string;
  stats: { txCount: number; totalsByCcy: CcyTotal[] };
  validation: Validation;
  status?: PaymentStatus;
  statusHistory?: PaymentStatus[];
  [k: string]: unknown;
}

export interface TxView {
  amount: string;
  ccy: string;
  reqdExctnDt: string;
  pmtMtd?: string;
  dbtrNm?: string;
  dbtrAcct?: string;
  dbtrBic?: string;
  cdtrNm?: string;
  cdtrAcct?: string;
  cdtrBic?: string;
  rmtInf?: string;
  initgPtyNm?: string;
  creDtTm?: string;
  receivedAt?: string;
}

export interface TxSummary {
  _id: string;
  fileId: string;
  batchId: string;
  msgId: string;
  pmtInfId: string;
  seq: number;
  pmtId: { instrId?: string; endToEndId: string; uetr?: string };
  view: TxView;
  status?: PaymentStatus;
}

export interface TxDoc extends TxSummary {
  cdtr?: Party;
  cdtrAcct?: Account;
  cdtrAgt?: Agent;
  ultmtCdtr?: Party;
  ultmtDbtr?: Party;
  intrmyAgt1?: Agent;
  intrmyAgt2?: Agent;
  intrmyAgt3?: Agent;
  purp?: { cd?: string; prtry?: string };
  rmtInf?: { ustrd?: string[]; strd?: unknown[] };
  context: {
    batch: BatchDoc;
    file: Pick<FileDoc, "_id" | "msgId" | "creDtTm" | "initgPty" | "validation" | "source">;
  };
  statusHistory: PaymentStatus[];
  [k: string]: unknown;
}

export interface Page<T> {
  items: T[];
  total: number;
  page: number;
  size: number;
}

export interface Summary {
  counts: { files: number; batches: number; transactions: number; statusReports: number };
  validation: Partial<Record<Status, number>>;
  paymentStatus: StatusCount[];
  totalsByCcy: CcyTotal[];
  perDay: { day: string; files: number; transactions: number }[];
  recentFiles: FileSummary[];
}

export interface GraphBatch
  extends Pick<BatchDoc, "_id" | "seq" | "pmtInfId" | "pmtMtd" | "reqdExctnDt" | "nbOfTxs" | "stats" | "validation" | "status"> {
  dbtr?: { nm?: string };
  transactions: Pick<TxSummary, "_id" | "seq" | "pmtId" | "view" | "status">[];
  more: number;
}

export interface FileGraph {
  file: FileSummary;
  batches: GraphBatch[];
  reports: ReportSummary[];
}

export interface StatusReason {
  orgtr?: Party;
  rsn?: { cd?: string; prtry?: string };
  addtlInf?: string[];
}

/** A pain.002.001.10 report as listed; the ISO tags keep their names. */
export interface ReportSummary {
  _id: string;
  msgId: string;
  creDtTm: string;
  fileId: string | null;
  dbtrAgt?: Agent;
  orgnlGrpInfAndSts: { orgnlMsgId: string; grpSts?: string; stsRsnInf?: StatusReason[] };
  source: { fileName: string; receivedAt: string; sha256?: string; sizeBytes?: number };
  stats: { pmtInfCount: number; txCount: number; txByStatus: { sts: string; count: number }[] };
  link: { status: "LINKED" | "PARTIAL" | "UNMATCHED" };
}

export interface ReportTx {
  seq: number;
  stsId?: string;
  orgnlInstrId?: string;
  orgnlEndToEndId?: string;
  orgnlUETR?: string;
  txSts?: string;
  stsRsnInf?: StatusReason[];
  accptncDtTm?: string;
  acctSvcrRef?: string;
  orgnlTxRef?: { amt?: { instdAmt?: { value: string; ccy: string } }; cdtr?: { pty?: Party } };
  txId: string | null;
}

export interface ReportPmtInf {
  seq: number;
  orgnlPmtInfId: string;
  orgnlNbOfTxs?: string;
  orgnlCtrlSum?: string;
  pmtInfSts?: string;
  stsRsnInf?: StatusReason[];
  batchId: string | null;
  txInfAndSts: ReportTx[];
}

export interface ReportDoc extends ReportSummary {
  initgPty?: Party;
  orgnlGrpInfAndSts: ReportSummary["orgnlGrpInfAndSts"] & {
    orgnlMsgNmId?: string;
    orgnlCreDtTm?: string;
    orgnlNbOfTxs?: string;
    orgnlCtrlSum?: string;
    nbOfTxsPerSts?: { dtldNbOfTxs: string; dtldSts: string; dtldCtrlSum?: string }[];
  };
  orgnlPmtInfAndSts: ReportPmtInf[];
  link: ReportSummary["link"] & { issues: Issue[] };
  file: (Pick<FileSummary, "_id" | "msgId" | "creDtTm" | "nbOfTxs" | "initgPty" | "status"> & { stats?: { txCount: number } }) | null;
  [k: string]: unknown;
}

export interface FileStatus {
  status?: PaymentStatus;
  reports: ReportSummary[];
  batchesByStatus: StatusCount[];
  transactionsByStatus: StatusCount[];
}

export interface SearchHit {
  type: "file" | "batch" | "transaction" | "report";
  id: string;
  label: string;
  detail?: string;
}

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

async function get<T>(path: string, params?: Record<string, string | number | undefined | null>): Promise<T> {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params ?? {})) {
    if (v !== undefined && v !== null && v !== "") qs.set(k, String(v));
  }
  const url = `/api${path}${qs.size ? `?${qs}` : ""}`;
  const res = await fetch(url, { headers: { Accept: "application/json", ...clientHeaders() } });
  if (!res.ok) {
    let message = `${res.status} ${res.statusText}`;
    try {
      const body = await res.json();
      message = body.error ?? body.detail ?? body.message ?? message;
    } catch {
      /* body was not JSON */
    }
    throw new ApiError(res.status, message);
  }
  return res.json() as Promise<T>;
}

export type Params = Record<string, string | number | undefined | null>;

export const api = {
  summary: () => get<Summary>("/summary"),
  parties: () => get<{ items: { name: string; files: number; transactions: number }[] }>("/parties"),
  search: (q: string) => get<{ hits: SearchHit[] }>("/search", { q }),
  files: (p: Params) => get<Page<FileSummary>>("/files", p),
  file: (id: string) => get<FileDoc>(`/files/${id}`),
  fileStatus: (id: string) => get<FileStatus>(`/files/${id}/status`),
  fileBatches: (id: string) => get<{ items: BatchDoc[] }>(`/files/${id}/batches`),
  fileGraph: (id: string, perBatch: number) => get<FileGraph>(`/files/${id}/graph`, { perBatch }),
  fileXml: (id: string) => xmlPreview(`/api/files/${id}/xml`),
  batch: (id: string) => get<BatchDoc>(`/batches/${id}`),
  batchTransactions: (id: string, p: Params) => get<Page<TxSummary>>(`/batches/${id}/transactions`, p),
  transactions: (p: Params) => get<Page<TxSummary>>("/transactions", p),
  transaction: (id: string) => get<TxDoc>(`/transactions/${id}`),
  reports: (p: Params) => get<Page<ReportSummary>>("/reports", p),
  report: (id: string) => get<ReportDoc>(`/reports/${id}`),
  reportXml: (id: string) => xmlPreview(`/api/reports/${id}/xml`),
};

export interface XmlPreview {
  text: string;
  /** True when only the start of the file was sent. */
  truncated: boolean;
  shownBytes: number;
  totalBytes: number;
}

/** The original XML, cut short by the server when the file is very large. */
async function xmlPreview(url: string): Promise<XmlPreview> {
  const res = await fetch(`${url}?preview=true`, { headers: clientHeaders() });
  if (!res.ok) throw new ApiError(res.status, "Original XML not available");
  const buf = await res.arrayBuffer();
  const total = Number(res.headers.get("X-Xml-Total-Bytes"));
  return {
    text: new TextDecoder().decode(buf),
    truncated: res.headers.get("X-Xml-Truncated") === "true",
    shownBytes: buf.byteLength,
    totalBytes: Number.isFinite(total) && total > 0 ? total : buf.byteLength,
  };
}

export function accountId(acct?: Account): string | undefined {
  return acct?.id?.iban ?? acct?.id?.othr?.id;
}
