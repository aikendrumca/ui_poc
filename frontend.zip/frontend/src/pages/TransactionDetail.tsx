import { useParams } from "react-router";
import { useQuery } from "@tanstack/react-query";
import { api } from "../api";
import { Card, Code, Copy, Crumbs, ErrorState, KeyValues, Loading, PaymentStatusBadge, Reason, StatusBadge, StatusHistory } from "../components/common";
import { JsonTree } from "../components/JsonTree";
import { PartyChain } from "../components/PartyChain";
import { date, dateTime, money } from "../format";

export function TransactionDetail() {
  const { id = "" } = useParams();
  const q = useQuery({ queryKey: ["tx", id], queryFn: () => api.transaction(id) });
  if (q.isLoading) return <Loading />;
  if (q.error) return <ErrorState error={q.error} />;
  const t = q.data!;
  const { batch, file } = t.context;
  const ustrd = t.rmtInf?.ustrd ?? [];

  return (
    <div className="page">
      <Crumbs
        items={[
          { label: "Files", to: "/files" },
          { label: file.msgId, to: `/files/${file._id}` },
          { label: batch.pmtInfId, to: `/batches/${batch._id}` },
          { label: t.pmtId.endToEndId },
        ]}
      />
      <div className="page-head row">
        <div>
          <div className="eyebrow">Transaction {t.seq + 1} of batch {batch.seq + 1}</div>
          <h1 className="mono">{t.pmtId.endToEndId}</h1>
          <p className="muted">
            {t.view.dbtrNm} → {t.view.cdtrNm}
          </p>
        </div>
        <div className="hero-side">
          <div className="hero-amount">
            <div className="num">{money(t.view.amount)}</div>
            <div className="ccy">{t.view.ccy}</div>
          </div>
          <PaymentStatusBadge status={t.status} showName />
        </div>
      </div>

      <Card title="Payment route">
        <PartyChain tx={t} />
      </Card>

      <Card title="Payment status">
        <div className="grid-2">
          <KeyValues
            items={[
              ["Current status", <PaymentStatusBadge status={t.status} showName />],
              ["Reason", <Reason code={t.status?.rsn} text={t.status?.addtlInf} />],
              ["Reported", t.status ? dateTime(t.status.at) : "—"],
            ]}
          />
          <StatusHistory items={t.statusHistory} />
        </div>
      </Card>

      <div className="grid-2">
        <Card title="References">
          <KeyValues
            items={[
              ["End-to-end ID", <Copy value={t.pmtId.endToEndId} />],
              ["Instruction ID", <Copy value={t.pmtId.instrId} />],
              ["UETR", <Copy value={t.pmtId.uetr} />],
              ["Payment information ID", <Copy value={t.pmtInfId} />],
              ["Message ID", <Copy value={t.msgId} />],
            ]}
          />
        </Card>
        <Card title="Details">
          <KeyValues
            items={[
              ["Amount", <span className="num">{money(t.view.amount, t.view.ccy)}</span>],
              ["Requested execution", date(t.view.reqdExctnDt)],
              ["Purpose", <Code value={t.purp?.cd ?? t.purp?.prtry} />],
              ["Charge bearer", <Code value={(t.chrgBr as string | undefined) ?? batch.chrgBr} />],
              ["Remittance", ustrd.length ? ustrd.join(" ") : t.rmtInf?.strd ? "Structured (see all fields)" : "—"],
              [
                "File",
                <span className="inline-stack">
                  <span className="mono small">{file.source?.fileName}</span>
                  <StatusBadge status={file.validation?.status} />
                </span>,
              ],
              ["File created", dateTime(file.creDtTm)],
            ]}
          />
        </Card>
      </div>

      <Card title="All transaction fields">
        <JsonTree value={t} hide={["_id", "fileId", "batchId", "context", "view", "seq", "status", "statusHistory"]} />
      </Card>
    </div>
  );
}
