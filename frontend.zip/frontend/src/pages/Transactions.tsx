import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { api } from "../api";
import { Card, DebouncedInput, Empty, ErrorState, Loading, Pager } from "../components/common";
import { TxTable } from "../components/TxTable";
import { useQueryParams } from "../useQueryParams";
import { AmountRange, amountParam, PartySelect, PaymentStatusSelect, TimeRange, timeParams } from "../components/Filters";

const DEFAULTS = {
  q: "", ref: "", account: "", party: "", sts: "", ccy: "", min: "", max: "", timeField: "execution", from: "", to: "",
  sort: "date", dir: "desc", page: "0",
};
const CLEARED = { q: "", ref: "", account: "", party: "", sts: "", ccy: "", min: "", max: "", from: "", to: "" };
const TIME_FIELDS = [
  { value: "execution", label: "Requested execution date", dateOnly: true },
  { value: "created", label: "File created (CreDtTm)" },
  { value: "received", label: "File received" },
];
const SIZE = 50;

export function Transactions() {
  const [p, update] = useQueryParams(DEFAULTS);
  const page = Number(p.page) || 0;
  const { data, error, isLoading, isFetching } = useQuery({
    queryKey: ["transactions", p],
    queryFn: () =>
      api.transactions({ ...p, ...timeParams(p.timeField === "execution", p.from, p.to), min: amountParam(p.min), max: amountParam(p.max), page, size: SIZE }),
    placeholderData: keepPreviousData,
  });
  const active = Object.keys(CLEARED).some((k) => p[k as keyof typeof CLEARED] !== "");

  return (
    <div className="page">
      <div className="page-head">
        <h1>Transactions</h1>
        <p className="muted">Search across every credit transfer in every file.</p>
      </div>

      <form className="filters" onSubmit={(e) => e.preventDefault()}>
        <label className="field grow">
          <span>Names or remittance text</span>
          <DebouncedInput type="search" placeholder="e.g. Litware invoice" value={p.q} onChange={(q) => update({ q })} />
        </label>
        <label className="field">
          <span>Reference</span>
          <DebouncedInput placeholder="EndToEndId, InstrId, UETR" value={p.ref} onChange={(ref) => update({ ref })} />
        </label>
        <label className="field">
          <span>Account (IBAN)</span>
          <DebouncedInput placeholder="Debtor or creditor" value={p.account} onChange={(account) => update({ account })} />
        </label>
        <PartySelect value={p.party} onChange={(party) => update({ party })} />
        <PaymentStatusSelect value={p.sts} onChange={(sts) => update({ sts })} />
        {active && (
          <button type="button" className="btn ghost align-end" onClick={() => update(CLEARED)}>
            Clear filters
          </button>
        )}
        <div className="filter-groups">
          <TimeRange fields={TIME_FIELDS} field={p.timeField} from={p.from} to={p.to} onChange={update} />
          <AmountRange legend="Amount" ccy={p.ccy} min={p.min} max={p.max} onChange={update} />
        </div>
      </form>

      <Card className={isFetching ? "is-fetching" : ""}>
        {isLoading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} />
        ) : data!.items.length === 0 ? (
          <Empty>No transactions match these filters.</Empty>
        ) : (
          <>
            <TxTable items={data!.items} sort={p.sort} dir={p.dir} onSort={(sort, dir) => update({ sort, dir })} showBatch />
            <Pager page={page} size={SIZE} total={data!.total} onPage={(n) => update({ page: String(n) }, false)} />
          </>
        )}
      </Card>
    </div>
  );
}
