import { Link, useNavigate } from "react-router";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { api } from "../api";
import { Card, DebouncedInput, Empty, ErrorState, Loading, Pager, PaymentStatusBadge, SortHeader, StatusBadge, Totals } from "../components/common";
import { dateTime, num } from "../format";
import { useQueryParams } from "../useQueryParams";
import { AmountRange, amountParam, PartySelect, PaymentStatusSelect, TimeRange, timeParams } from "../components/Filters";

const DEFAULTS = {
  q: "", status: "", sts: "", party: "", timeField: "received", from: "", to: "", ccy: "", min: "", max: "",
  sort: "received", dir: "desc", page: "0",
};
const CLEARED = { q: "", status: "", sts: "", party: "", from: "", to: "", ccy: "", min: "", max: "" };
const TIME_FIELDS = [
  { value: "received", label: "Received" },
  { value: "created", label: "Created (CreDtTm)" },
];

export function Files() {
  const navigate = useNavigate();
  const [p, update] = useQueryParams(DEFAULTS);
  const page = Number(p.page) || 0;
  const { data, error, isLoading, isFetching } = useQuery({
    queryKey: ["files", p],
    queryFn: () =>
      api.files({ ...p, ...timeParams(p.timeField === "execution", p.from, p.to), min: amountParam(p.min), max: amountParam(p.max), page, size: 25 }),
    placeholderData: keepPreviousData,
  });
  const onSort = (sort: string, dir: string) => update({ sort, dir });
  const active = Object.keys(CLEARED).some((k) => p[k as keyof typeof CLEARED] !== "");

  return (
    <div className="page">
      <div className="page-head">
        <h1>Files</h1>
        <p className="muted">One row per pain.001 message (group header), with the latest pain.002 status the bank reported for it.</p>
      </div>

      <form className="filters" onSubmit={(e) => e.preventDefault()}>
        <label className="field grow">
          <span>Search</span>
          <DebouncedInput
            type="search"
            placeholder="Message ID, initiating party or file name"
            value={p.q}
            onChange={(q) => update({ q })}
          />
        </label>
        <label className="field">
          <span>Validation</span>
          <select value={p.status} onChange={(e) => update({ status: e.target.value })}>
            <option value="">Any</option>
            <option value="VALID">Valid</option>
            <option value="WARN">Warning</option>
            <option value="INVALID">Invalid</option>
          </select>
        </label>
        <PaymentStatusSelect value={p.sts} onChange={(sts) => update({ sts })} />
        <PartySelect value={p.party} onChange={(party) => update({ party })} />
        {active && (
          <button type="button" className="btn ghost align-end" onClick={() => update(CLEARED)}>
            Clear filters
          </button>
        )}
        <div className="filter-groups">
          <TimeRange fields={TIME_FIELDS} field={p.timeField} from={p.from} to={p.to} onChange={update} />
          <AmountRange legend="File total (any currency in the file)" ccy={p.ccy} min={p.min} max={p.max} onChange={update} />
        </div>
      </form>

      <Card className={isFetching ? "is-fetching" : ""}>
        {isLoading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} />
        ) : data!.items.length === 0 ? (
          <Empty>No files match these filters.</Empty>
        ) : (
          <>
            <div className="table-wrap">
              <table className="table clickable">
                <thead>
                  <tr>
                    <SortHeader label="Received" field="received" sort={p.sort} dir={p.dir} onSort={onSort} />
                    <SortHeader label="Message ID" field="msgId" sort={p.sort} dir={p.dir} onSort={onSort} />
                    <SortHeader label="Created" field="created" sort={p.sort} dir={p.dir} onSort={onSort} />
                    <th>Initiating party</th>
                    <th className="right">Batches</th>
                    <SortHeader label="Txs" field="txCount" sort={p.sort} dir={p.dir} onSort={onSort} align="right" />
                    <th>Totals</th>
                    <th>Validation</th>
                    <th>Payment</th>
                  </tr>
                </thead>
                <tbody>
                  {data!.items.map((f) => (
                    <tr key={f._id} onClick={() => navigate(`/files/${f._id}`)}>
                      <td className="nowrap">{dateTime(f.source.receivedAt)}</td>
                      <td>
                        <Link className="mono row-link" to={`/files/${f._id}`} onClick={(e) => e.stopPropagation()}>
                          {f.msgId}
                        </Link>
                        <div className="muted small">{f.source.fileName}</div>
                      </td>
                      <td className="nowrap">{dateTime(f.creDtTm)}</td>
                      <td>{f.initgPty?.nm ?? "—"}</td>
                      <td className="right num">{num(f.stats.batchCount)}</td>
                      <td className="right num">{num(f.stats.txCount)}</td>
                      <td>
                        <Totals totals={f.stats.totalsByCcy} compact />
                      </td>
                      <td>
                        <StatusBadge status={f.validation.status} />
                      </td>
                      <td>
                        <PaymentStatusBadge status={f.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pager page={page} size={25} total={data!.total} onPage={(n) => update({ page: String(n) }, false)} />
          </>
        )}
      </Card>
    </div>
  );
}
