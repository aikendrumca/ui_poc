import { useState } from "react";
import { useParams } from "react-router";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { api, accountId } from "../api";
import {
  Card,
  Code,
  Copy,
  Crumbs,
  Empty,
  ErrorState,
  Issues,
  KeyValues,
  Loading,
  Pager,
  PaymentStatusBadge,
  StatusBadge,
  StatusHistory,
  Totals,
} from "../components/common";
import { JsonTree } from "../components/JsonTree";
import { TxTable } from "../components/TxTable";
import { date, dateTime, iban, money, num } from "../format";

const SIZE = 50;

export function BatchDetail() {
  const { id = "" } = useParams();
  const [page, setPage] = useState(0);
  const [sort, setSort] = useState({ sort: "seq", dir: "asc" });
  const [showAll, setShowAll] = useState(false);
  const batch = useQuery({ queryKey: ["batch", id], queryFn: () => api.batch(id) });
  const txs = useQuery({
    queryKey: ["batchTx", id, page, sort],
    queryFn: () => api.batchTransactions(id, { page, size: SIZE, ...sort }),
    placeholderData: keepPreviousData,
  });

  if (batch.isLoading) return <Loading />;
  if (batch.error) return <ErrorState error={batch.error} />;
  const b = batch.data!;
  const svc = (b.pmtTpInf?.svcLvl as { cd?: string }[] | undefined)?.[0]?.cd;
  const ctgy = (b.pmtTpInf?.ctgyPurp as { cd?: string } | undefined)?.cd;
  const prty = b.pmtTpInf?.instrPrty as string | undefined;
  const countMismatch = b.nbOfTxs !== b.stats.txCount;

  return (
    <div className="page">
      <Crumbs items={[{ label: "Files", to: "/files" }, { label: b.msgId, to: `/files/${b.fileId}` }, { label: b.pmtInfId }]} />
      <div className="page-head row">
        <div>
          <div className="eyebrow">Batch {b.seq + 1} · payment information</div>
          <h1 className="mono">{b.pmtInfId}</h1>
          <p className="muted">
            {b.dbtr?.nm} · executes {date(b.reqdExctnDt?.date)}
          </p>
        </div>
        <div className="inline-stack">
          <StatusBadge status={b.validation.status} />
          <PaymentStatusBadge status={b.status} showName />
        </div>
      </div>

      <div className="grid-3">
        <Card title="Debtor">
          <KeyValues
            items={[
              ["Name", b.dbtr?.nm],
              ["Account", <span className="mono">{iban(accountId(b.dbtrAcct))}</span>],
              ["Account currency", b.dbtrAcct?.ccy],
              ["Agent (BIC)", <span className="mono">{b.dbtrAgt?.finInstnId?.bicfi ?? "—"}</span>],
              ["Ultimate debtor", b.ultmtDbtr?.nm ?? "—"],
            ]}
          />
        </Card>
        <Card title="Instruction">
          <KeyValues
            items={[
              ["Payment method", <Code value={b.pmtMtd} />],
              ["Execution date", b.reqdExctnDt?.hasTime ? dateTime(b.reqdExctnDt.date) : date(b.reqdExctnDt?.date)],
              ["Service level", <Code value={svc} />],
              ["Category purpose", <Code value={ctgy} />],
              ["Priority", <Code value={prty} />],
              ["Charge bearer", <Code value={b.chrgBr} />],
              ["Batch booking", b.btchBookg == null ? "—" : b.btchBookg ? "Yes" : "No"],
            ]}
          />
        </Card>
        <Card title="Totals">
          <KeyValues
            items={[
              [
                "Transactions",
                <span className={countMismatch ? "bad" : undefined}>
                  {num(b.stats.txCount)} found{countMismatch && ` · ${num(b.nbOfTxs)} declared`}
                </span>,
              ],
              ["Control sum", b.ctrlSum ? money(b.ctrlSum) : "Not provided"],
              ["By currency", <Totals totals={b.stats.totalsByCcy} />],
              ["File", <Copy value={b.msgId} />],
            ]}
          />
          <Issues issues={b.validation.issues} />
        </Card>
      </div>

      <Card title="Payment status history">
        <StatusHistory items={b.statusHistory} />
      </Card>

      <Card title={`Transactions (${num(b.stats.txCount)})`}>
        {txs.isLoading ? (
          <Loading />
        ) : txs.error ? (
          <ErrorState error={txs.error} />
        ) : txs.data!.items.length === 0 ? (
          <Empty>No transactions.</Empty>
        ) : (
          <>
            <TxTable
              items={txs.data!.items}
              sort={sort.sort}
              dir={sort.dir}
              onSort={(s, d) => {
                setSort({ sort: s, dir: d });
                setPage(0);
              }}
            />
            <Pager page={page} size={SIZE} total={txs.data!.total} onPage={setPage} />
          </>
        )}
      </Card>

      <Card
        title="All batch fields"
        actions={
          <button type="button" className="btn" onClick={() => setShowAll(!showAll)}>
            {showAll ? "Hide" : "Show"}
          </button>
        }
      >
        {showAll && <JsonTree value={b} hide={["_id", "fileId", "stats", "validation", "seq", "status", "statusHistory"]} />}
      </Card>
    </div>
  );
}
