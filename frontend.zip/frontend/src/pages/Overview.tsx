import { Link } from "react-router";
import { useQuery } from "@tanstack/react-query";
import { api, type Summary } from "../api";
import { Card, Empty, ErrorState, Loading, PaymentBadge, PaymentStatusBadge, StatusBadge, Totals } from "../components/common";
import { PAYMENT_STATUS } from "../glossary";
import { money, num, relative } from "../format";

export function Overview() {
  const { data, error, isLoading } = useQuery({ queryKey: ["summary"], queryFn: api.summary, refetchInterval: 15000 });
  if (isLoading) return <Loading />;
  if (error) return <ErrorState error={error} />;
  const s = data!;
  const invalid = s.validation.INVALID ?? 0;
  const warn = s.validation.WARN ?? 0;
  const rejected = s.paymentStatus.find((p) => p.code === "RJCT")?.count ?? 0;

  return (
    <div className="page">
      <div className="page-head">
        <h1>Overview</h1>
        <p className="muted">Everything loaded from pain.001 files and the pain.002 status reports that answer them. Refreshes every 15 seconds.</p>
      </div>

      <div className="tiles">
        <Tile label="Files" value={num(s.counts.files)} detail={`${num(s.counts.batches)} batches`} to="/files" />
        <Tile
          label="Transactions"
          value={num(s.counts.transactions)}
          detail={rejected ? `${num(rejected)} rejected by the bank` : undefined}
          tone={rejected ? "bad" : undefined}
          to={rejected ? "/transactions?sts=RJCT" : "/transactions"}
        />
        <Tile label="Status reports" value={num(s.counts.statusReports)} detail="pain.002" to="/reports" />
        <Tile
          label="Files needing attention"
          value={num(invalid + warn)}
          detail={`${num(invalid)} invalid · ${num(warn)} with warnings`}
          tone={invalid ? "bad" : warn ? "warn" : undefined}
          to={invalid ? "/files?status=INVALID" : warn ? "/files?status=WARN" : undefined}
        />
      </div>

      <div className="grid-2">
        <Card title="Files received, last 14 days">
          <PerDay data={s.perDay} />
        </Card>
        <Card title="Value by currency">
          {s.totalsByCcy.length === 0 ? (
            <Empty>No transactions yet.</Empty>
          ) : (
            <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>Currency</th>
                  <th className="right">Transactions</th>
                  <th className="right">Total</th>
                </tr>
              </thead>
              <tbody>
                {s.totalsByCcy.map((t) => (
                  <tr key={t.ccy}>
                    <td>
                      <Link to={`/transactions?ccy=${t.ccy}`}>{t.ccy}</Link>
                    </td>
                    <td className="right num">{num(t.count)}</td>
                    <td className="right num">{money(t.amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          )}
        </Card>
      </div>

      <Card title="Transactions by payment status">
        <PaymentStatusBars data={s.paymentStatus} />
      </Card>

      <Card title="Recently received" actions={<Link to="/files">All files</Link>}>
        {s.recentFiles.length === 0 ? (
          <Empty>
            No files yet. Drop pain.001.001.09 XML files into the inbox folder, or run
            <code> gradlew generateSamples</code>.
          </Empty>
        ) : (
          <div className="table-wrap">
          <table className="table clickable">
            <thead>
              <tr>
                <th>Received</th>
                <th>Message ID</th>
                <th>Initiating party</th>
                <th className="right">Txs</th>
                <th>Totals</th>
                <th>Validation</th>
                <th>Payment</th>
              </tr>
            </thead>
            <tbody>
              {s.recentFiles.map((f) => (
                <tr key={f._id}>
                  <td className="muted">{relative(f.source.receivedAt)}</td>
                  <td>
                    <Link className="mono row-link" to={`/files/${f._id}`}>{f.msgId}</Link>
                  </td>
                  <td>{f.initgPty?.nm ?? "—"}</td>
                  <td className="right num">{num(f.stats.txCount)}</td>
                  <td>
                    <Totals totals={f.stats.totalsByCcy} compact />
                  </td>
                  <td>
                    <StatusBadge status={f.validation.status} />
                  </td>
                  <td>
                    <PaymentStatusBadge status={f.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        )}
      </Card>
    </div>
  );
}

function Tile({ label, value, detail, tone, to }: { label: string; value: string; detail?: string; tone?: "bad" | "warn"; to?: string }) {
  const body = (
    <>
      <div className="tile-label">{label}</div>
      <div className="tile-value num">{value}</div>
      {detail && <div className="tile-detail">{detail}</div>}
    </>
  );
  return to ? (
    <Link to={to} className={`tile ${tone ? `tile-${tone}` : ""}`}>{body}</Link>
  ) : (
    <div className={`tile ${tone ? `tile-${tone}` : ""}`}>{body}</div>
  );
}

/** One bar per status, longest first, each linking to the matching transactions. */
function PaymentStatusBars({ data }: { data: Summary["paymentStatus"] }) {
  const total = data.reduce((n, d) => n + d.count, 0);
  if (!total) return <Empty>No transactions yet.</Empty>;
  const max = Math.max(...data.map((d) => d.count));
  return (
    <ul className="hbars">
      {data.map((d) => (
        <li key={d.code}>
          <Link to={`/transactions?sts=${d.code}`} className="hbar-label">
            <PaymentBadge code={d.code === "NONE" ? undefined : d.code} />
            <span className="muted small">{d.code === "NONE" ? "No status report yet" : PAYMENT_STATUS[d.code]?.name ?? d.code}</span>
          </Link>
          <span className="hbar-track">
            <span className={`hbar tone-${d.code === "NONE" ? "none" : PAYMENT_STATUS[d.code]?.tone ?? "info"}`} style={{ width: `${(d.count / max) * 100}%` }} />
          </span>
          <span className="num">{num(d.count)}</span>
        </li>
      ))}
    </ul>
  );
}

function PerDay({ data }: { data: Summary["perDay"] }) {
  const days: { day: string; files: number; transactions: number }[] = [];
  const byDay = new Map(data.map((d) => [d.day, d]));
  for (let i = 13; i >= 0; i--) {
    const d = new Date();
    d.setUTCDate(d.getUTCDate() - i);
    const key = d.toISOString().slice(0, 10);
    days.push(byDay.get(key) ?? { day: key, files: 0, transactions: 0 });
  }
  const max = Math.max(1, ...days.map((d) => d.files));
  return (
    <div className="bars" role="img" aria-label="Files received per day over the last 14 days">
      {days.map((d) => (
        <div key={d.day} className="bar-col" title={`${d.day}: ${d.files} files, ${d.transactions} transactions`}>
          <div className="bar-track">
            <div className="bar" style={{ height: `${(d.files / max) * 100}%` }} />
          </div>
          <div className="bar-label">{Number(d.day.slice(8))}</div>
        </div>
      ))}
    </div>
  );
}
