import { Link, useNavigate } from "react-router";
import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { api, type ReportSummary } from "../api";
import { Card, DebouncedInput, Empty, ErrorState, Loading, Pager, PaymentBadge, SortHeader } from "../components/common";
import { PaymentStatusSelect, TimeRange, timeParams } from "../components/Filters";
import { dateTime, num } from "../format";
import { useQueryParams } from "../useQueryParams";

const DEFAULTS = { q: "", sts: "", link: "", fileId: "", timeField: "received", from: "", to: "", sort: "received", dir: "desc", page: "0" };
const CLEARED = { q: "", sts: "", link: "", fileId: "", from: "", to: "" };
const TIME_FIELDS = [
  { value: "received", label: "Received" },
  { value: "created", label: "Created (CreDtTm)" },
];
const SIZE = 25;

export const LINK_TEXT: Record<ReportSummary["link"]["status"], string> = {
  LINKED: "Linked",
  PARTIAL: "Partly linked",
  UNMATCHED: "Original not loaded",
};

export function LinkState({ status }: { status: ReportSummary["link"]["status"] }) {
  const cls = status === "LINKED" ? "badge-valid" : status === "PARTIAL" ? "badge-warn" : "badge-invalid";
  return (
    <span className={`badge ${cls}`}>
      <span className="dot" aria-hidden />
      {LINK_TEXT[status]}
    </span>
  );
}

export function Reports() {
  const navigate = useNavigate();
  const [p, update] = useQueryParams(DEFAULTS);
  const page = Number(p.page) || 0;
  const { data, error, isLoading, isFetching } = useQuery({
    queryKey: ["reports", p],
    queryFn: () => api.reports({ ...p, ...timeParams(false, p.from, p.to), page, size: SIZE }),
    placeholderData: keepPreviousData,
  });
  const onSort = (sort: string, dir: string) => update({ sort, dir });
  const active = Object.keys(CLEARED).some((k) => p[k as keyof typeof CLEARED] !== "");

  return (
    <div className="page">
      <div className="page-head">
        <h1>Status reports</h1>
        <p className="muted">One row per pain.002 customer payment status report, linked to the pain.001 file it answers.</p>
      </div>

      <form className="filters" onSubmit={(e) => e.preventDefault()}>
        <label className="field grow">
          <span>Search</span>
          <DebouncedInput
            type="search"
            placeholder="Report MsgId, original MsgId or file name"
            value={p.q}
            onChange={(q) => update({ q })}
          />
        </label>
        <PaymentStatusSelect value={p.sts} onChange={(sts) => update({ sts })} label="Group status" allowNone={false} />
        <label className="field">
          <span>Link to original</span>
          <select value={p.link} onChange={(e) => update({ link: e.target.value })}>
            <option value="">Any</option>
            {Object.entries(LINK_TEXT).map(([k, v]) => (
              <option key={k} value={k}>{v}</option>
            ))}
          </select>
        </label>
        {p.fileId && (
          <button type="button" className="chip align-end" onClick={() => update({ fileId: "" })} title="Show reports for every file">
            One file only ✕
          </button>
        )}
        {active && (
          <button type="button" className="btn ghost align-end" onClick={() => update(CLEARED)}>
            Clear filters
          </button>
        )}
        <div className="filter-groups">
          <TimeRange fields={TIME_FIELDS} field={p.timeField} from={p.from} to={p.to} onChange={update} />
        </div>
      </form>

      <Card className={isFetching ? "is-fetching" : ""}>
        {isLoading ? (
          <Loading />
        ) : error ? (
          <ErrorState error={error} />
        ) : data!.items.length === 0 ? (
          <Empty>
            No status reports match. Drop pain.002.001.10 XML files into the inbox folder, or run <code>gradlew generateStatusReports</code>.
          </Empty>
        ) : (
          <>
            <div className="table-wrap">
              <table className="table clickable">
                <thead>
                  <tr>
                    <SortHeader label="Received" field="received" sort={p.sort} dir={p.dir} onSort={onSort} />
                    <SortHeader label="Report" field="msgId" sort={p.sort} dir={p.dir} onSort={onSort} />
                    <SortHeader label="Created" field="created" sort={p.sort} dir={p.dir} onSort={onSort} />
                    <th>Original file</th>
                    <th>Group status</th>
                    <th>Transactions named</th>
                    <th>Link</th>
                  </tr>
                </thead>
                <tbody>
                  {data!.items.map((r) => (
                    <tr key={r._id} onClick={() => navigate(`/reports/${r._id}`)}>
                      <td className="nowrap">{dateTime(r.source.receivedAt)}</td>
                      <td>
                        <Link className="mono row-link" to={`/reports/${r._id}`} onClick={(e) => e.stopPropagation()}>
                          {r.msgId}
                        </Link>
                        <div className="muted small">{r.source.fileName}</div>
                      </td>
                      <td className="nowrap">{dateTime(r.creDtTm)}</td>
                      <td>
                        {r.fileId ? (
                          <Link className="mono" to={`/files/${r.fileId}`} onClick={(e) => e.stopPropagation()}>
                            {r.orgnlGrpInfAndSts.orgnlMsgId}
                          </Link>
                        ) : (
                          <span className="mono muted">{r.orgnlGrpInfAndSts.orgnlMsgId}</span>
                        )}
                      </td>
                      <td>
                        {r.orgnlGrpInfAndSts.grpSts ? (
                          <PaymentBadge code={r.orgnlGrpInfAndSts.grpSts} reason={r.orgnlGrpInfAndSts.stsRsnInf?.[0]?.rsn?.cd} />
                        ) : (
                          <span className="muted small">Per batch</span>
                        )}
                      </td>
                      <td>
                        {r.stats.txByStatus.length === 0 ? (
                          <span className="muted small">None</span>
                        ) : (
                          <span className="inline-stack">
                            {r.stats.txByStatus.map((c) => (
                              <span key={c.sts} className="nowrap">
                                <span className="num">{num(c.count)}</span> <PaymentBadge code={c.sts} />
                              </span>
                            ))}
                          </span>
                        )}
                      </td>
                      <td>
                        <LinkState status={r.link.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <Pager page={page} size={SIZE} total={data!.total} onPage={(n) => update({ page: String(n) }, false)} />
          </>
        )}
      </Card>
    </div>
  );
}
