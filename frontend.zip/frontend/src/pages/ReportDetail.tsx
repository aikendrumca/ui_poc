import { useState } from "react";
import { Link, useParams } from "react-router";
import { useQuery } from "@tanstack/react-query";
import { api, type ReportDoc, type StatusReason } from "../api";
import { track } from "../audit";
import { Card, Copy, Crumbs, Empty, ErrorState, Issues, KeyValues, Loading, PaymentBadge, PaymentStatusBadge, Reason, XmlView } from "../components/common";
import { JsonTree } from "../components/JsonTree";
import { dateTime, money, num } from "../format";
import { LinkState } from "./Reports";

type Tab = "transactions" | "fields" | "xml";

function firstReason(r?: StatusReason[]) {
  const first = r?.[0];
  return { code: first?.rsn?.cd ?? first?.rsn?.prtry, text: first?.addtlInf?.join(" ") };
}

export function ReportDetail() {
  const { id = "" } = useParams();
  const [tab, setTab] = useState<Tab>("transactions");
  const q = useQuery({ queryKey: ["report", id], queryFn: () => api.report(id) });
  if (q.isLoading) return <Loading />;
  if (q.error) return <ErrorState error={q.error} />;
  const r = q.data!;
  const grp = r.orgnlGrpInfAndSts;
  const grpReason = firstReason(grp.stsRsnInf);
  const txCount = r.orgnlPmtInfAndSts.reduce((n, p) => n + p.txInfAndSts.length, 0);

  return (
    <div className="page">
      <Crumbs items={[{ label: "Status reports", to: "/reports" }, { label: r.msgId }]} />
      <div className="page-head row">
        <div>
          <div className="eyebrow">pain.002 status report</div>
          <h1 className="mono">{r.msgId}</h1>
          <p className="muted">
            For{" "}
            {r.file ? (
              <Link className="mono" to={`/files/${r.fileId}`}>
                {grp.orgnlMsgId}
              </Link>
            ) : (
              <span className="mono">{grp.orgnlMsgId}</span>
            )}{" "}
            · created {dateTime(r.creDtTm)}
          </p>
        </div>
        <div className="inline-stack">
          {grp.grpSts && <PaymentBadge code={grp.grpSts} showName />}
          <LinkState status={r.link.status} />
        </div>
      </div>

      <div className="grid-2">
        <Card title="Original message">
          <KeyValues
            items={[
              ["Message ID", r.file ? <Link className="mono" to={`/files/${r.fileId}`}>{grp.orgnlMsgId}</Link> : <Copy value={grp.orgnlMsgId} />],
              ["Message type", <span className="mono">{grp.orgnlMsgNmId}</span>],
              ["Created", dateTime(grp.orgnlCreDtTm)],
              ["Transactions", grp.orgnlNbOfTxs ? num(Number(grp.orgnlNbOfTxs)) : "—"],
              ["Control sum", grp.orgnlCtrlSum ? money(grp.orgnlCtrlSum) : "—"],
              ["Initiating party", r.file?.initgPty?.nm],
              ["File status now", r.file ? <PaymentStatusBadge status={r.file.status} showName /> : "Original file not loaded yet"],
            ]}
          />
          {r.link.issues.length > 0 ? (
            <>
              <h3 className="sub-title">Linking</h3>
              <Issues issues={r.link.issues} />
            </>
          ) : (
            <p className="muted small ok-note">Every reference in this report matched the original file.</p>
          )}
        </Card>
        <Card title="Report">
          <KeyValues
            items={[
              ["Message ID", <Copy value={r.msgId} />],
              ["Created", dateTime(r.creDtTm)],
              ["Sent by (debtor agent)", <span className="mono">{r.dbtrAgt?.finInstnId?.bicfi ?? r.initgPty?.nm ?? "—"}</span>],
              ["Group status", grp.grpSts ? <PaymentBadge code={grp.grpSts} showName /> : "Given per batch"],
              ["Reason", <Reason code={grpReason.code} text={grpReason.text} />],
              ["File name", <span className="mono">{r.source.fileName}</span>],
              ["Received", dateTime(r.source.receivedAt)],
            ]}
          />
          {grp.nbOfTxsPerSts?.length ? (
            <>
              <h3 className="sub-title">Transactions per status</h3>
              <div className="inline-stack">
                {grp.nbOfTxsPerSts.map((n) => (
                  <span key={n.dtldSts}>
                    <span className="num">{num(Number(n.dtldNbOfTxs))}</span> <PaymentBadge code={n.dtldSts} />
                  </span>
                ))}
              </div>
            </>
          ) : null}
        </Card>
      </div>

      {r.orgnlPmtInfAndSts.length > 0 && (
        <Card title={`Batches (${r.orgnlPmtInfAndSts.length})`}>
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>Original payment information ID</th>
                  <th>Status</th>
                  <th>Reason</th>
                  <th className="right">Original txs</th>
                  <th className="right">Txs named</th>
                </tr>
              </thead>
              <tbody>
                {r.orgnlPmtInfAndSts.map((p) => {
                  const reason = firstReason(p.stsRsnInf);
                  return (
                    <tr key={p.seq}>
                      <td>
                        {p.batchId ? (
                          <Link className="mono" to={`/batches/${p.batchId}`}>{p.orgnlPmtInfId}</Link>
                        ) : (
                          <span className="mono muted" title="No batch with this ID in the original file">{p.orgnlPmtInfId}</span>
                        )}
                      </td>
                      <td>{p.pmtInfSts ? <PaymentBadge code={p.pmtInfSts} showName /> : <span className="muted small">Not given</span>}</td>
                      <td>
                        <Reason code={reason.code} text={reason.text} />
                      </td>
                      <td className="right num">{p.orgnlNbOfTxs ?? "—"}</td>
                      <td className="right num">{num(p.txInfAndSts.length)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <div className="tabs" role="tablist">
        {(
          [
            ["transactions", `Transactions named (${num(txCount)})`],
            ["fields", "All fields"],
            ["xml", "Original XML"],
          ] as [Tab, string][]
        ).map(([key, text]) => (
          <button key={key} type="button" role="tab" aria-selected={tab === key} className={`tab ${tab === key ? "active" : ""}`} onClick={() => {
              track("report.tab", { type: "report", id, label: r.msgId }, { tab: key });
              setTab(key);
            }}>
            {text}
          </button>
        ))}
      </div>

      {tab === "transactions" && <TransactionsTab report={r} />}
      {tab === "fields" && (
        <Card>
          <JsonTree value={r} hide={["_id", "source", "stats", "link", "rawXmlRef", "file", "fileId"]} />
        </Card>
      )}
      {tab === "xml" && <XmlTab id={id} />}
    </div>
  );
}

function TransactionsTab({ report }: { report: ReportDoc }) {
  const rows = report.orgnlPmtInfAndSts.flatMap((p) => p.txInfAndSts.map((t) => ({ p, t })));
  if (rows.length === 0) {
    return (
      <Card>
        <Empty>This report gives its status for the whole {report.orgnlPmtInfAndSts.length ? "batch" : "file"} and names no single transaction.</Empty>
      </Card>
    );
  }
  return (
    <Card>
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              <th>Original end-to-end ID</th>
              <th>Batch</th>
              <th>Status</th>
              <th>Reason</th>
              <th>Creditor</th>
              <th className="right">Amount</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(({ p, t }) => {
              const reason = firstReason(t.stsRsnInf);
              const amt = t.orgnlTxRef?.amt?.instdAmt;
              const ref = t.orgnlEndToEndId ?? t.orgnlInstrId ?? t.orgnlUETR ?? "—";
              return (
                <tr key={`${p.seq}-${t.seq}`}>
                  <td>
                    {t.txId ? (
                      <Link className="mono" to={`/transactions/${t.txId}`}>{ref}</Link>
                    ) : (
                      <span className="mono muted" title="No matching transaction in the original file">{ref}</span>
                    )}
                    {t.orgnlUETR && <div className="muted small mono">{t.orgnlUETR}</div>}
                  </td>
                  <td className="mono small">{p.orgnlPmtInfId}</td>
                  <td>{t.txSts ? <PaymentBadge code={t.txSts} showName /> : "—"}</td>
                  <td>
                    <Reason code={reason.code} text={reason.text} />
                  </td>
                  <td>{t.orgnlTxRef?.cdtr?.pty?.nm ?? "—"}</td>
                  <td className="right num nowrap">{amt ? money(amt.value, amt.ccy) : "—"}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function XmlTab({ id }: { id: string }) {
  const q = useQuery({ queryKey: ["reportXml", id], queryFn: () => api.reportXml(id) });
  return (
    <Card
      title="Original XML"
      actions={
        <a className="btn" href={`/api/reports/${id}/xml`} download onClick={() => track("xml.download", { type: "report", id })}>
          Download
        </a>
      }
    >
      {q.isLoading ? <Loading /> : q.error ? <ErrorState error={q.error} /> : <XmlView xml={q.data!} />}
    </Card>
  );
}
