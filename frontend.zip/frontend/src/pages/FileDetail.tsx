import { lazy, Suspense, useState } from "react";
import { Link, useNavigate, useParams } from "react-router";
import { useQuery } from "@tanstack/react-query";
import { api } from "../api";
import { track } from "../audit";
import { accountId } from "../api";
import {
  Card,
  Code,
  Copy,
  Crumbs,
  Empty,
  ErrorState,
  Issues,
  KeyValues,
  Loading,
  PaymentBadge,
  PaymentStatusBadge,
  Reason,
  StatusBadge,
  StatusCounts,
  Totals,
  XmlView,
} from "../components/common";
import { JsonTree } from "../components/JsonTree";
import { bytes, date, dateTime, iban, money, num } from "../format";

// The graph library is the largest dependency; load it only when the tab opens.
const FileGraph = lazy(() => import("../components/FileGraph").then((m) => ({ default: m.FileGraph })));

type Tab = "graph" | "batches" | "header" | "xml";

export function FileDetail() {
  const { id = "" } = useParams();
  const [tab, setTab] = useState<Tab>("graph");
  const file = useQuery({ queryKey: ["file", id], queryFn: () => api.file(id) });

  if (file.isLoading) return <Loading />;
  if (file.error) return <ErrorState error={file.error} />;
  const f = file.data!;
  const declaredMismatch = f.nbOfTxs !== f.stats.txCount;

  return (
    <div className="page">
      <Crumbs items={[{ label: "Files", to: "/files" }, { label: f.msgId }]} />
      <div className="page-head row">
        <div>
          <div className="eyebrow">Payment file</div>
          <h1 className="mono">{f.msgId}</h1>
          <p className="muted">
            {f.initgPty?.nm ?? "Unknown initiating party"} · created {dateTime(f.creDtTm)}
          </p>
        </div>
        <div className="inline-stack">
          <StatusBadge status={f.validation.status} />
          <PaymentStatusBadge status={f.status} showName />
        </div>
      </div>

      <div className="grid-2">
        <Card title="Group header">
          <KeyValues
            items={[
              ["Message ID", <Copy value={f.msgId} />],
              ["Created", dateTime(f.creDtTm)],
              ["Initiating party", f.initgPty?.nm],
              [
                "Transactions",
                <span className={declaredMismatch ? "bad" : undefined}>
                  {num(f.stats.txCount)} found{declaredMismatch && ` · ${num(f.nbOfTxs)} declared`}
                </span>,
              ],
              ["Control sum", f.ctrlSum ? money(f.ctrlSum) : "Not provided"],
              ["Batches", num(f.stats.batchCount)],
              ["Totals", <Totals totals={f.stats.totalsByCcy} />],
            ]}
          />
        </Card>
        <Card title="Source">
          <KeyValues
            items={[
              ["File name", <span className="mono">{f.source.fileName}</span>],
              ["Received", dateTime(f.source.receivedAt)],
              ["Channel", f.source.channel],
              ["Size", bytes(f.source.sizeBytes)],
              ["SHA-256", <span className="mono small break">{f.source.sha256}</span>],
            ]}
          />
          {f.validation.issues?.length ? (
            <>
              <h3 className="sub-title">Validation</h3>
              <Issues issues={f.validation.issues} />
            </>
          ) : (
            <p className="muted small ok-note">Counts and control sums match.</p>
          )}
        </Card>
      </div>

      <PaymentStatusCard id={id} />

      <div className="tabs" role="tablist">
        {(
          [
            ["graph", "Link graph"],
            ["batches", `Batches (${f.stats.batchCount})`],
            ["header", "Header fields"],
            ["xml", "Original XML"],
          ] as [Tab, string][]
        ).map(([key, text]) => (
          <button key={key} type="button" role="tab" aria-selected={tab === key} className={`tab ${tab === key ? "active" : ""}`} onClick={() => {
              track("file.tab", { type: "file", id, label: f.msgId }, { tab: key });
              setTab(key);
            }}>
            {text}
          </button>
        ))}
      </div>

      {tab === "graph" && <GraphTab id={id} />}
      {tab === "batches" && <BatchesTab id={id} />}
      {tab === "header" && (
        <Card>
          <JsonTree value={f} hide={["_id", "source", "stats", "validation", "rawXmlRef", "status"]} />
        </Card>
      )}
      {tab === "xml" && <XmlTab id={id} />}
    </div>
  );
}

/** What the bank said about this file in its pain.002 status reports. */
function PaymentStatusCard({ id }: { id: string }) {
  const q = useQuery({ queryKey: ["fileStatus", id], queryFn: () => api.fileStatus(id) });
  if (q.isLoading) return <Loading label="Loading payment status" />;
  if (q.error) return <ErrorState error={q.error} />;
  const s = q.data!;
  return (
    <Card
      title="Payment status"
      actions={
        s.reports.length > 0 && (
          <Link className="btn" to={`/reports?fileId=${id}`}>
            All reports
          </Link>
        )
      }
    >
      {s.reports.length === 0 ? (
        <Empty>No pain.002 status report has arrived for this file yet.</Empty>
      ) : (
        <div className="grid-2">
          <div>
            <KeyValues
              items={[
                ["Current status", <PaymentStatusBadge status={s.status} showName />],
                ["Reason", <Reason code={s.status?.rsn} text={s.status?.addtlInf} />],
                ["Last report", s.status ? dateTime(s.status.at) : "—"],
              ]}
            />
            <h3 className="sub-title">Transactions by status</h3>
            <StatusCounts counts={s.transactionsByStatus} noun="transactions" />
          </div>
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>Status report</th>
                  <th>Created</th>
                  <th>Group status</th>
                  <th className="right">Txs named</th>
                </tr>
              </thead>
              <tbody>
                {s.reports.map((r) => (
                  <tr key={r._id}>
                    <td>
                      <Link className="mono" to={`/reports/${r._id}`}>
                        {r.msgId}
                      </Link>
                      {r.link.status !== "LINKED" && <div className="small bad">Some references did not match</div>}
                    </td>
                    <td className="nowrap">{dateTime(r.creDtTm)}</td>
                    <td>
                      {r.orgnlGrpInfAndSts.grpSts ? (
                        <PaymentBadge code={r.orgnlGrpInfAndSts.grpSts} reason={r.orgnlGrpInfAndSts.stsRsnInf?.[0]?.rsn?.cd} />
                      ) : (
                        <span className="muted small">Per batch</span>
                      )}
                    </td>
                    <td className="right num">{num(r.stats.txCount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </Card>
  );
}

function GraphTab({ id }: { id: string }) {
  const [perBatch, setPerBatch] = useState(5);
  const graph = useQuery({ queryKey: ["graph", id, perBatch], queryFn: () => api.fileGraph(id, perBatch) });
  return (
    <Card
      title="Status reports → file → batches → transactions"
      actions={
        <label className="inline-field">
          Transactions per batch
          <select value={perBatch} onChange={(e) => setPerBatch(Number(e.target.value))}>
            {[5, 15, 30, 60].map((n) => (
              <option key={n} value={n}>{n}</option>
            ))}
          </select>
        </label>
      }
    >
      <p className="muted small">
        Click a report, batch or transaction to open it. The coloured tag on each node is its latest pain.002 status. Scroll to zoom, drag to pan.
      </p>
      {graph.isLoading ? <Loading /> : graph.error ? <ErrorState error={graph.error} /> : (
        <Suspense fallback={<Loading />}>
          <FileGraph graph={graph.data!} />
        </Suspense>
      )}
    </Card>
  );
}

function BatchesTab({ id }: { id: string }) {
  const navigate = useNavigate();
  const q = useQuery({ queryKey: ["fileBatches", id], queryFn: () => api.fileBatches(id) });
  if (q.isLoading) return <Loading />;
  if (q.error) return <ErrorState error={q.error} />;
  return (
    <Card>
      <div className="table-wrap">
        <table className="table clickable">
          <thead>
            <tr>
              <th>#</th>
              <th>Payment information ID</th>
              <th>Execution date</th>
              <th>Method</th>
              <th>Debtor account</th>
              <th className="right">Txs</th>
              <th>Totals</th>
              <th>Validation</th>
              <th>Payment status</th>
            </tr>
          </thead>
          <tbody>
            {q.data!.items.map((b) => (
              <tr key={b._id} onClick={() => navigate(`/batches/${b._id}`)}>
                <td className="muted num">{b.seq + 1}</td>
                <td>
                  <Link className="mono row-link" to={`/batches/${b._id}`} onClick={(e) => e.stopPropagation()}>
                    {b.pmtInfId}
                  </Link>
                </td>
                <td className="nowrap">{date(b.reqdExctnDt?.date)}</td>
                <td>
                  <Code value={b.pmtMtd} />
                </td>
                <td className="mono small">{iban(accountId(b.dbtrAcct))}</td>
                <td className="right num">{num(b.stats.txCount)}</td>
                <td>
                  <Totals totals={b.stats.totalsByCcy} compact />
                </td>
                <td>
                  <StatusBadge status={b.validation.status} />
                </td>
                <td>
                  <PaymentStatusBadge status={b.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function XmlTab({ id }: { id: string }) {
  const q = useQuery({ queryKey: ["xml", id], queryFn: () => api.fileXml(id) });
  return (
    <Card
      title="Original XML"
      actions={
        <a className="btn" href={`/api/files/${id}/xml`} download onClick={() => track("xml.download", { type: "file", id })}>
          Download
        </a>
      }
    >
      {q.isLoading ? <Loading /> : q.error ? <ErrorState error={q.error} /> : <XmlView xml={q.data!} />}
    </Card>
  );
}
