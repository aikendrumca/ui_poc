import { useMemo } from "react";
import { useNavigate } from "react-router";
import {
  Background,
  Controls,
  Handle,
  Position,
  ReactFlow,
  type Edge,
  type Node,
  type NodeProps,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import type { FileGraph as Graph, PaymentStatus, Status } from "../api";
import { compactMoney, date, dateTime, money, num } from "../format";
import { PaymentBadge, PaymentStatusBadge, statusTone } from "./common";
import { track } from "../audit";

const COL_X = [0, 360, 740];
const TX_ROW = 58;
const GROUP_GAP = 28;
const FILE_HEIGHT = 130;
const REPORT_ROW = 96;

type FileData = { msgId: string; party?: string; batches: number; txs: number; status: Status; pmt?: PaymentStatus };
type BatchData = { pmtInfId: string; debtor?: string; date: string; txs: number; totals: string; status: Status; pmt?: PaymentStatus };
type TxData = { e2e: string; creditor?: string; amount: string; ccy: string; pmt?: PaymentStatus };
type MoreData = { more: number };
type ReportData = { msgId: string; created: string; grpSts?: string; rsn?: string; txs: number; linked: boolean };

function statusClass(s: Status) {
  return `status-${s.toLowerCase()}`;
}

function FileNode({ data }: NodeProps<Node<FileData>>) {
  return (
    <div className={`gnode gnode-file ${statusClass(data.status)}`}>
      <div className="gnode-kind">File</div>
      <div className="gnode-title mono">{data.msgId}</div>
      <div className="gnode-sub">{data.party}</div>
      <div className="gnode-meta">
        {num(data.batches)} batches · {num(data.txs)} transactions
      </div>
      <div className="gnode-status">
        <PaymentStatusBadge status={data.pmt} showName />
      </div>
      <Handle type="source" position={Position.Right} />
      <Handle type="target" position={Position.Bottom} id="reports" />
    </div>
  );
}

function BatchNode({ data }: NodeProps<Node<BatchData>>) {
  return (
    <div className={`gnode gnode-batch ${statusClass(data.status)}`}>
      <Handle type="target" position={Position.Left} />
      <div className="gnode-kind">Batch · {date(data.date)}</div>
      <div className="gnode-title mono">{data.pmtInfId}</div>
      <div className="gnode-sub">{data.debtor}</div>
      <div className="gnode-meta">
        {num(data.txs)} txs · {data.totals}
      </div>
      {data.pmt && (
        <div className="gnode-status">
          <PaymentStatusBadge status={data.pmt} />
        </div>
      )}
      <Handle type="source" position={Position.Right} />
    </div>
  );
}

function TxNode({ data }: NodeProps<Node<TxData>>) {
  return (
    <div className={`gnode gnode-tx ${data.pmt ? `tone-${statusTone(data.pmt.code)}` : ""}`}>
      <Handle type="target" position={Position.Left} />
      <div className="gnode-row">
        <span className="gnode-title mono">{data.e2e}</span>
        <span className="gnode-amt num">{money(data.amount, data.ccy)}</span>
      </div>
      <div className="gnode-row">
        <span className="gnode-sub">{data.creditor}</span>
        {data.pmt && <PaymentStatusBadge status={data.pmt} />}
      </div>
    </div>
  );
}

function MoreNode({ data }: NodeProps<Node<MoreData>>) {
  return (
    <div className="gnode gnode-more">
      <Handle type="target" position={Position.Left} />+{num(data.more)} more in this batch
    </div>
  );
}

function ReportNode({ data }: NodeProps<Node<ReportData>>) {
  return (
    <div className={`gnode gnode-report tone-${statusTone(data.grpSts)}`}>
      <div className="gnode-kind">pain.002 status report · {dateTime(data.created)}</div>
      <div className="gnode-title mono">{data.msgId}</div>
      <div className="gnode-status">
        {data.grpSts ? <PaymentBadge code={data.grpSts} reason={data.rsn} showName /> : <span className="gnode-sub">Status per batch</span>}
        {data.txs > 0 && <span className="gnode-sub">{num(data.txs)} txs named</span>}
      </div>
      {!data.linked && <div className="gnode-sub bad">Some references did not match</div>}
      <Handle type="source" position={Position.Top} />
    </div>
  );
}

const nodeTypes = { file: FileNode, batch: BatchNode, tx: TxNode, more: MoreNode, report: ReportNode };

export function FileGraph({ graph }: { graph: Graph }) {
  const navigate = useNavigate();

  const layout = useMemo(() => {
    const nodes: Node[] = [];
    const edges: Edge[] = [];
    let y = 0;
    for (const b of graph.batches) {
      const rows = b.transactions.length + (b.more > 0 ? 1 : 0);
      const groupTop = y;
      b.transactions.forEach((t, i) => {
        const id = `t-${t._id}`;
        nodes.push({
          id,
          type: "tx",
          position: { x: COL_X[2], y: groupTop + i * TX_ROW },
          data: { e2e: t.pmtId.endToEndId, creditor: t.view.cdtrNm, amount: t.view.amount, ccy: t.view.ccy, pmt: t.status },
        });
        edges.push({ id: `e-${b._id}-${t._id}`, source: `b-${b._id}`, target: id, type: "smoothstep" });
      });
      if (b.more > 0) {
        const id = `m-${b._id}`;
        nodes.push({ id, type: "more", position: { x: COL_X[2], y: groupTop + b.transactions.length * TX_ROW }, data: { more: b.more } });
        edges.push({ id: `e-${b._id}-more`, source: `b-${b._id}`, target: id, type: "smoothstep", style: { strokeDasharray: "4 4" } });
      }
      const groupHeight = Math.max(1, rows) * TX_ROW;
      nodes.push({
        id: `b-${b._id}`,
        type: "batch",
        position: { x: COL_X[1], y: groupTop + groupHeight / 2 - 50 },
        data: {
          pmtInfId: b.pmtInfId,
          debtor: b.dbtr?.nm,
          date: b.reqdExctnDt?.date,
          txs: b.stats.txCount,
          totals: b.stats.totalsByCcy.map((t) => compactMoney(t.amount, t.ccy)).join(", "),
          status: b.validation.status,
          pmt: b.status,
        },
      });
      edges.push({
        id: `e-f-${b._id}`,
        source: "file",
        target: `b-${b._id}`,
        type: "smoothstep",
        animated: b.validation.status !== "VALID",
        className: `edge-${b.validation.status.toLowerCase()}`,
      });
      y += groupHeight + GROUP_GAP;
    }
    const f = graph.file;
    const reports = graph.reports ?? [];
    // Status reports hang below the file, so the file sits a little higher when there are any.
    const fileY = Math.max(0, (y - GROUP_GAP) / 2 - 55 - (reports.length * REPORT_ROW) / 2);
    nodes.push({
      id: "file",
      type: "file",
      position: { x: COL_X[0], y: fileY },
      data: {
        msgId: f.msgId,
        party: f.initgPty?.nm,
        batches: f.stats.batchCount,
        txs: f.stats.txCount,
        status: f.validation.status,
        pmt: f.status,
      },
    });
    reports.forEach((r, i) => {
      const id = `r-${r._id}`;
      nodes.push({
        id,
        type: "report",
        position: { x: COL_X[0], y: fileY + FILE_HEIGHT + 40 + i * REPORT_ROW },
        data: {
          msgId: r.msgId,
          created: r.creDtTm,
          grpSts: r.orgnlGrpInfAndSts.grpSts,
          rsn: r.orgnlGrpInfAndSts.stsRsnInf?.[0]?.rsn?.cd,
          txs: r.stats.txCount,
          linked: r.link.status === "LINKED",
        },
      });
      edges.push({ id: `e-${id}`, source: id, target: "file", targetHandle: "reports", type: "smoothstep", className: "edge-report" });
    });
    const height = Math.max(y, fileY + FILE_HEIGHT + 40 + reports.length * REPORT_ROW);
    return { nodes, edges, height };
  }, [graph]);
  const { nodes, edges, height } = layout;
  // Grow with the content up to a point; past that, keep nodes readable and let the user pan.
  const boxHeight = Math.round(Math.min(760, Math.max(360, height * 0.75 + 60)));

  return (
    <div className="graph" style={{ height: boxHeight }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.06, maxZoom: 1, minZoom: 0.6 }}
        minZoom={0.2}
        nodesDraggable={false}
        nodesConnectable={false}
        proOptions={{ hideAttribution: true }}
        onNodeClick={(_, node) => {
          if (node.id === "file") return;
          const [kind, id] = [node.id.slice(0, 1), node.id.slice(2)];
          const type = { r: "report", b: "batch", m: "batch", t: "transaction" }[kind];
          if (type) track("graph.open", { type, id }, { fileId: graph.file._id });
          if (kind === "r") navigate(`/reports/${id}`);
          if (kind === "b" || kind === "m") navigate(`/batches/${id}`);
          if (kind === "t") navigate(`/transactions/${id}`);
        }}
      >
        <Background gap={20} size={1} />
        <Controls showInteractive={false} />
      </ReactFlow>
    </div>
  );
}
