import { useEffect, useRef, useState, type ReactNode } from "react";
import { Link } from "react-router";
import type { CcyTotal, Issue, PaymentStatus, Status, StatusCount, XmlPreview } from "../api";
import { CODE_NAMES, PAYMENT_STATUS, STATUS_REASONS } from "../glossary";
import { bytes, dateTime, money, num } from "../format";

const STATUS_TEXT: Record<Status, string> = { VALID: "Valid", WARN: "Warning", INVALID: "Invalid" };

export function StatusBadge({ status }: { status?: Status }) {
  if (!status) return null;
  return (
    <span className={`badge badge-${status.toLowerCase()}`}>
      <span className="dot" aria-hidden />
      {STATUS_TEXT[status]}
    </span>
  );
}

const LEVEL_TEXT: Record<PaymentStatus["level"], string> = { GROUP: "file", PMTINF: "batch", TX: "transaction" };

export function statusTone(code?: string) {
  return code ? (PAYMENT_STATUS[code]?.tone ?? "info") : "none";
}

/** A pain.002 status code (ACSC, RJCT, …) with its name on hover; "No report" when none has arrived yet. */
export function PaymentBadge({ code, reason, showName }: { code?: string; reason?: string; showName?: boolean }) {
  const name = code ? (PAYMENT_STATUS[code]?.name ?? code) : "No status report yet";
  const reasonName = reason ? `${reason}${STATUS_REASONS[reason] ? ` ${STATUS_REASONS[reason]}` : ""}` : undefined;
  return (
    <span className={`pbadge pbadge-${statusTone(code)}`} title={reasonName ? `${name} · ${reasonName}` : name}>
      {code ?? "None"}
      {showName && code && <span className="pbadge-name">{name}</span>}
      {reason && <span className="pbadge-rsn">{reason}</span>}
    </span>
  );
}

export function PaymentStatusBadge({ status, showName }: { status?: PaymentStatus; showName?: boolean }) {
  return <PaymentBadge code={status?.code} reason={status?.rsn} showName={showName} />;
}

/** The reason code with its name and any free text the bank added. */
export function Reason({ code, text }: { code?: string; text?: string }) {
  if (!code && !text) return <>—</>;
  return (
    <span>
      {code && <Code value={code} />}
      {code && STATUS_REASONS[code] && <span className="code-name"> {STATUS_REASONS[code]}</span>}
      {text && <div className="muted small">{text}</div>}
    </span>
  );
}

/** Every status a file, batch or transaction received, oldest first. */
export function StatusHistory({ items }: { items?: PaymentStatus[] }) {
  if (!items?.length) return <Empty>No pain.002 status report covers this yet.</Empty>;
  return (
    <ol className="timeline">
      {items.map((s, i) => (
        <li key={`${s.reportId}-${i}`} className={`timeline-item tone-${statusTone(s.code)}`}>
          <div className="timeline-head">
            <PaymentBadge code={s.code} showName />
            <span className="muted small">{dateTime(s.at)}</span>
          </div>
          <div className="small">
            <Link to={`/reports/${s.reportId}`} className="mono">
              {s.reportMsgId ?? "Status report"}
            </Link>
            <span className="muted"> · set for the whole {LEVEL_TEXT[s.level]}</span>
          </div>
          {(s.rsn || s.addtlInf) && (
            <div className="small">
              <Reason code={s.rsn} text={s.addtlInf} />
            </div>
          )}
        </li>
      ))}
    </ol>
  );
}

/** How many items are in each status, as a stacked bar with a legend. */
export function StatusCounts({ counts, noun }: { counts?: StatusCount[]; noun: string }) {
  const total = (counts ?? []).reduce((n, c) => n + c.count, 0);
  if (!total) return <Empty>No {noun}.</Empty>;
  const ordered = [...(counts ?? [])].sort((a, b) => b.count - a.count);
  return (
    <div className="scounts">
      <div className="sbar" role="img" aria-label={ordered.map((c) => `${c.count} ${c.code}`).join(", ")}>
        {ordered.map((c) => (
          <span key={c.code} className={`sbar-seg tone-${statusTone(c.code === "NONE" ? undefined : c.code)}`} style={{ flexGrow: c.count }} />
        ))}
      </div>
      <ul className="slegend">
        {ordered.map((c) => (
          <li key={c.code}>
            <PaymentBadge code={c.code === "NONE" ? undefined : c.code} showName />
            <span className="num">{num(c.count)}</span>
            <span className="muted small">{Math.round((100 * c.count) / total)}%</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Code({ value }: { value?: string }) {
  if (!value) return <>—</>;
  const name = CODE_NAMES[value];
  return (
    <span className="code" title={name}>
      {value}
      {name && <span className="code-name"> {name}</span>}
    </span>
  );
}

export function Totals({ totals, compact }: { totals?: CcyTotal[]; compact?: boolean }) {
  if (!totals?.length) return <>—</>;
  return (
    <div className={compact ? "totals compact" : "totals"}>
      {totals.map((t) => (
        <span key={t.ccy} className="total-chip">
          <span className="num">{money(t.amount)}</span> <span className="ccy">{t.ccy}</span>
        </span>
      ))}
    </div>
  );
}

export function Card({ title, actions, children, className }: { title?: ReactNode; actions?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`card ${className ?? ""}`}>
      {(title || actions) && (
        <header className="card-head">
          {title && <h2>{title}</h2>}
          {actions && <div className="card-actions">{actions}</div>}
        </header>
      )}
      {children}
    </section>
  );
}

export function KeyValues({ items }: { items: [ReactNode, ReactNode][] }) {
  return (
    <dl className="kv">
      {items.map(([k, v], i) => (
        <div key={i} className="kv-row">
          <dt>{k}</dt>
          <dd>{v ?? "—"}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Crumbs({ items }: { items: { label: ReactNode; to?: string }[] }) {
  return (
    <nav className="crumbs" aria-label="Breadcrumb">
      {items.map((c, i) => (
        <span key={i} className="crumb">
          {c.to ? <Link to={c.to}>{c.label}</Link> : <span aria-current="page">{c.label}</span>}
          {i < items.length - 1 && <span className="sep" aria-hidden>/</span>}
        </span>
      ))}
    </nav>
  );
}

export function Copy({ value }: { value?: string }) {
  const [done, setDone] = useState(false);
  if (!value) return <>—</>;
  return (
    <span className="copy">
      <span className="mono">{value}</span>
      <button
        type="button"
        className="icon-btn"
        title="Copy"
        aria-label={`Copy ${value}`}
        onClick={() => {
          navigator.clipboard?.writeText(value).then(() => {
            setDone(true);
            setTimeout(() => setDone(false), 1200);
          });
        }}
      >
        {done ? "✓" : "⧉"}
      </button>
    </span>
  );
}

export function Issues({ issues }: { issues?: Issue[] }) {
  if (!issues?.length) return null;
  return (
    <ul className="issues">
      {issues.map((i, n) => (
        <li key={n} className={`issue issue-${i.severity.toLowerCase()}`}>
          <span className="issue-sev">{i.severity === "ERROR" ? "Error" : "Warning"}</span>
          <span className="issue-msg">{i.msg}</span>
          <span className="issue-path mono">{i.path}</span>
        </li>
      ))}
    </ul>
  );
}

export function Pager({ page, size, total, onPage }: { page: number; size: number; total: number; onPage: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / size));
  const from = total === 0 ? 0 : page * size + 1;
  const to = Math.min(total, (page + 1) * size);
  return (
    <div className="pager">
      <span className="muted">
        {num(from)}–{num(to)} of {num(total)}
      </span>
      <div className="pager-btns">
        <button type="button" className="btn" disabled={page === 0} onClick={() => onPage(page - 1)}>
          Previous
        </button>
        <span className="muted">
          Page {page + 1} of {num(pages)}
        </span>
        <button type="button" className="btn" disabled={page + 1 >= pages} onClick={() => onPage(page + 1)}>
          Next
        </button>
      </div>
    </div>
  );
}

export function Loading({ label = "Loading" }: { label?: string }) {
  return (
    <div className="state" role="status">
      <span className="spinner" aria-hidden /> {label}…
    </div>
  );
}

export function ErrorState({ error }: { error: unknown }) {
  const message = error instanceof Error ? error.message : String(error);
  return (
    <div className="state state-error" role="alert">
      <strong>Could not load this.</strong> {message}
      <div className="muted small">Is the API running on port 8080 and MongoDB reachable?</div>
    </div>
  );
}

export function Empty({ children }: { children: ReactNode }) {
  return <div className="state muted">{children}</div>;
}

export function SortHeader({
  label,
  field,
  sort,
  dir,
  onSort,
  align,
}: {
  label: string;
  field: string;
  sort: string;
  dir: string;
  onSort: (field: string, dir: string) => void;
  align?: "right";
}) {
  const active = sort === field;
  const next = active && dir === "desc" ? "asc" : "desc";
  return (
    <th className={align === "right" ? "right" : undefined} aria-sort={active ? (dir === "asc" ? "ascending" : "descending") : "none"}>
      <button type="button" className={`sort ${active ? "active" : ""}`} onClick={() => onSort(field, next)}>
        {label}
        <span className="sort-arrow" aria-hidden>
          {active ? (dir === "asc" ? "▲" : "▼") : "↕"}
        </span>
      </button>
    </th>
  );
}

/** Text input that reports changes after the user pauses typing, so lists don't refetch on every key. */
export function DebouncedInput({
  value,
  onChange,
  delay = 300,
  ...rest
}: { value: string; onChange: (v: string) => void; delay?: number } & Omit<React.InputHTMLAttributes<HTMLInputElement>, "value" | "onChange">) {
  const [text, setText] = useState(value);
  const latest = useRef(onChange);
  latest.current = onChange;
  useEffect(() => setText(value), [value]);
  useEffect(() => {
    if (text === value) return;
    const t = setTimeout(() => latest.current(text), delay);
    return () => clearTimeout(t);
  }, [text]);
  return <input {...rest} value={text} onChange={(e) => setText(e.target.value)} />;
}

/** The original XML; a very large file shows only its start, with a note saying so. */
export function XmlView({ xml }: { xml: XmlPreview }) {
  return (
    <>
      {xml.truncated && (
        <p className="xml-note" role="status">
          Showing the first {bytes(xml.shownBytes)} of {bytes(xml.totalBytes)}. Use Download to get the whole file.
        </p>
      )}
      <pre className="xml">{xml.text}</pre>
    </>
  );
}
