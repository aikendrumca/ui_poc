import { useQuery } from "@tanstack/react-query";
import { api } from "../api";
import { DebouncedInput } from "./common";
import { PAYMENT_STATUS } from "../glossary";

/**
 * Times are kept in the URL as the browser's local "YYYY-MM-DDTHH:mm" (what a
 * datetime-local input produces) and sent to the API as UTC instants.
 */
export function toApiTime(local: string, endOfMinute = false): string {
  if (!local) return "";
  const d = new Date(local);
  if (Number.isNaN(d.getTime())) return "";
  // "To 14:30" means up to the end of that minute.
  if (endOfMinute) d.setSeconds(59, 999);
  return d.toISOString();
}

/**
 * The from/to query parameters for a time filter. Date-only fields (execution
 * dates carry no time of day) send whole calendar days; the API treats a
 * date-only "to" as inclusive of that day.
 */
export function timeParams(dateOnly: boolean, from: string, to: string) {
  if (dateOnly) return { from: from.slice(0, 10), to: to.slice(0, 10) };
  return { from: toApiTime(from), to: toApiTime(to, true) };
}

function toLocalInput(d: Date): string {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

const PRESETS: { label: string; range: () => [Date, Date | null] }[] = [
  { label: "Last hour", range: () => [new Date(Date.now() - 3600_000), null] },
  { label: "Last 24 h", range: () => [new Date(Date.now() - 86400_000), null] },
  {
    label: "Today",
    range: () => {
      const start = new Date();
      start.setHours(0, 0, 0, 0);
      return [start, null];
    },
  },
  { label: "Last 7 days", range: () => [new Date(Date.now() - 7 * 86400_000), null] },
  { label: "Last 30 days", range: () => [new Date(Date.now() - 30 * 86400_000), null] },
];

export function TimeRange({
  fields,
  field,
  from,
  to,
  onChange,
}: {
  fields: { value: string; label: string; dateOnly?: boolean }[];
  field: string;
  from: string;
  to: string;
  onChange: (patch: { timeField?: string; from?: string; to?: string }) => void;
}) {
  const dateOnly = fields.find((f) => f.value === field)?.dateOnly ?? false;
  const type = dateOnly ? "date" : "datetime-local";
  const shown = (v: string) => (dateOnly ? v.slice(0, 10) : v.length === 10 ? `${v}T00:00` : v);
  const invalid = from && to && shown(from) > shown(to);
  return (
    <fieldset className="filter-group">
      <legend>Time range</legend>
      <div className="filter-row">
        <label className="field">
          <span>By</span>
          <select value={field} onChange={(e) => onChange({ timeField: e.target.value })}>
            {fields.map((f) => (
              <option key={f.value} value={f.value}>{f.label}</option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>From</span>
          <input type={type} value={shown(from)} max={to ? shown(to) : undefined} onChange={(e) => onChange({ from: e.target.value })} />
        </label>
        <label className="field">
          <span>To</span>
          <input
            type={type}
            value={shown(to)}
            min={from ? shown(from) : undefined}
            aria-invalid={invalid ? true : undefined}
            onChange={(e) => onChange({ to: e.target.value })}
          />
        </label>
      </div>
      <div className="presets" role="group" aria-label="Quick time ranges">
        {PRESETS.map((p) => (
          <button
            key={p.label}
            type="button"
            className="chip"
            onClick={() => {
              const [start, end] = p.range();
              onChange({ from: toLocalInput(start), to: end ? toLocalInput(end) : "" });
            }}
          >
            {p.label}
          </button>
        ))}
        {(from || to) && (
          <button type="button" className="chip ghost" onClick={() => onChange({ from: "", to: "" })}>
            Any time
          </button>
        )}
      </div>
      {invalid && <div className="field-error">"From" is after "To", so nothing can match.</div>}
    </fieldset>
  );
}

export function AmountRange({
  legend,
  ccy,
  min,
  max,
  onChange,
}: {
  legend: string;
  ccy: string;
  min: string;
  max: string;
  onChange: (patch: { ccy?: string; min?: string; max?: string }) => void;
}) {
  const bad = (v: string) => v !== "" && !/^\d+(\.\d{1,5})?$/.test(v);
  const invalid = bad(min) || bad(max) || (min && max && Number(min) > Number(max));
  const clean = (v: string) => v.replace(/[,\s]/g, "");
  return (
    <fieldset className="filter-group">
      <legend>{legend}</legend>
      <div className="filter-row">
        <label className="field narrow">
          <span>Currency</span>
          <DebouncedInput placeholder="Any" maxLength={3} value={ccy} onChange={(v) => onChange({ ccy: v.toUpperCase() })} />
        </label>
        <label className="field narrow">
          <span>Min</span>
          <DebouncedInput inputMode="decimal" placeholder="0.00" value={min} aria-invalid={bad(min) || undefined} onChange={(v) => onChange({ min: clean(v) })} />
        </label>
        <label className="field narrow">
          <span>Max</span>
          <DebouncedInput inputMode="decimal" placeholder="No limit" value={max} aria-invalid={bad(max) || undefined} onChange={(v) => onChange({ max: clean(v) })} />
        </label>
      </div>
      {invalid && <div className="field-error">Enter plain numbers like 2500 or 2500.50, with min no larger than max.</div>}
    </fieldset>
  );
}

export function PartySelect({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const { data } = useQuery({ queryKey: ["parties"], queryFn: api.parties, staleTime: 60_000 });
  const items = data?.items ?? [];
  const known = !value || items.some((p) => p.name === value);
  return (
    <label className="field">
      <span>Initiating party</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">Any party</option>
        {!known && <option value={value}>{value}</option>}
        {items.map((p) => (
          <option key={p.name} value={p.name}>
            {p.name} ({p.files} {p.files === 1 ? "file" : "files"})
          </option>
        ))}
      </select>
    </label>
  );
}

/** True when an amount filter value is safe to send (the API rejects non-numbers). */
export function amountParam(v: string): string {
  return /^\d+(\.\d{1,5})?$/.test(v) ? v : "";
}

/** Filter on the latest pain.002 status; NONE means no report has covered the item yet. */
export function PaymentStatusSelect({
  value,
  onChange,
  label = "Payment status",
  allowNone = true,
}: {
  value: string;
  onChange: (v: string) => void;
  label?: string;
  allowNone?: boolean;
}) {
  return (
    <label className="field">
      <span>{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">Any</option>
        {allowNone && <option value="NONE">No report yet</option>}
        {Object.entries(PAYMENT_STATUS).map(([code, s]) => (
          <option key={code} value={code}>
            {code} · {s.name}
          </option>
        ))}
      </select>
    </label>
  );
}
