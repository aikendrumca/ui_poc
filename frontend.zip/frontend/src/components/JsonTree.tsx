import { useState } from "react";
import { label } from "../glossary";

type Json = null | boolean | number | string | Json[] | { [k: string]: Json };

/** Collapsible view of a stored document, with ISO tags explained. */
export function JsonTree({ value, hide = [] }: { value: unknown; hide?: string[] }) {
  const entries = Object.entries((value ?? {}) as Record<string, Json>).filter(([k]) => !hide.includes(k));
  return (
    <ul className="tree root">
      {entries.map(([k, v]) => (
        <Node key={k} name={k} value={v} depth={0} />
      ))}
    </ul>
  );
}

function Node({ name, value, depth }: { name: string; value: Json; depth: number }) {
  const isObject = value !== null && typeof value === "object";
  const [open, setOpen] = useState(depth < 2);
  const friendly = label(name);
  const keyEl = (
    <span className="tree-key">
      <span className="mono">{name}</span>
      {friendly && <span className="tree-label">{friendly}</span>}
    </span>
  );

  if (!isObject) {
    return (
      <li className="tree-leaf">
        {keyEl}
        <span className="tree-value mono">{String(value)}</span>
      </li>
    );
  }

  const children = Array.isArray(value)
    ? value.map((v, i) => [String(i), v] as const)
    : Object.entries(value);
  const summary = Array.isArray(value) ? `[${value.length}]` : `{${children.length}}`;

  return (
    <li className="tree-branch">
      <button type="button" className="tree-toggle" aria-expanded={open} onClick={() => setOpen(!open)}>
        <span className="chev" aria-hidden>{open ? "▾" : "▸"}</span>
        {keyEl}
        {!open && <span className="muted small">{summary}</span>}
      </button>
      {open && (
        <ul className="tree">
          {children.map(([k, v]) => (
            <Node key={k} name={k} value={v as Json} depth={depth + 1} />
          ))}
        </ul>
      )}
    </li>
  );
}
