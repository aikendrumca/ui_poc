import { Link, useNavigate } from "react-router";
import type { TxSummary } from "../api";
import { date, iban, money } from "../format";
import { PaymentStatusBadge, SortHeader } from "./common";

/** Transaction rows shared by the batch page and the transaction search. */
export function TxTable({
  items,
  sort,
  dir,
  onSort,
  showBatch,
}: {
  items: TxSummary[];
  sort: string;
  dir: string;
  onSort: (field: string, dir: string) => void;
  showBatch?: boolean;
}) {
  const navigate = useNavigate();
  return (
    <div className="table-wrap">
      <table className="table clickable">
        <thead>
          <tr>
            {!showBatch && <SortHeader label="#" field="seq" sort={sort} dir={dir} onSort={onSort} />}
            <th>End-to-end ID</th>
            <SortHeader label="Creditor" field="creditor" sort={sort} dir={dir} onSort={onSort} />
            <th>Creditor account</th>
            {showBatch && <th>Debtor</th>}
            <SortHeader label="Execution" field="date" sort={sort} dir={dir} onSort={onSort} />
            <SortHeader label="Amount" field="amount" sort={sort} dir={dir} onSort={onSort} align="right" />
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {items.map((t) => (
            <tr key={t._id} onClick={() => navigate(`/transactions/${t._id}`)}>
              {!showBatch && <td className="muted num">{t.seq + 1}</td>}
              <td>
                <Link className="mono row-link" to={`/transactions/${t._id}`} onClick={(e) => e.stopPropagation()}>
                  {t.pmtId.endToEndId}
                </Link>
                {showBatch && (
                  <div className="muted small">
                    <Link to={`/batches/${t.batchId}`} onClick={(e) => e.stopPropagation()} className="mono">
                      {t.pmtInfId}
                    </Link>
                  </div>
                )}
              </td>
              <td>
                {t.view.cdtrNm ?? "—"}
                {t.view.rmtInf && <div className="muted small ellipsis">{t.view.rmtInf}</div>}
              </td>
              <td className="mono small nowrap">
                {iban(t.view.cdtrAcct)}
                {t.view.cdtrBic && <div className="muted">{t.view.cdtrBic}</div>}
              </td>
              {showBatch && <td>{t.view.dbtrNm ?? "—"}</td>}
              <td className="nowrap">{date(t.view.reqdExctnDt)}</td>
              <td className="right num nowrap amount">{money(t.view.amount, t.view.ccy)}</td>
              <td>
                <PaymentStatusBadge status={t.status} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
