import { useEffect, useRef, useState } from "react";
import { NavLink, Outlet, useLocation, useNavigate } from "react-router";
import { useQuery } from "@tanstack/react-query";
import { api, type SearchHit } from "../api";
import { targetFromPath, track } from "../audit";

const KIND_LABEL: Record<SearchHit["type"], string> = { file: "File", batch: "Batch", transaction: "Transaction", report: "Status report" };
const KIND_PATH: Record<SearchHit["type"], string> = { file: "files", batch: "batches", transaction: "transactions", report: "reports" };

function useTheme() {
  const [theme, setTheme] = useState<string | null>(() => {
    try {
      return localStorage.getItem("theme");
    } catch {
      return null;
    }
  });
  useEffect(() => {
    if (theme) document.documentElement.dataset.theme = theme;
    else delete document.documentElement.dataset.theme;
    try {
      if (theme) localStorage.setItem("theme", theme);
      else localStorage.removeItem("theme");
    } catch {
      /* storage unavailable */
    }
  }, [theme]);
  const dark = theme ? theme === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
  return {
    dark,
    toggle: () => {
      const next = dark ? "light" : "dark";
      track("theme.change", undefined, { theme: next });
      setTheme(next);
    },
  };
}

function GlobalSearch() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [debounced, setDebounced] = useState("");
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(q.trim()), 200);
    return () => clearTimeout(t);
  }, [q]);

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (box.current && !box.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", close);
    return () => document.removeEventListener("mousedown", close);
  }, []);

  const { data, isFetching } = useQuery({
    queryKey: ["search", debounced],
    queryFn: () => api.search(debounced),
    enabled: debounced.length >= 2,
  });
  const hits = debounced.length >= 2 ? (data?.hits ?? []) : [];

  // One audit event per settled search term, with how many hits it found.
  const lastLogged = useRef("");
  useEffect(() => {
    if (debounced.length >= 2 && data && !isFetching && lastLogged.current !== debounced) {
      lastLogged.current = debounced;
      track("search.query", undefined, { q: debounced, hits: data.hits.length });
    }
  }, [debounced, data, isFetching]);

  const go = (h: SearchHit) => {
    track("search.open", { type: h.type, id: h.id, label: h.label }, { q: debounced });
    setOpen(false);
    setQ("");
    navigate(`/${KIND_PATH[h.type]}/${h.id}`);
  };

  return (
    <div className="search" ref={box}>
      <input
        type="search"
        placeholder="Find by MsgId, PmtInfId, EndToEndId, InstrId or UETR"
        aria-label="Search payments"
        value={q}
        onChange={(e) => {
          setQ(e.target.value);
          setOpen(true);
          setActive(0);
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={(e) => {
          if (e.key === "ArrowDown") {
            e.preventDefault();
            setActive((a) => Math.min(a + 1, hits.length - 1));
          } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setActive((a) => Math.max(a - 1, 0));
          } else if (e.key === "Enter") {
            if (hits[active]) go(hits[active]);
            else if (q.trim()) {
              setOpen(false);
              navigate(`/transactions?q=${encodeURIComponent(q.trim())}`);
            }
          } else if (e.key === "Escape") setOpen(false);
        }}
      />
      {open && debounced.length >= 2 && (
        <div className="search-results" role="listbox">
          {hits.length === 0 && !isFetching && (
            <div className="search-empty">
              No reference matches. Press Enter to search names and remittance text.
            </div>
          )}
          {hits.map((h, i) => (
            <button
              type="button"
              key={`${h.type}-${h.id}`}
              role="option"
              aria-selected={i === active}
              className={`search-hit ${i === active ? "active" : ""}`}
              onMouseEnter={() => setActive(i)}
              onClick={() => go(h)}
            >
              <span className={`kind kind-${h.type}`}>{KIND_LABEL[h.type]}</span>
              <span className="mono">{h.label}</span>
              <span className="muted small">{h.detail}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function Layout() {
  const location = useLocation();
  // Every page the user opens, with the file, batch, transaction or report it shows.
  useEffect(() => {
    track("page.view", targetFromPath(location.pathname), location.search ? { query: location.search.slice(1) } : undefined);
  }, [location.pathname, location.search]);
  const { dark, toggle } = useTheme();
  return (
    <div className="shell">
      <aside className="side">
        <div className="brand">
          <span className="logo" aria-hidden>
            <svg viewBox="0 0 32 32" width="26" height="26">
              <rect width="32" height="32" rx="7" fill="var(--accent)" />
              <path d="M8 11h16M8 16h11M8 21h7" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
            </svg>
          </span>
          <div>
            <div className="brand-name">Payments Console</div>
            <div className="brand-sub">pain.001 · pain.002</div>
          </div>
        </div>
        <nav className="nav">
          <NavLink to="/" end>Overview</NavLink>
          <NavLink to="/files">Files</NavLink>
          <NavLink to="/transactions">Transactions</NavLink>
          <NavLink to="/reports">Status reports</NavLink>
        </nav>
        <div className="side-foot">
          <button type="button" className="btn ghost" onClick={toggle}>
            {dark ? "Light mode" : "Dark mode"}
          </button>
          <div className="muted small">Read-only view</div>
        </div>
      </aside>
      <div className="main">
        <header className="top">
          <GlobalSearch />
        </header>
        <main className="content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
