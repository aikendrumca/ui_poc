import type { Account, Agent, Party, TxDoc } from "../api";
import { accountId } from "../api";
import { iban } from "../format";

interface Step {
  role: string;
  name?: string;
  account?: string;
  bic?: string;
  kind: "party" | "agent";
}

function party(role: string, p?: Party, acct?: Account): Step | null {
  if (!p) return null;
  return { role, name: p.nm, account: accountId(acct), kind: "party" };
}

function agent(role: string, a?: Agent, acct?: Account): Step | null {
  if (!a) return null;
  const f = a.finInstnId;
  return { role, name: f?.nm, bic: f?.bicfi ?? f?.clrSysMmbId?.mmbId ?? f?.lei, account: accountId(acct), kind: "agent" };
}

/** Left-to-right money flow: who pays, through which banks, to whom. */
export function PartyChain({ tx }: { tx: TxDoc }) {
  const b = tx.context.batch;
  const steps = [
    party("Ultimate debtor", tx.ultmtDbtr ?? b.ultmtDbtr),
    party("Debtor", b.dbtr, b.dbtrAcct),
    agent("Debtor agent", b.dbtrAgt),
    agent("Intermediary 1", tx.intrmyAgt1),
    agent("Intermediary 2", tx.intrmyAgt2),
    agent("Intermediary 3", tx.intrmyAgt3),
    agent("Creditor agent", tx.cdtrAgt),
    party("Creditor", tx.cdtr, tx.cdtrAcct),
    party("Ultimate creditor", tx.ultmtCdtr),
  ].filter((s): s is Step => s !== null);

  return (
    <ol className="chain" aria-label="Payment route">
      {steps.map((s, i) => (
        <li key={s.role} className={`chain-step chain-${s.kind}`}>
          <div className="chain-role">{s.role}</div>
          <div className="chain-name">{s.name ?? (s.kind === "agent" ? s.bic : "—")}</div>
          {s.bic && s.name && <div className="chain-detail mono">{s.bic}</div>}
          {s.kind === "agent" && !s.name && s.bic && <div className="chain-detail">BIC</div>}
          {s.account && <div className="chain-detail mono">{iban(s.account)}</div>}
          {i < steps.length - 1 && <span className="chain-arrow" aria-hidden>→</span>}
        </li>
      ))}
    </ol>
  );
}
