// Records what the user does in the UI and sends it to /api/audit/events, where
// each event becomes an entry in the auditLog collection. Every API call also
// carries the same client identifiers, so the server-side log of API requests
// lines up with these events.

const CLIENT_KEY = "paymentsui.clientId";
const SESSION_KEY = "paymentsui.sessionId";
const FLUSH_MS = 1500;
const MAX_BATCH = 50;

export interface AuditTarget {
  type: "file" | "batch" | "transaction" | "report" | string;
  id?: string;
  label?: string;
}

interface AuditEvent {
  action: string;
  target?: AuditTarget;
  details?: Record<string, unknown>;
  path: string;
  at: string;
}

function uuid(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  // randomUUID needs a secure context; a LAN address over plain http is not one.
  const b = new Uint8Array(16);
  crypto.getRandomValues(b);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

/** Reads an id from storage, creating it on first use; falls back to a per-page id if storage is blocked. */
function stored(storage: () => Storage, key: string, fallback: { value?: string }): string {
  try {
    const s = storage();
    let v = s.getItem(key);
    if (!v) {
      v = uuid();
      s.setItem(key, v);
    }
    return v;
  } catch {
    fallback.value ??= uuid();
    return fallback.value;
  }
}

const memoryClient: { value?: string } = {};
const memorySession: { value?: string } = {};

/** Stays the same for this browser until its site data is cleared. */
export const clientId = () => stored(() => localStorage, CLIENT_KEY, memoryClient);
/** One per browser tab session. */
export const sessionId = () => stored(() => sessionStorage, SESSION_KEY, memorySession);

/** Headers sent with every API call. */
export function clientHeaders(): Record<string, string> {
  return { "X-Client-Id": clientId(), "X-Session-Id": sessionId(), "X-Request-Id": uuid() };
}

let queue: AuditEvent[] = [];
let timer: ReturnType<typeof setTimeout> | undefined;

/** Records one user action; events are sent in small batches. */
export function track(action: string, target?: AuditTarget, details?: Record<string, unknown>) {
  queue.push({
    action,
    target,
    details,
    path: window.location.pathname + window.location.search,
    at: new Date().toISOString(),
  });
  if (queue.length >= MAX_BATCH) flush();
  else if (!timer) timer = setTimeout(flush, FLUSH_MS);
}

function flush(useBeacon = false) {
  if (timer) {
    clearTimeout(timer);
    timer = undefined;
  }
  if (queue.length === 0) return;
  const events = queue.slice(0, MAX_BATCH);
  queue = queue.slice(MAX_BATCH);
  const body = JSON.stringify({ events, clientId: clientId(), sessionId: sessionId() });
  if (useBeacon && typeof navigator.sendBeacon === "function") {
    // Beacons cannot set headers, hence the ids in the body.
    navigator.sendBeacon("/api/audit/events", new Blob([body], { type: "application/json" }));
  } else {
    fetch("/api/audit/events", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...clientHeaders() },
      body,
      keepalive: true,
    }).catch(() => {
      /* Losing an audit event must never break the page. */
    });
  }
  if (queue.length) flush(useBeacon);
}

// Send whatever is queued when the tab is hidden or closed.
if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") flush(true);
  });
  window.addEventListener("pagehide", () => flush(true));
}

const TARGET_TYPES: Record<string, AuditTarget["type"]> = {
  files: "file",
  batches: "batch",
  transactions: "transaction",
  reports: "report",
};

/** The file, batch, transaction or report a detail page shows, from its path. */
export function targetFromPath(pathname: string): AuditTarget | undefined {
  const [, section, id] = pathname.split("/");
  const type = TARGET_TYPES[section];
  return type && id ? { type, id } : undefined;
}
