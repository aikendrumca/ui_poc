import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { createBrowserRouter, Link, RouterProvider } from "react-router";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Layout } from "./components/Layout";
import { Overview } from "./pages/Overview";
import { Files } from "./pages/Files";
import { FileDetail } from "./pages/FileDetail";
import { BatchDetail } from "./pages/BatchDetail";
import { Transactions } from "./pages/Transactions";
import { TransactionDetail } from "./pages/TransactionDetail";
import { Reports } from "./pages/Reports";
import { ReportDetail } from "./pages/ReportDetail";
import { ApiError } from "./api";
import "./styles.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 10_000,
      retry: (count, err) => !(err instanceof ApiError && err.status === 404) && count < 2,
    },
  },
});

function NotFound() {
  return (
    <div className="page">
      <h1>Not found</h1>
      <p className="muted">
        That page does not exist. <Link to="/">Back to the overview</Link>
      </p>
    </div>
  );
}

const router = createBrowserRouter([
  {
    element: <Layout />,
    children: [
      { path: "/", element: <Overview /> },
      { path: "/files", element: <Files /> },
      { path: "/files/:id", element: <FileDetail /> },
      { path: "/batches/:id", element: <BatchDetail /> },
      { path: "/transactions", element: <Transactions /> },
      { path: "/transactions/:id", element: <TransactionDetail /> },
      { path: "/reports", element: <Reports /> },
      { path: "/reports/:id", element: <ReportDetail /> },
      { path: "*", element: <NotFound /> },
    ],
  },
]);

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  </StrictMode>,
);
