import { useCallback } from "react";
import { useSearchParams } from "react-router";
import { track } from "./audit";

/**
 * List filters, sorting and paging live in the URL, so a filtered view can be
 * bookmarked or shared and the back button behaves.
 */
export function useQueryParams<T extends Record<string, string>>(defaults: T) {
  const [params, setParams] = useSearchParams();
  const values = { ...defaults } as T;
  for (const key of Object.keys(defaults) as (keyof T & string)[]) {
    const v = params.get(key);
    if (v !== null) (values as Record<string, string>)[key] = v;
  }

  const update = useCallback(
    (patch: Partial<T>, resetPage = true) => {
      const keys = Object.keys(patch);
      track(keys.length === 1 && keys[0] === "page" ? "list.page" : "list.filter", undefined, {
        list: window.location.pathname,
        changes: patch,
      });
      setParams(
        (prev) => {
          const next = new URLSearchParams(prev);
          for (const [k, v] of Object.entries(patch)) {
            if (v === undefined || v === "" || v === defaults[k]) next.delete(k);
            else next.set(k, String(v));
          }
          if (resetPage && !("page" in patch)) next.delete("page");
          return next;
        },
        { replace: true },
      );
    },
    [setParams],
  );

  return [values, update] as const;
}
