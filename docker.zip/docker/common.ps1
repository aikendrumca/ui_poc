# Helpers shared by docker-start.ps1, docker-stop.ps1 and docker-samples.ps1.

function Write-Step([string]$Message) {
    Write-Host "==> $Message" -ForegroundColor Cyan
}

function Assert-Docker {
    if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
        throw "The docker command was not found. Install Docker Desktop and open a new terminal."
    }
    docker info *> $null
    if ($LASTEXITCODE -ne 0) {
        throw "Docker is not running. Start Docker Desktop, wait until it says it is running, then try again."
    }
    docker compose version *> $null
    if ($LASTEXITCODE -ne 0) {
        throw "Docker Compose v2 is needed ('docker compose'). Update Docker Desktop."
    }
}

# Reads the values docker-compose.yml uses from .env, falling back to its defaults.
function Get-DockerSettings {
    $values = @{}
    $envFile = Join-Path (Get-Location) ".env"
    if (Test-Path $envFile) {
        foreach ($line in Get-Content $envFile) {
            if ($line -match '^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$' -and -not $line.TrimStart().StartsWith("#")) {
                $values[$Matches[1]] = $Matches[2].Trim('"').Trim("'")
            }
        }
    }
    function Pick($name, $default) {
        $fromShell = [Environment]::GetEnvironmentVariable($name)
        if ($fromShell) { return $fromShell }
        if ($values.ContainsKey($name) -and $values[$name]) { return $values[$name] }
        return $default
    }
    [pscustomobject]@{
        MongoUri  = Pick "MONGODB_URI" "mongodb://host.docker.internal:27017/payments"
        UiPort    = Pick "UI_PORT" "3000"
        ApiPort   = Pick "API_PORT" "8080"
        MongoPort = Pick "MONGO_PORT" "27018"
        InboxDir  = Pick "INBOX_DIR" "./inbox"
    }
}

# Runs db/create-db.js inside an existing MongoDB container. Safe to re-run.
function Initialize-ExistingMongo([string]$Container, [string]$Uri) {
    $running = docker ps --filter "name=^/$Container$" --format "{{.Names}}"
    if (-not $running) {
        $exists = docker ps -a --filter "name=^/$Container$" --format "{{.Names}}"
        if ($exists) {
            Write-Step "Starting MongoDB container '$Container'"
            docker start $Container | Out-Null
            if ($LASTEXITCODE -ne 0) { throw "Could not start the MongoDB container '$Container'." }
            Start-Sleep -Seconds 3
        } else {
            Write-Warning "No container named '$Container'. Skipping database setup; the API will use $Uri."
            Write-Warning "Use -MongoContainer <name> for another container, or -BundledMongo to start one."
            return
        }
    }
    $dbName = "payments"
    if ($Uri -match '^mongodb(?:\+srv)?://[^/]+/([^/?]+)') { $dbName = $Matches[1] }
    Write-Step "Updating collections, validators and indexes in '$Container' (database $dbName)"
    docker cp ([IO.Path]::Combine($PSScriptRoot, "..", "db", "create-db.js")) "${Container}:/tmp/create-db.js" | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "Could not copy create-db.js into '$Container'." }
    docker exec $Container mongosh --quiet --eval "var DB_NAME='$dbName'" /tmp/create-db.js
    if ($LASTEXITCODE -ne 0) {
        throw "create-db.js failed inside '$Container'. If that container needs a username and password, run it yourself with mongosh and start with -SkipDbSetup."
    }
}
